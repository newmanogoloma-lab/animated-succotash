# CHANGELOG — v4.1 (dashboard sync + charts)

All 148 original tests still pass; 30 new tests added (178 total). Strategy, scoring and risk-engine math are untouched.

## Position sync (dashboard vs robot)
| ID | Problem | Fix |
|----|---------|-----|
| A1 | Dashboard created its **own** PaperEngine, so Close/Close-All/Config acted on an empty copy | Dashboard no longer trades. Commands go through a `commands` table; the robot executes them and returns the result (409 if robot offline) |
| A2 | DB path was `process.cwd()/data` → robot and dashboard could open **different** `robot.db` files | Anchored to the repo (`ROBOT_DATA_DIR` override); path logged by both processes and shown in the UI; mismatch banner |
| A3 | Manual close booked the exit at the **entry price** (PnL ≈ −fees) | `closeTrade` requires a real market price; the robot supplies the live ticker and refuses to close when none is available |
| A4 | Journal writes wrapped in `catch (_) {}` — failed saves vanished silently | `_persist` logs, raises a `DB_WRITE_FAILED` alert, queues the trade and retries (`flushOutbox`) |
| A5 | Event bus is in-process only; UI polled every 5 s | `events` table + `/api/stream` SSE; browser refreshes instantly; `LIVE/POLLING` badge |
| A6 | `robot_running` was a stale flag | Heartbeat (pid, DB path, open count, pending writes); status derived from it (`RUNNING/PAUSED/OFFLINE`) |
| A7 | SL/TP were evaluated only when a symbol was reached in a full scan | Dedicated position monitor loop (default 5 s) |
| A8 | Ticker failure silently showed 0.00 PnL | `priceSource` per position (`LIVE/STALE/ENTRY_FALLBACK`) + stale banner |
| A9 | `index.html` cacheable; N+1 signal query; no one-command start | `Cache-Control: no-store`; signals fetched once; `npm run start:all`; Codespaces URL logged |
| NEW | **Trade id was `symbol_strategy`** and the journal used `INSERT OR REPLACE` → re-entering the same symbol+strategy **overwrote the earlier closed trade** | Unique id `symbol_strategy_openTime` |
| NEW | Restart lost all in-memory positions while the DB still showed them "open" forever | `restoreFromJournal()` on robot start (open trades, trailing state, realized balance, risk exposure) |
| NEW | Trailing-stop moves were never persisted (dashboard showed the original SL) | `stop_loss`, `trailing_stop`, `trailing_active`, `initial_risk` columns kept up to date |
| NEW | Dashboard Start/Stop only flipped a DB flag the robot never read | Real `PAUSE/RESUME/EMERGENCY_*` commands; emergency now also blocks the paper engine's own risk engine |
| NEW | Dashboard config changes never reached the robot | `CONFIG_UPDATE` command + persisted `config_overrides` re-applied on restart |

## Charts
| ID | Problem | Fix |
|----|---------|-----|
| B1 | Fixed 1200×380 canvas stretched by CSS, no axis/crosshair/zoom | lightweight-charts v4.2: crisp, responsive, crosshair, zoom/pan, local-time axis, volume |
| B2 | Chart never refreshed | Live candle every 3 s (tab visible), instant refresh on SSE events |
| B3 | Signal levels labelled "Active Trade Levels" | `levels.source` = `OPEN_TRADE` (solid) or `SIGNAL` (dotted, "not traded") |
| B4 | No trade context | Entry/SL/TP/trailing lines, live unrealized PnL, entry/exit markers with PnL |
| B5 | 3 timeframes, 100 candles, unvalidated symbol, no cache | 1m/5m/15m/1h/4h/1d, 300 (max 500) candles, symbol validation, 3–10 s server cache with in-flight dedupe, `since=` incremental updates |
| B6 | No indicators | EMA20 / EMA50 / VWAP overlays (toggles remembered) |
| — | Chart buttons elsewhere didn't open the chart tab | `loadChart()` now switches to the chart tab |

## Not changed / out of scope
- Live (real-money) position close from the dashboard is not supported by design.
- Analytics tab charts (equity curve, R-distribution) still use the canvas renderer.
