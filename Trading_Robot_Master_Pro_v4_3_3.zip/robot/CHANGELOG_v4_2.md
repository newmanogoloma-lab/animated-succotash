# CHANGELOG — v4.2 (multi-position, all strategies, Black & Teal)
188 tests pass (178 original + 10 new in `tests/v4_2_features.test.js`). Strategy scoring maths is unchanged.

## Why pages were blank (root causes)
| Page | Cause | Fix |
|------|-------|-----|
| Latest Scanner Signals / Market Scanner / Opportunities | The robot only saved a signal **when a trade opened**; rejected/qualified-unopened setups were never stored. Rows that were stored had `null` levels and `s.entry.toFixed()` crashed the whole table render | Robot saves best signal per market + every qualified/fill setup each scan; UI is null-safe; scanner reads the **latest scan** (qualified first, then score) |
| Trade Journal | The tab had **no loader function** (`filterJournalTable`/`fetchJournal` never existed) | Loader added, shows open + closed, paper + live |

## Requested features
- **10+ open positions @ ≥1.5% risk**: defaults `RISK_PER_TRADE=1.5%`, `MAX_OPEN_POSITIONS=12`, `TARGET_OPEN_POSITIONS=10`. Root blocker fixed: exposure was **notional** vs balance (cap 30%) so a $100 account at 1.5% risk could hold ~1 trade. Now **margin-based** (notional ÷ leverage). `ALT_GENERAL` is exempt from the cluster cap.
- **All strategies at once**: `STRATEGY_MODE=ALL` (router no longer gates by regime). Opposing LONG/SHORT: stronger side wins if ≥10 pts ahead, else stand aside. One position per symbol (best signal).
- **Rank-then-fill**: whole universe analysed first, slots filled best-score-first; `FILL` tier (75–84) tops up to the target; `MAX_NEW_PER_SCAN=4` staggers entries.
- **Qualified opportunities show Entry/SL/TP + risk→reward before any trade** (cards on Overview, full table on Scanner), with IN TRADE / READY / FILL status.
- **Strategy toggles now reach the robot** (previously changed the dashboard process only) and persist across restarts.

## Close-trade error ("… not found")
Dashboard listed an open row that the robot's memory no longer held. Close now **re-attaches the journal row and closes it at the live price**; a truly closed id returns a clear "not open" message. `restoreFromJournal` no longer skips a second row with the same symbol+strategy.

## Theme
Black & teal (#14b8a6 / #2dd4bf), glass cards, teal glow tabs, new scan-status strip with strategy chips, teal/red candles.

## Housekeeping
`npm test` script fixed (glob), `.env.example` updated (**old values `RISK_PER_TRADE=0.01`, `MAX_OPEN_POSITIONS=5` silently override the new defaults if copied to `.env`**), signals table auto-pruned (`SIGNAL_RETENTION`).
