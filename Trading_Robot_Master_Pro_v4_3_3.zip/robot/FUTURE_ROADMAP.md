# GPS Crypto Trading Platform — Future Roadmap

This document outlines intentional, future-ready architectural extension points designed into the GPS Crypto Trading Robot. These capabilities are planned for subsequent development phases and are isolated to prevent code bloat in the lean production release.

---

## 1. Multi-Exchange Connectivity
- **Contract Interface**: `BaseExchangeAdapter` in `src/exchanges/base.js`.
- **Planned Adapters**:
  - `BinanceAdapter` (USDT-M Futures REST & WebSockets)
  - `OKXAdapter` (Perpetual Swap REST & WebSockets)
  - `HyperliquidAdapter` (On-chain perpetual DEX)
- **Zero Core Modification**: Adding an exchange requires only implementing `BaseExchangeAdapter` without altering the risk engine, strategy registry, or journal store.

---

## 2. Advanced Market Regimes & Volatility Modeling
- **Extension Point**: `src/market/regime.js`.
- **Planned Enhancements**:
  - GARCH / Realized Volatility cone estimation.
  - Hidden Markov Model (HMM) 3-state transition matrix (Trend, Mean-Reverting, Breakout).
  - Funding Rate & Open Interest delta momentum integration.

---

## 3. High-Performance Persistence Layer
- **Contract Interface**: `src/journal/store.js`.
- **Planned Database Drivers**:
  - PostgreSQL with TimescaleDB for multi-year tick/candle backtesting data.
  - Redis cache layer for sub-millisecond multi-asset orderbook state sharing.
  - Automated cloud backup snapshot rotation.

---

## 4. Advanced Portfolio & Institutional Risk Management
- **Extension Point**: `src/risk/engine.js`.
- **Planned Capabilities**:
  - Value-at-Risk (VaR) and Conditional VaR (CVaR) live calculation.
  - Principal Component Analysis (PCA) rolling correlation matrix across top 100 crypto assets.
  - Dynamic Kelly Criterion position sizing with half-Kelly conservative mode.

---

## 5. Execution Algorithms
- **Extension Point**: `src/execution/live.js`.
- **Planned Features**:
  - TWAP (Time-Weighted Average Price) slice execution for large position entries.
  - Passive post-only limit order chasing to capture maker fee rebates.
  - Slippage minimization routing.

---

## 6. Real-Time WebSockets Data Feed
- **Extension Point**: `src/market/dataFeed.js`.
- **Planned Features**:
  - Bybit V5 WebSocket private & public streams (`kline`, `tickers`, `orderbook.50`).
  - Event-driven trigger candle processing reducing latency from polling intervals to sub-second updates.
