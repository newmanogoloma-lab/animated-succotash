'use strict';
const { describe, it } = require('node:test');
const assert = require('node:assert');
const rules = require('../src/exchanges/rules');
const expiry = require('../src/signals/expiry');
const config = require('../src/config');
const { NotificationService } = require('../src/notifications');

const inst = (o = {}) => rules.parseInstrument({ symbol: 'SOLUSDT', priceFilter: { tickSize: '0.01' }, lotSizeFilter: { qtyStep: '0.1', minOrderQty: '0.1', maxOrderQty: '1000', minNotionalValue: '5' }, leverageFilter: { maxLeverage: '50' }, ...o });

describe('Bybit ticket rounding', () => {
  it('rounds entry to tick, SL away from entry, TP toward entry, qty down to step', () => {
    const t = rules.buildTicket({ symbol: 'SOLUSDT', direction: 'LONG', entry: 150.1234, stopLoss: 147.5049, takeProfit: 156.2999 }, { rules: inst(), balance: 1000, riskPct: 0.01, leverage: 10 });
    assert.equal(t.entry, 150.12);
    assert.equal(t.stopLoss, 147.5);      // floor (away from entry for LONG)
    assert.equal(t.takeProfit, 156.29);   // floor (toward entry for LONG)
    assert.equal(t.qty, 3.8);             // 10 / 2.62 = 3.816 -> 3.8
    assert.ok(t.riskUsd <= 10);
  });
  it('SHORT rounds the other way', () => {
    const t = rules.buildTicket({ symbol: 'SOLUSDT', direction: 'SHORT', entry: 150, stopLoss: 152.501, takeProfit: 144.999 }, { rules: inst(), balance: 1000, riskPct: 0.01 });
    assert.equal(t.stopLoss, 152.51);
    assert.equal(t.takeProfit, 145);
  });
  it('flags orders below Bybit minimums and handles micro prices', () => {
    const tiny = rules.buildTicket({ symbol: 'SOLUSDT', direction: 'LONG', entry: 150, stopLoss: 100, takeProfit: 250 }, { rules: inst(), balance: 20, riskPct: 0.01 });
    assert.equal(tiny.belowMin, true);
    const pepe = rules.buildTicket({ symbol: 'PEPEUSDT', direction: 'LONG', entry: 0.00001234, stopLoss: 0.0000120, takeProfit: 0.0000135 },
      { rules: rules.parseInstrument({ symbol: 'PEPEUSDT', priceFilter: { tickSize: '0.0000001' }, lotSizeFilter: { qtyStep: '100', minOrderQty: '100' } }), balance: 100, riskPct: 0.02 });
    assert.equal(pepe.entry, 0.0000123);
    assert.equal(pepe.qty % 100, 0);
  });
  it('degrades gracefully without rules', () => {
    const t = rules.buildTicket({ symbol: 'ZZZUSDT', direction: 'LONG', entry: 1, stopLoss: 0.9, takeProfit: 1.2 }, { balance: 100, riskPct: 0.01 });
    assert.equal(t.rulesLoaded, false);
    assert.ok(t.notes.length);
  });
});

describe('Signal expiry', () => {
  const sig = { direction: 'LONG', entry: 100, stopLoss: 98, openTime: Date.now() - 60000 };
  it('fresh inside the entry zone', () => assert.equal(expiry.evaluate(sig, 100.3).status, 'FRESH'));
  it('expired once price runs past entry', () => { const r = expiry.evaluate(sig, 100.8); assert.equal(r.status, 'EXPIRED'); assert.equal(r.reason, 'RAN_AWAY'); });
  it('expired when it moves far against', () => assert.equal(expiry.evaluate(sig, 98.7).reason, 'WEAKENED'));
  it('expired when too old; SHORT mirrored', () => {
    assert.equal(expiry.evaluate({ ...sig, openTime: Date.now() - 5 * 3600e3 }, 100).reason, 'OLD');
    assert.equal(expiry.evaluate({ direction: 'SHORT', entry: 100, stopLoss: 102, openTime: Date.now() }, 99.2).reason, 'RAN_AWAY');
  });
});

describe('Telegram score gate', () => {
  it('skips signals below TELEGRAM_MIN_SCORE and sends at/above', async () => {
    const n = new NotificationService();
    const sent = []; n.dispatch = async (e) => { sent.push(e); return {}; };
    const prev = config.telegramMinScore; config.telegramMinScore = 90;
    try {
      const base = { symbol: 'SOLUSDT', direction: 'LONG', entry: 150, stopLoss: 147, takeProfit: 156, riskReward: 2, regime: { regime: 'STRONG_TREND' } };
      const lo = await n.notifySignal({ ...base, score: 88 });
      assert.equal(lo.skipped, true);
      await n.notifySignal({ ...base, score: 92 });
      assert.equal(sent.length, 1);
      assert.match(sent[0].title, /SOLUSDT/);
    } finally { config.telegramMinScore = prev; }
  });
});
