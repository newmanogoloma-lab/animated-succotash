'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  calculateTradeMetrics,
  calculatePortfolioMetrics,
  calculatePerformanceStats,
  calculateRiskStatus,
} = require('../src/dashboard/analytics');

describe('Dashboard Analytics & Financial Mathematics', () => {

  describe('calculateTradeMetrics()', () => {
    it('calculates accurate LONG metrics (Notional, Margin, Risk, Reward, PnL, R multiple)', () => {
      const trade = {
        symbol: 'SOLUSDT',
        direction: 'LONG',
        entry: 100,
        stopLoss: 90,
        takeProfit: 120,
        positionSize: 10,
        mode: 'PAPER',
        regime: 'TRENDING_UP',
        cluster: 'LAYER_1',
      };

      // Current mark price: $110 (profit of $10/unit, total $100 PnL)
      const metrics = calculateTradeMetrics(trade, 110, 10);

      // Notional = 10 * 110 = 1100
      assert.equal(metrics.notional, 1100);
      // Margin = 1100 / 10 = 110
      assert.equal(metrics.margin, 110);
      // Risk = abs(100 - 90) * 10 = 100
      assert.equal(metrics.riskAmount, 100);
      // Expected Reward = abs(120 - 100) * 10 = 200
      assert.equal(metrics.expectedReward, 200);
      // R:R = 200 / 100 = 2.0
      assert.equal(metrics.riskRewardRatio, 2.0);
      // Unrealized PnL = (110 - 100) * 10 = 100
      assert.equal(metrics.unrealizedPnl, 100);
      // Current R = 100 / 100 = +1.0R
      assert.equal(metrics.currentR, 1.0);
      // Progress: SL is 90, TP is 120 (range 30). Price 110 is (110 - 90)/30 * 100 = 66.7%
      assert.equal(metrics.progressPct, 66.7);
    });

    it('calculates accurate SHORT metrics and handles bounds', () => {
      const trade = {
        symbol: 'DOGEUSDT',
        direction: 'SHORT',
        entry: 0.10,
        stopLoss: 0.12,
        takeProfit: 0.06,
        positionSize: 1000,
      };

      // Current mark price: 0.08 (profit of 0.02 * 1000 = $20)
      const metrics = calculateTradeMetrics(trade, 0.08, 5);

      assert.equal(metrics.notional, 80);
      assert.equal(metrics.margin, 16);
      assert.equal(metrics.riskAmount, 20);
      assert.equal(metrics.expectedReward, 40);
      assert.equal(metrics.riskRewardRatio, 2.0);
      assert.equal(metrics.unrealizedPnl, 20);
      assert.equal(metrics.currentR, 1.0);
      // SHORT Progress: SL is 0.12, TP is 0.06 (range 0.06). At 0.08: (0.12 - 0.08)/0.06 = 66.7%
      assert.equal(metrics.progressPct, 66.7);
    });

    it('clamps progress bar between 0% and 100%', () => {
      const trade = { entry: 100, stopLoss: 90, takeProfit: 120, positionSize: 1, direction: 'LONG' };
      // Below SL
      const below = calculateTradeMetrics(trade, 85);
      assert.equal(below.progressPct, 0);

      // Above TP
      const above = calculateTradeMetrics(trade, 130);
      assert.equal(above.progressPct, 100);
    });
  });

  describe('calculatePortfolioMetrics()', () => {
    it('accurately computes portfolio equity, deployed capital, and exposure %', () => {
      const openPositions = [
        { notional: 1000, margin: 100, unrealizedPnl: 50, riskAmount: 30, expectedReward: 60 },
        { notional: 500, margin: 50, unrealizedPnl: -20, riskAmount: 20, expectedReward: 40 },
      ];
      const closedTrades = [
        { pnl: 200 },
        { pnl: -50 },
      ];

      const port = calculatePortfolioMetrics(openPositions, 10000, 10, closedTrades, 0.3);

      // Realized PnL = 200 - 50 = 150
      assert.equal(port.realizedPnl, 150);
      // Unrealized PnL = 50 - 20 = 30
      assert.equal(port.unrealizedPnl, 30);
      // Net PnL = 150 + 30 = 180
      assert.equal(port.netPnl, 180);
      // Current Equity = 10000 + 180 = 10180
      assert.equal(port.currentEquity, 10180);
      // Capital Deployed = 1000 + 500 = 1500
      assert.equal(port.capitalDeployed, 1500);
      // Margin Used = 100 + 50 = 150
      assert.equal(port.marginUsed, 150);
      // Available Capital = 10180 - 150 = 10030
      assert.equal(port.availableCapital, 10030);
      // Portfolio Exposure % = 1500 / 10180 * 100 = 14.7%
      assert.equal(port.portfolioExposurePct, 14.7);
      // Total Risk = 30 + 20 = 50
      assert.equal(port.currentRisk, 50);
      assert.equal(port.openPositionsCount, 2);
    });
  });

  describe('calculatePerformanceStats()', () => {
    it('handles empty closed trades gracefully with zeroed statistics', () => {
      const stats = calculatePerformanceStats([], 10000);
      assert.equal(stats.totalTrades, 0);
      assert.equal(stats.winRate, 0);
      assert.equal(stats.profitFactor, 0);
      assert.equal(stats.expectancy, 0);
      assert.equal(stats.peakEquity, 10000);
      assert.equal(stats.currentDrawdown, 0);
      assert.ok(Array.isArray(stats.rDistribution));
    });

    it('accurately computes win rate, profit factor, expectancy, and R distribution', () => {
      const trades = [
        { id: '1', symbol: 'SOLUSDT', entry: 100, stop_loss: 95, position_size: 10, pnl: 100, outcome: 'WIN', exit_reason: 'TAKE_PROFIT_HIT', open_time: 1000, close_time: 2000 },
        { id: '2', symbol: 'NEARUSDT', entry: 2.0, stop_loss: 1.8, position_size: 250, pnl: -50, outcome: 'LOSS', exit_reason: 'STOP_LOSS_HIT', open_time: 2000, close_time: 3000 },
        { id: '3', symbol: 'SOLUSDT', entry: 100, stop_loss: 95, position_size: 10, pnl: 100, outcome: 'WIN', exit_reason: 'TAKE_PROFIT_HIT', open_time: 3000, close_time: 4000 },
      ];

      const stats = calculatePerformanceStats(trades, 10000);

      assert.equal(stats.totalTrades, 3);
      assert.equal(stats.winningTrades, 2);
      assert.equal(stats.losingTrades, 1);
      assert.equal(stats.winRate, 66.67);
      assert.equal(stats.grossProfit, 200);
      assert.equal(stats.grossLoss, 50);
      assert.equal(stats.netPnl, 150);
      // Profit factor = 200 / 50 = 4.0
      assert.equal(stats.profitFactor, 4.0);
      // Avg Win = 100, Avg Loss = 50
      assert.equal(stats.avgWin, 100);
      assert.equal(stats.avgLoss, 50);
      // Expectancy = (0.6667 * 100) - (0.3333 * 50) = 66.67 - 16.67 = 50.0
      assert.equal(stats.expectancy, 50.01);
      assert.equal(stats.tpCount, 2);
      assert.equal(stats.slCount, 1);

      // Attribution
      assert.ok(stats.bySymbol.some(s => s.symbol === 'SOLUSDT' && s.trades === 2));
      assert.ok(stats.bySymbol.some(s => s.symbol === 'NEARUSDT' && s.trades === 1));
    });
  });

  describe('calculateRiskStatus()', () => {
    it('reports NORMAL risk state when operating within limits', () => {
      const riskStatus = { exposurePct: 15, dailyPnL: 50, consecutiveLosses: 1, clusterExposures: { LAYER_1: 1000 } };
      const cfg = { maxDailyLoss: 0.05, maxConsecutiveLosses: 5, maxPortfolioExposure: 0.3, maxCorrelatedExposure: 0.2 };

      const res = calculateRiskStatus(riskStatus, cfg, [{ id: '1' }], 10000);
      assert.equal(res.level, 'NORMAL');
      assert.ok(res.badge.includes('NORMAL'));
    });

    it('reports ELEVATED when near consecutive loss streak limit', () => {
      const riskStatus = { exposurePct: 15, dailyPnL: -100, consecutiveLosses: 4, clusterExposures: {} };
      const cfg = { maxDailyLoss: 0.05, maxConsecutiveLosses: 5, maxPortfolioExposure: 0.3, maxCorrelatedExposure: 0.2 };

      const res = calculateRiskStatus(riskStatus, cfg, [], 10000);
      assert.equal(res.level, 'ELEVATED');
      assert.ok(res.badge.includes('ELEVATED'));
    });

    it('reports LOCKED when emergency kill switch is active or daily loss limit hit', () => {
      const riskStatus = { killSwitch: true, exposurePct: 0, dailyPnL: 0, consecutiveLosses: 0 };
      const cfg = { maxDailyLoss: 0.05, maxConsecutiveLosses: 5, maxPortfolioExposure: 0.3, maxCorrelatedExposure: 0.2 };

      const res = calculateRiskStatus(riskStatus, cfg, [], 10000);
      assert.equal(res.level, 'LOCKED');
      assert.ok(res.badge.includes('LOCKED'));
      assert.equal(res.circuitBreakers.killSwitch, true);
    });
  });

});
