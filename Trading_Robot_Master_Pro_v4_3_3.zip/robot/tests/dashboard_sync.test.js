'use strict';

const os = require('os');
const fs = require('fs');
const path = require('path');
const http = require('http');
process.env.ROBOT_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'gps-dash-'));

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const journal = require('../src/journal/store');
const dataFeed = require('../src/market/dataFeed');

// Deterministic candles (ms timestamps like Bybit) so no network is needed
const BASE = 1_790_000_000_000;
const STEP = 15 * 60 * 1000;
dataFeed.getCandles = async (symbol, tf, limit) => Array.from({ length: Math.min(limit, 120) }, (_, i) => ({
  time: BASE + i * STEP, open: 100 + i * 0.1, high: 101 + i * 0.1, low: 99 + i * 0.1, close: 100.5 + i * 0.1, volume: 1000 + i, turnover: 0,
}));
const bybit = require('../src/exchanges/bybit');
bybit.getTickers = async () => [{ symbol: 'SOLUSDT', lastPrice: '105', markPrice: '105', turnover24h: '1', fundingRate: '0' }];

const server = require('../dashboard/server');

function beat(over = {}) {
  journal.setState('robot_heartbeat', { ts: Date.now(), alive: true, pid: 1, dbPath: journal.getDbPath(), openTrades: 0, paused: false, pendingWrites: 0, ...over });
}

describe('Dashboard <-> robot sync', () => {
  let base, fakeRobot;

  before(() => new Promise(resolve => server.listen(0, () => {
    base = `http://127.0.0.1:${server.address().port}`;
    resolve();
  })));

  after(() => {
    clearInterval(fakeRobot);
    server.closeAllConnections();
    return new Promise(resolve => server.close(resolve));
  });

  it('close returns 409 (not a silent no-op) when the robot is offline', async () => {
    const res = await fetch(`${base}/api/positions/close/ANY`, { method: 'POST' });
    assert.equal(res.status, 409);
    assert.match((await res.json()).error, /not running/i);
  });

  it('summary reports OFFLINE for a stale heartbeat and RUNNING for a fresh one', async () => {
    beat({ ts: Date.now() - 120000 });
    let d = await (await fetch(`${base}/api/dashboard/summary`)).json();
    assert.equal(d.status, 'OFFLINE');
    assert.equal(d.sync.alive, false);
    beat();
    d = await (await fetch(`${base}/api/dashboard/summary`)).json();
    assert.equal(d.status, 'RUNNING');
    assert.equal(d.sync.alive, true);
    assert.equal(d.sync.dbPathMismatch, false);
  });

  it('flags a robot/dashboard open-count mismatch', async () => {
    beat({ openTrades: 3 });
    const d = await (await fetch(`${base}/api/dashboard/summary`)).json();
    assert.equal(d.sync.mismatch, true);
    beat();
  });

  it('close is executed by the robot via the command queue and the result is returned', async () => {
    beat();
    fakeRobot = setInterval(() => {
      beat();
      for (const c of journal.claimPendingCommands(10)) {
        if (c.type === 'CLOSE_POSITION') journal.completeCommand(c.id, 'DONE', { closed: { id: c.payload.id, symbol: 'SOLUSDT', exitPrice: 105, pnl: 9.9 } });
        else journal.completeCommand(c.id, 'FAILED', { error: 'No live market price for SOLUSDT — not closed' });
      }
    }, 100);
    const ok = await fetch(`${base}/api/positions/close/SOLUSDT_gps_v1_1`, { method: 'POST' });
    assert.equal(ok.status, 200);
    const body = await ok.json();
    assert.equal(body.closed.exitPrice, 105);

    const bad = await fetch(`${base}/api/positions/close-all`, { method: 'POST' });
    assert.equal(bad.status, 422);
  });

  it('SSE stream pushes robot events to the browser', async () => {
    const received = await new Promise((resolve, reject) => {
      const req = http.get(`${base}/api/stream`, res => {
        assert.match(res.headers['content-type'], /text\/event-stream/);
        let buf = '';
        res.on('data', chunk => {
          buf += chunk.toString();
          if (buf.includes('event: hello') && !buf.includes('position.closed')) {
            journal.appendEvent('position.closed', { symbol: 'SOLUSDT', trade: { symbol: 'SOLUSDT', pnl: 1.5 } });
          }
          if (buf.includes('event: position.closed')) { req.destroy(); resolve(buf); }
        });
      });
      req.on('error', e => { if (e.code !== 'ECONNRESET') reject(e); });
      setTimeout(() => { req.destroy(); reject(new Error('SSE timeout')); }, 6000);
    });
    assert.match(received, /position\.closed/);
  });

  it('/api/events/recent includes robot events stored in the journal', async () => {
    const d = await (await fetch(`${base}/api/events/recent?limit=20`)).json();
    assert.ok(d.events.some(e => e.event === 'position.closed'));
  });

  it('positions endpoint labels price source and does not break with no open trades', async () => {
    const d = await (await fetch(`${base}/api/dashboard/positions`)).json();
    assert.equal(typeof d.count, 'number');
    assert.ok('tickersStale' in d);
  });

  it('index.html is served with no-store so a stale page can never be shown', async () => {
    const res = await fetch(`${base}/`);
    assert.match(res.headers.get('cache-control'), /no-store/);
  });

  describe('chart API', () => {
    it('rejects invalid symbols', async () => {
      assert.equal((await fetch(`${base}/api/dashboard/chart/%3Cscript%3E`)).status, 400);
      assert.equal((await fetch(`${base}/api/dashboard/chart/BTC`)).status, 400);
    });

    it('returns candles with SECONDS timestamps, indicators and clamps limit', async () => {
      const d = await (await fetch(`${base}/api/dashboard/chart/SOLUSDT?interval=15m&limit=9999&indicators=ema20,vwap`)).json();
      assert.equal(d.candles[0].time, BASE / 1000);
      assert.ok(d.indicators.ema20.length > 0 && d.indicators.vwap.length === d.candles.length);
      assert.equal(d.indicators.ema50, undefined);
      assert.equal(d.levels, null);
    });

    it('supports the 1m/5m/1d intervals and falls back for unknown ones', async () => {
      for (const tf of ['1m', '5m', '1d']) {
        assert.equal((await (await fetch(`${base}/api/dashboard/chart/SOLUSDT?interval=${tf}`)).json()).interval, tf);
      }
      assert.equal((await (await fetch(`${base}/api/dashboard/chart/SOLUSDT?interval=7m`)).json()).interval, '15m');
    });

    it('incremental requests (since=) return only new candles', async () => {
      const since = BASE / 1000 + 118 * (STEP / 1000);
      const d = await (await fetch(`${base}/api/dashboard/chart/SOLUSDT?since=${since}`)).json();
      assert.equal(d.incremental, true);
      assert.equal(d.candles.length, 2);
    });

    it('open-trade levels come back as OPEN_TRADE with live PnL, trailing stop and trade markers', async () => {
      journal.savePaperTrade({
        id: 'SOLUSDT_gps_v1_77', symbol: 'SOLUSDT', strategyId: 'gps_v1', strategyName: 'GPS v1', strategyVersion: '1',
        direction: 'LONG', entry: 100, stopLoss: 101, takeProfit: 110, positionSize: 2, score: 91, riskReward: 3,
        openTime: BASE + STEP, initialRisk: 2, initialStopLoss: 98, trailingActive: true, trailingStopPrice: 101,
      });
      const d = await (await fetch(`${base}/api/dashboard/chart/SOLUSDT`)).json();
      assert.equal(d.levels.source, 'OPEN_TRADE');
      assert.equal(d.levels.unrealizedPnl, 10);          // (105-100)*2
      assert.equal(d.levels.trailingStop, 101);
      assert.equal(d.levels.trailingActive, true);
      assert.ok(d.trades.some(t => t.id === 'SOLUSDT_gps_v1_77' && t.open === true));
    });

    it('a signal-only symbol is labelled SIGNAL (never mistaken for a trade)', async () => {
      journal.saveSignal({
        id: 'sig-1', strategyId: 'gps_v1', strategyName: 'GPS v1', strategyVersion: '1', symbol: 'ETHUSDT',
        direction: 'SHORT', score: 88, entry: 200, stopLoss: 205, takeProfit: 190, riskReward: 2, conditions: {},
        qualified: true, decision: 'TRADE', timestamp: Date.now(), mode: 'PAPER',
      });
      const d = await (await fetch(`${base}/api/dashboard/chart/ETHUSDT`)).json();
      assert.equal(d.levels.source, 'SIGNAL');
    });
  });
});
