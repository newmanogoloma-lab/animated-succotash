'use strict';
const { describe, it } = require('node:test');
const assert = require('node:assert');
const { buildJournalXlsx, toRow, strategySummary } = require('../src/journal/export');

const trade = (o) => Object.assign({ id: 'T', strategy_name: 'GPS', symbol: 'SOLUSDT', direction: 'LONG', entry: 150, stop_loss: 147, initial_risk: 3, take_profit: 156, position_size: 2, score: 88, open_time: 1e12, close_time: 1e12 + 60000, outcome: 'WIN', pnl: 12, exit_price: 156 }, o);

describe('Journal Excel export', () => {
  it('computes R result from initial risk and keeps open trades blank', () => {
    assert.equal(toRow(trade({})).rResult, 2);
    const open = toRow(trade({ close_time: null, outcome: null, pnl: null }));
    assert.equal(open.status, 'OPEN');
    assert.equal(open.rResult, null);
  });
  it('summarises per strategy and overall', () => {
    const rows = [toRow(trade({})), toRow(trade({ outcome: 'LOSS', pnl: -6 }))];
    const s = strategySummary(rows);
    const all = s[s.length - 1];
    assert.equal(all.trades, 2);
    assert.equal(all.winRate, 50);
    assert.equal(all.netR, 1);
    assert.equal(all.profitFactor, 2);
  });
  it('produces a valid zip/xlsx buffer', () => {
    const buf = buildJournalXlsx([trade({})]);
    assert.equal(buf.readUInt32LE(0), 0x04034b50);
    assert.ok(buf.includes(Buffer.from('xl/worksheets/sheet2.xml')));
  });
});
