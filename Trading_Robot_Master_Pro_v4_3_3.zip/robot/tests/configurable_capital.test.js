'use strict';

/**
 * Configurable Paper Capital Tests
 *
 * Verifies that capital flows correctly through every layer:
 * Config → Risk Engine → Position Sizing → PnL → Daily Loss → Analytics
 *
 * Required presets: $50, $100, $200, $500, $1,000
 * Changing capital MUST NOT silently change the risk percentage.
 */

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const RiskEngine = require('../src/risk/engine');
const {
  calculatePortfolioMetrics,
  calculatePerformanceStats,
  calculateRiskStatus,
} = require('../src/dashboard/analytics');

// ─── Helpers ────────────────────────────────────────────────────────────────

/**
 * Build a RiskEngine config for a given capital preset.
 * risk per trade = 0.5%, daily loss = 3%.
 */
function makeRiskConfig(capital) {
  return {
    accountBalance: capital,
    riskPerTrade: 0.005,        // 0.5%
    maxDailyLoss: 0.03,         // 3.0%
    maxOpenPositions: 5,
    maxPortfolioExposure: 0.3,
    maxCorrelatedExposure: 0.2,
    maxConsecutiveLosses: 5,
  };
}

/**
 * Calculate monetary risk for a given capital + riskPerTrade.
 * This is what the risk engine computes: riskAmount = accountBalance * riskPerTrade
 */
function monetaryRisk(capital, riskPct = 0.005) {
  return capital * riskPct;
}

/**
 * Calculate monetary daily loss limit.
 */
function monetaryDailyLoss(capital, limitPct = 0.03) {
  return capital * limitPct;
}

// ─── Tests ───────────────────────────────────────────────────────────────────

describe('Configurable Paper Capital', () => {

  // ── $50 capital ──────────────────────────────────────────────────────────
  describe('$50 capital preset', () => {
    it('risk engine holds correct accountBalance', () => {
      const risk = new RiskEngine(makeRiskConfig(50));
      assert.strictEqual(risk.cfg.accountBalance, 50);
    });

    it('calculates $0.25 risk per trade at 0.5%', () => {
      const riskAmt = monetaryRisk(50);
      assert.ok(Math.abs(riskAmt - 0.25) < 0.001,
        `Expected $0.25, got $${riskAmt}`);
    });

    it('calculates $1.50 daily loss limit at 3%', () => {
      const limit = monetaryDailyLoss(50);
      assert.ok(Math.abs(limit - 1.50) < 0.001,
        `Expected $1.50, got $${limit}`);
    });

    it('calcPositionSize returns a number (position size in units)', () => {
      const risk = new RiskEngine(makeRiskConfig(50));
      const size = risk.calcPositionSize({ entry: 100, stopLoss: 90 });
      // riskAmount = 50 * 0.005 = $0.25; riskPerUnit = |100-90| = 10
      // positionSize = 0.25 / 10 = 0.025 units
      assert.strictEqual(typeof size, 'number');
      assert.ok(Math.abs(size - 0.025) < 0.0001,
        `Expected 0.025 units, got ${size}`);
    });
  });

  // ── $100 capital ─────────────────────────────────────────────────────────
  describe('$100 capital preset', () => {
    it('risk engine holds correct accountBalance', () => {
      const risk = new RiskEngine(makeRiskConfig(100));
      assert.strictEqual(risk.cfg.accountBalance, 100);
    });

    it('calculates $0.50 risk per trade at 0.5%', () => {
      const riskAmt = monetaryRisk(100);
      assert.ok(Math.abs(riskAmt - 0.50) < 0.001,
        `Expected $0.50, got $${riskAmt}`);
    });

    it('calculates $3.00 daily loss limit at 3%', () => {
      const limit = monetaryDailyLoss(100);
      assert.ok(Math.abs(limit - 3.00) < 0.001,
        `Expected $3.00, got $${limit}`);
    });

    it('calcPositionSize is 0.05 units for $100 capital (entry=100, SL=90)', () => {
      const risk = new RiskEngine(makeRiskConfig(100));
      const size = risk.calcPositionSize({ entry: 100, stopLoss: 90 });
      // riskAmount = 100 * 0.005 = $0.50; riskPerUnit = 10 → 0.05 units
      assert.ok(Math.abs(size - 0.05) < 0.0001,
        `Expected 0.05 units, got ${size}`);
    });
  });

  // ── $200 capital ─────────────────────────────────────────────────────────
  describe('$200 capital preset', () => {
    it('calculates $1.00 risk per trade at 0.5%', () => {
      const riskAmt = monetaryRisk(200);
      assert.ok(Math.abs(riskAmt - 1.00) < 0.001,
        `Expected $1.00, got $${riskAmt}`);
    });

    it('calculates $6.00 daily loss limit at 3%', () => {
      const limit = monetaryDailyLoss(200);
      assert.ok(Math.abs(limit - 6.00) < 0.001,
        `Expected $6.00, got $${limit}`);
    });
  });

  // ── $500 capital ─────────────────────────────────────────────────────────
  describe('$500 capital preset', () => {
    it('calculates $2.50 risk per trade at 0.5%', () => {
      const riskAmt = monetaryRisk(500);
      assert.ok(Math.abs(riskAmt - 2.50) < 0.001,
        `Expected $2.50, got $${riskAmt}`);
    });

    it('calculates $15.00 daily loss limit at 3%', () => {
      const limit = monetaryDailyLoss(500);
      assert.ok(Math.abs(limit - 15.00) < 0.001,
        `Expected $15.00, got $${limit}`);
    });
  });

  // ── $1,000 capital ───────────────────────────────────────────────────────
  describe('$1,000 capital preset', () => {
    it('calculates $5.00 risk per trade at 0.5%', () => {
      const riskAmt = monetaryRisk(1000);
      assert.ok(Math.abs(riskAmt - 5.00) < 0.001,
        `Expected $5.00, got $${riskAmt}`);
    });

    it('calculates $30.00 daily loss limit at 3%', () => {
      const limit = monetaryDailyLoss(1000);
      assert.ok(Math.abs(limit - 30.00) < 0.001,
        `Expected $30.00, got $${limit}`);
    });
  });

  // ── Capital flows through analytics ──────────────────────────────────────
  describe('Capital flows through analytics layer', () => {

    it('calculatePortfolioMetrics uses actual capital, not hardcoded default', () => {
      const metrics = calculatePortfolioMetrics([], 200, 10, [], 0.3);
      assert.strictEqual(metrics.startingBalance, 200);
      assert.strictEqual(metrics.currentEquity, 200);
    });

    it('calculatePortfolioMetrics startingBalance = $100 produces correct equity at rest', () => {
      const metrics = calculatePortfolioMetrics([], 100, 10, [], 0.3);
      assert.strictEqual(metrics.startingBalance, 100);
      assert.strictEqual(metrics.currentEquity, 100);
      assert.strictEqual(metrics.availableCapital, 100);
      assert.strictEqual(metrics.netPnl, 0);
    });

    it('calculatePerformanceStats uses configured capital for return metrics', () => {
      const closedTrades = [{ pnl: 3.00 }];
      const stats = calculatePerformanceStats(closedTrades, 100);
      assert.strictEqual(stats.totalTrades, 1);
      assert.strictEqual(stats.netPnl, 3.00);
    });

    it('calculateRiskStatus returns currentDailyLossPct', () => {
      const riskStatus = { dailyPnL: -3.00, killSwitch: false, tradingEnabled: true };
      const cfg = { maxDailyLoss: 0.03, maxConsecutiveLosses: 5, maxPortfolioExposure: 0.3, maxCorrelatedExposure: 0.2 };
      const result = calculateRiskStatus(riskStatus, cfg, [], 100);
      assert.ok(typeof result.currentDailyLossPct === 'number');
      // $3.00 loss on $100 account = 3.0%
      assert.ok(Math.abs(result.currentDailyLossPct - 3.0) < 0.01,
        `Expected 3.0% daily loss, got ${result.currentDailyLossPct}%`);
    });
  });

  // ── Capital isolation: changing capital does NOT change risk % ────────────
  describe('Capital isolation guarantees', () => {

    it('risk percentage stays constant when capital changes', () => {
      const r100 = new RiskEngine(makeRiskConfig(100));
      const r200 = new RiskEngine(makeRiskConfig(200));
      assert.strictEqual(r100.cfg.riskPerTrade, r200.cfg.riskPerTrade,
        'riskPerTrade % must not change when capital changes');
    });

    it('doubling capital doubles monetary risk but keeps risk% the same', () => {
      const r100 = new RiskEngine(makeRiskConfig(100));
      const r200 = new RiskEngine(makeRiskConfig(200));

      const risk100 = r100.cfg.accountBalance * r100.cfg.riskPerTrade;
      const risk200 = r200.cfg.accountBalance * r200.cfg.riskPerTrade;

      // Monetary risk doubles
      assert.ok(Math.abs(risk200 - risk100 * 2) < 0.01,
        `r200 monetary risk should be 2× r100 monetary risk. got ${risk100} vs ${risk200}`);

      // Risk % stays same
      assert.strictEqual(r100.cfg.riskPerTrade, r200.cfg.riskPerTrade);
    });

    it('5× capital produces 5× monetary risk', () => {
      const r50  = new RiskEngine(makeRiskConfig(50));
      const r250 = new RiskEngine(makeRiskConfig(250));

      const risk50  = r50.cfg.accountBalance  * r50.cfg.riskPerTrade;
      const risk250 = r250.cfg.accountBalance * r250.cfg.riskPerTrade;

      assert.ok(Math.abs(risk250 / risk50 - 5.0) < 0.01,
        `Risk should scale 5× with 5× capital. Got ${risk50} vs ${risk250}`);
    });

    it('calcPositionSize scales linearly with capital', () => {
      const r100 = new RiskEngine(makeRiskConfig(100));
      const r200 = new RiskEngine(makeRiskConfig(200));

      const signal = { entry: 100, stopLoss: 90 };
      const size100 = r100.calcPositionSize(signal);
      const size200 = r200.calcPositionSize(signal);

      assert.ok(Math.abs(size200 / size100 - 2.0) < 0.001,
        `Position size should double when capital doubles. got ${size100} vs ${size200}`);
    });
  });
});
