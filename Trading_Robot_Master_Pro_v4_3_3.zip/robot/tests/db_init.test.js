'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');

// Each scenario runs in a child process with its own ROBOT_DATA_DIR (store.js resolves the path at load time)
function run(dir, code) {
  const r = spawnSync(process.execPath, ['-e', code], {
    cwd: ROOT, env: { ...process.env, ROBOT_DATA_DIR: dir, NODE_NO_WARNINGS: '1' }, encoding: 'utf8',
  });
  return { out: (r.stdout || '').trim(), err: (r.stderr || '').trim(), status: r.status };
}
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'robotdb-'));
const CHECK = "const s=require('./src/journal/store');const r=s.checkDb();console.log(JSON.stringify({m:r.missing,i:r.integrity}))";

test('fresh data dir creates every required table', () => {
  const r = run(tmp(), CHECK);
  assert.strictEqual(r.status, 0, r.err);
  assert.deepStrictEqual(JSON.parse(r.out), { m: [], i: 'ok' });
});

test('empty 0-byte robot.db is initialised', () => {
  const d = tmp(); fs.writeFileSync(path.join(d, 'robot.db'), '');
  assert.strictEqual(run(d, CHECK).status, 0);
});

test('DB missing paper_trades (old/partial file) is repaired', () => {
  const d = tmp();
  const mk = "const {DatabaseSync}=require('node:sqlite');const x=new DatabaseSync(process.env.ROBOT_DATA_DIR+'/robot.db');x.exec('CREATE TABLE strategies(id TEXT PRIMARY KEY,name TEXT)');x.close();";
  assert.strictEqual(run(d, mk).status, 0);
  const r = run(d, CHECK);
  assert.strictEqual(r.status, 0, r.err);
  assert.deepStrictEqual(JSON.parse(r.out).m, []);
});

test('garbage (non-SQLite) file is quarantined, not deleted', () => {
  const d = tmp(); fs.writeFileSync(path.join(d, 'robot.db'), 'this is not sqlite '.repeat(200));
  const r = run(d, CHECK);
  assert.strictEqual(r.status, 0, r.err);
  assert.ok(fs.readdirSync(d).some(f => f.includes('.corrupt-')), 'old file kept as .corrupt-*');
});

test('a failed init is never cached: next getDb() retries instead of returning a schema-less handle', () => {
  const code = `
    const fs=require('fs');
    const real=fs.existsSync;
    const s=require('./src/journal/store');
    // inject one failure inside the first init attempt (busy-style error => retry path)
    const sqlite=require('node:sqlite');
    const Orig=sqlite.DatabaseSync; let n=0;
    sqlite.DatabaseSync=class extends Orig{ exec(sql){ if(n++===3) throw new Error('database is locked'); return super.exec(sql);} };
    try{ s.getPaperTrades? s.getPaperTrades(1):0; }catch(e){}
    const r=s.checkDb(); console.log(JSON.stringify(r.missing));
  `;
  const r = run(tmp(), code);
  assert.strictEqual(r.out.split('\n').pop(), '[]', r.err);
});

test('.env loader strips inline comments', () => {
  const code = "process.chdir('/');const c=require('./src/config');console.log(String(process.env.STRATEGY_MODE))";
  const d = tmp();
  const envFile = path.join(ROOT, '.env');
  const had = fs.existsSync(envFile) ? fs.readFileSync(envFile, 'utf8') : null;
  try {
    fs.writeFileSync(envFile, 'STRATEGY_MODE=ALL            # ALL = every strategy\n');
    const r = spawnSync(process.execPath, ['-e', code], { cwd: ROOT, env: { PATH: process.env.PATH, ROBOT_DATA_DIR: d }, encoding: 'utf8' });
    assert.strictEqual(r.stdout.trim(), 'ALL');
  } finally {
    if (had === null) fs.unlinkSync(envFile); else fs.writeFileSync(envFile, had);
  }
});
