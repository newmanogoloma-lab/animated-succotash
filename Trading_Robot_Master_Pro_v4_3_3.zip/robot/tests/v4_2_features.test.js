'use strict';

// v4.2: 10+ concurrent positions @1.5% risk, all-strategies mode, FILL tier, orphan-close fix, latest-scan query
const os = require('os');
const fs = require('fs');
const path = require('path');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'gps-v42-'));
process.env.ROBOT_DATA_DIR = TMP;

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const config = require('../src/config');
const journal = require('../src/journal/store');
const RiskEngine = require('../src/risk/engine');
const PaperEngine = require('../src/paper/engine');
const StrategyRouter = require('../src/strategy/router');
const TradingRobot = require('../src/robot');

const sig = (symbol, over = {}) => ({
  symbol, strategyId: 'gps_v1', strategyName: 'GPS', strategyVersion: '1', direction: 'LONG',
  entry: 100, stopLoss: 98, takeProfit: 106, riskReward: 3, score: 90, decision: 'TRADE', tier: 'QUALIFIED',
  timestamp: Date.now(), ...over,
});

describe('v4.2 defaults', () => {
  it('risk >= 1.5%, room for 10+ positions, ALL strategy mode', () => {
    assert.ok(config.riskPerTrade >= 0.015);
    assert.equal(config.maxOpenPositions, 0, '0 = unlimited positions');
    assert.equal(config.maxPortfolioExposure, 0, '0 = unlimited exposure');
    assert.equal(config.maxDailyLoss, 0);
    assert.equal(config.fillToTarget, false, 'only setups >= minScore trade');
    assert.equal(config.minScore, 85);
    assert.equal(config.strategyMode, 'ALL');
    assert.equal(config.exposureBasis, 'margin');
  });
});

describe('10+ concurrent positions @ 1.5% risk on a $100 account', () => {
  it('risk engine approves 12 distinct-symbol trades (margin exposure basis)', () => {
    const risk = new RiskEngine({ accountBalance: 100, riskPerTrade: 0.015, maxOpenPositions: 12, leverage: 10 });
    const open = [];
    for (let i = 0; i < 12; i++) {
      const s = sig(`COIN${i}USDT`);
      const r = risk.check(s, open);
      assert.equal(r.approved, true, `trade ${i + 1} rejected: ${r.reason}`);
      assert.ok(Math.abs(r.riskAmount - 1.5) < 1e-9);
      open.push({ symbol: s.symbol, positionSize: r.positionSize, entry: s.entry });
      risk.onPositionOpened(r.positionSize * s.entry, s.symbol);
    }
    assert.equal(risk.check(sig('EXTRAUSDT'), open).approved, false, '13th must hit MAX_POSITIONS');
  });

  it('the OLD notional basis really did cap this account at ~1 position (regression proof)', () => {
    const risk = new RiskEngine({ accountBalance: 100, riskPerTrade: 0.015, maxOpenPositions: 12, exposureBasis: 'notional', maxPortfolioExposure: 0.3 });
    const r1 = risk.check(sig('AUSDT'), []);
    assert.equal(r1.approved, false);
  });

  it('paper engine opens 10 positions, one per symbol, and blocks a second strategy on the same symbol', () => {
    const eng = new PaperEngine({}, { accountBalance: 100, riskPerTrade: 0.015, maxOpenPositions: 12, leverage: 10 });
    for (let i = 0; i < 10; i++) assert.equal(eng.openFromSignal(sig(`C${i}USDT`)).action, 'OPENED');
    assert.equal(eng.openTrades.size, 10);
    const dup = eng.openFromSignal(sig('C0USDT', { strategyId: 'breakout_v1', timestamp: Date.now() + 120000 }));
    assert.equal(dup.reason, 'SYMBOL_ALREADY_OPEN');
  });
});

describe('FILL tier', () => {
  it('score 75-84 with valid levels + R:R is a FILL setup, below 75 is not', () => {
    const eng = new PaperEngine();
    const prevFill = config.fillToTarget; config.fillToTarget = true;
    assert.equal(eng.classify({ ...sig('XUSDT'), score: 79, decision: 'NO_TRADE' }).tier, 'FILL');
    assert.equal(eng.classify({ ...sig('XUSDT'), score: 60, decision: 'NO_TRADE' }).tier, null);
    assert.equal(eng.classify({ ...sig('XUSDT'), score: 90, decision: 'NO_TRADE', criticalFail: 'X' }).tier, null);
    assert.equal(eng.classify(sig('XUSDT')).tier, 'QUALIFIED');
    config.fillToTarget = false;
    assert.equal(eng.classify({ ...sig('XUSDT'), score: 79, decision: 'NO_TRADE' }).tier, null, 'fill is OFF by default');
    config.fillToTarget = prevFill;
  });
});

describe('all strategies active at once', () => {
  it('ALL mode runs every enabled strategy regardless of regime; ROUTED mode does not', async () => {
    const ids = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'];
    const calls = [];
    const strategies = new Map(ids.map(id => [id, { id, enabled: true, evaluate: (m) => { calls.push(id); return { strategyId: id, symbol: m.symbol, qualified: false, score: 10 }; } }]));
    const registry = { getEnabled: () => [...strategies.values()], get: (id) => strategies.get(id) };
    const router = new StrategyRouter(registry);
    const data = { symbol: 'TESTUSDT', candles4H: [], candles1H: [], candles15M: [] };
    const prev = config.strategyMode;
    try {
      config.strategyMode = 'ALL';
      const res = await router.routeAndEvaluate(data);
      assert.equal(res.length, 9);
      assert.equal(new Set(calls).size, 9);
    } finally { config.strategyMode = prev; }
  });

  it('opposing signals: clearly stronger side survives, near-tie stands aside', async () => {
    const mk = (id, dir, score) => ({ id, enabled: true, evaluate: (m) => ({ strategyId: id, symbol: m.symbol, direction: dir, qualified: true, score }) });
    const run = async (a, b) => {
      const m = new Map([['a', mk('a', 'LONG', a)], ['b', mk('b', 'SHORT', b)]]);
      const router = new StrategyRouter({ getEnabled: () => [...m.values()], get: (id) => m.get(id) });
      return router.routeAndEvaluate({ symbol: 'T', candles4H: [], candles1H: [], candles15M: [] });
    };
    const strong = await run(95, 80);
    assert.deepEqual(strong.filter(r => r.qualified).map(r => r.direction), ['LONG']);
    const tie = await run(90, 88);
    assert.equal(tie.filter(r => r.qualified).length, 0);
  });
});

describe('unlimited positions / risk and account reset', () => {
  it('opens 40 positions with no cap, and rejects a stop beyond the liquidation guard', () => {
    const eng = new PaperEngine({}, { accountBalance: 100, riskPerTrade: 0.015, leverage: 10 });
    for (let i = 0; i < 40; i++) assert.equal(eng.openFromSignal(sig(`U${i}USDT`)).action, 'OPENED');
    assert.equal(eng.openTrades.size, 40);
    const far = eng.openFromSignal(sig('FARUSDT', { stopLoss: 88 })); // 12% stop at 10x (liq ~9.5%)
    assert.match(far.reason, /LIQUIDATION/);
  });

  it('equity sizing: risk % applies to the current balance', () => {
    const eng = new PaperEngine({}, { accountBalance: 100, riskPerTrade: 0.015, leverage: 10 });
    eng.balance = 50;
    const r = eng.openFromSignal(sig('EQUSDT'));
    assert.ok(Math.abs(r.trade.positionSize * 2 - 0.75) < 1e-6, 'risk = 1.5% of $50 = $0.75');
  });

  it('depleted balance blocks new trades; resetAccount restores trading at any balance', () => {
    const eng = new PaperEngine({}, { accountBalance: 100, riskPerTrade: 0.015, leverage: 10 });
    eng.balance = 0;
    assert.match(eng.openFromSignal(sig('DEPUSDT')).reason, /ACCOUNT_DEPLETED/);
    eng.balance = 100;
    eng.openFromSignal(sig('RSTUSDT'));
    const closed = eng.resetAccount(1500, () => 101);
    assert.equal(closed.length, 1);
    assert.equal(eng.balance, 1500);
    assert.equal(eng.openTrades.size, 0);
    const r = eng.openFromSignal(sig('NEWUSDT', { timestamp: Date.now() + 999999 }));
    assert.ok(Math.abs(r.trade.positionSize * 2 - 22.5) < 1e-6, '1.5% of $1500 = $22.50');
  });

  it('free-margin enforcement is optional (paper off, on when requested)', () => {
    const off = new PaperEngine({}, { accountBalance: 100, riskPerTrade: 0.015, leverage: 10 });
    for (let i = 0; i < 20; i++) off.openFromSignal(sig(`M${i}USDT`));
    assert.equal(off.openTrades.size, 20);
    const on = new PaperEngine({}, { accountBalance: 100, riskPerTrade: 0.015, leverage: 10, enforceFreeMargin: true });
    for (let i = 0; i < 20; i++) on.openFromSignal(sig(`M${i}USDT`));
    assert.equal(on.openTrades.size, 13, '$7.50 margin each -> 13 fit in $100');
  });
});

describe('close-position "not found" fix', () => {
  it('re-attaches an open journal row the robot lost from memory, then closes it at the live price', async () => {
    const openTime = Date.now() - 60000;
    journal.savePaperTrade({
      id: `ORPHANUSDT_vwap_structure_v1_${openTime}`, symbol: 'ORPHANUSDT', strategyId: 'vwap_structure_v1',
      strategyName: 'VWAP Structure', strategyVersion: '1.0.0', direction: 'LONG', entry: 10, stopLoss: 9.5, takeProfit: 11.5,
      positionSize: 20, score: 88, riskReward: 3, cluster: 'ALT_GENERAL', openTime, initialRisk: 0.5, initialStopLoss: 9.5,
    });
    const robot = new TradingRobot();
    robot._getTickerMap = async () => ({ ORPHANUSDT: { lastPrice: 10.4, markPrice: 10.4 } });
    robot.notifier = { notifyTradeClosed: async () => {} };
    assert.equal(robot.paperEngine.getOpenTrades().length, 0, 'not in memory');
    const out = await robot._executeCommand({ type: 'CLOSE_POSITION', payload: { id: `ORPHANUSDT_vwap_structure_v1_${openTime}` } });
    assert.equal(out.closed.symbol, 'ORPHANUSDT');
    assert.ok(out.closed.pnl > 0);
    assert.equal(journal.getOpenPaperTrades().filter(r => r.symbol === 'ORPHANUSDT').length, 0);
  });

  it('a genuinely closed id gives a clear message, not a strategy-name "not found"', async () => {
    const robot = new TradingRobot();
    await assert.rejects(() => robot._executeCommand({ type: 'CLOSE_POSITION', payload: { id: 'NOPE_vwap_structure_v1_1' } }), /not open/);
  });
});

describe('latest-scan signals (scanner page was empty)', () => {
  it('returns the newest scan only, qualified/fill first, then by score', () => {
    const old = Date.now() - 3600000, now = Date.now();
    journal.saveSignal({ ...sig('OLDUSDT'), timestamp: old });
    journal.saveSignal({ ...sig('LOWUSDT', { score: 40, decision: 'NO_TRADE', qualified: false }), timestamp: now });
    journal.saveSignal({ ...sig('FILLUSDT', { score: 78, decision: 'FILL', qualified: false }), timestamp: now });
    journal.saveSignal({ ...sig('TOPUSDT', { score: 92, qualified: true }), timestamp: now });
    const rows = journal.getLatestScanSignals(10).map(r => r.symbol);
    assert.ok(!rows.includes('OLDUSDT'));
    assert.deepEqual(rows.slice(0, 3), ['TOPUSDT', 'FILLUSDT', 'LOWUSDT']);
  });
});
