'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const { validateMarketData } = require('../src/market/dataQuality');

describe('Data-Quality Firewall', () => {
  const createMockCandles = (count, startPrice = 100) => {
    const candles = [];
    let price = startPrice;
    for (let i = 0; i < count; i++) {
      const open = price;
      const close = price + 1;
      const high = close + 0.5;
      const low = open - 0.5;
      candles.push({
        time: 1700000000000 + i * 900000,
        open, high, low, close,
        volume: 1000,
      });
      price = close;
    }
    return candles;
  };

  test('passes on valid multi-timeframe datasets', () => {
    const res = validateMarketData({
      symbol: 'SOLUSDT',
      candles4H: createMockCandles(40),
      candles1H: createMockCandles(40),
      candles15M: createMockCandles(30),
    });
    assert.equal(res.valid, true);
    assert.equal(res.reason, null);
  });

  test('blocks on insufficient candle history', () => {
    const res = validateMarketData({
      symbol: 'SOLUSDT',
      candles4H: createMockCandles(10), // less than minimum 30
      candles1H: createMockCandles(40),
      candles15M: createMockCandles(30),
    });
    assert.equal(res.valid, false);
    assert.ok(res.reason.includes('DATA_QUALITY_BLOCK: Insufficient 4H history'));
  });

  test('blocks on impossible OHLC geometry (high < low)', () => {
    const candles = createMockCandles(40);
    candles[15].high = 50;
    candles[15].low = 80; // impossible: high < low

    const res = validateMarketData({
      symbol: 'SOLUSDT',
      candles4H: candles,
      candles1H: createMockCandles(40),
      candles15M: createMockCandles(30),
    });
    assert.equal(res.valid, false);
    assert.ok(res.reason.includes('Impossible OHLC'));
  });

  test('blocks on duplicate timestamps', () => {
    const candles = createMockCandles(40);
    candles[10].time = candles[9].time; // duplicate

    const res = validateMarketData({
      symbol: 'SOLUSDT',
      candles4H: createMockCandles(40),
      candles1H: candles,
      candles15M: createMockCandles(30),
    });
    assert.equal(res.valid, false);
    assert.ok(res.reason.includes('duplicate timestamp') || res.reason.includes('Non-chronological'));
  });

  test('blocks on negative volume or NaN values', () => {
    const candles = createMockCandles(30);
    candles[5].volume = -100;

    const res = validateMarketData({
      symbol: 'SOLUSDT',
      candles4H: createMockCandles(40),
      candles1H: createMockCandles(40),
      candles15M: candles,
    });
    assert.equal(res.valid, false);
    assert.ok(res.reason.includes('Invalid non-numeric or non-positive OHLCV'));
  });
});
