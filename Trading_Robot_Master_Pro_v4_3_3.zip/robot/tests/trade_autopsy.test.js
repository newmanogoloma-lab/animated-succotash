'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { TradeAutopsyEngine } = require('../src/learning/autopsy');
const journal = require('../src/journal/store');

describe('Trade Autopsy & Memory Learning Engine', () => {

  const engine = new TradeAutopsyEngine();

  it('performs diagnostic autopsy on a winning trade with MFE/MAE calculation', () => {
    const trade = {
      id: 'trade-win-101',
      symbol: 'SOLUSDT',
      strategyId: 'gps_v1',
      direction: 'LONG',
      entry: 100,
      stopLoss: 90,
      takeProfit: 120,
      exitPrice: 120,
      positionSize: 1,
      pnl: 20,
      outcome: 'WIN',
      exitReason: 'TAKE_PROFIT_HIT',
      regime: 'STRONG_TREND',
    };

    const candles = [
      { high: 102, low: 98 },
      { high: 110, low: 99 },
      { high: 122, low: 108 },
    ];

    const autopsy = engine.diagnoseTrade(trade, candles);

    assert.equal(autopsy.tradeId, 'trade-win-101');
    assert.equal(autopsy.outcome, 'WIN');
    assert.equal(autopsy.rMultiple, 2.0); // 20 / 10 = 2R
    assert.equal(autopsy.mfe, 22);        // 122 - 100 = 22
    assert.equal(autopsy.mae, 2);         // 100 - 98 = 2
    assert.equal(autopsy.mfeR, 2.2);      // 22 / 10 = 2.2R
    assert.equal(autopsy.maeR, 0.2);      // 2 / 10 = 0.2R
  });

  it('diagnoses stop loss tightness when trade reached > 1.2R before stopping out', () => {
    const trade = {
      id: 'trade-loss-tight',
      symbol: 'BTCUSDT',
      strategyId: 'breakout_v1',
      direction: 'LONG',
      entry: 60000,
      stopLoss: 59000,
      takeProfit: 63000,
      exitPrice: 59000,
      positionSize: 0.1,
      pnl: -100,
      outcome: 'LOSS',
      exitReason: 'STOP_LOSS_HIT',
      regime: 'BREAKOUT',
    };

    const candles = [
      { high: 61500, low: 59800 }, // MFE = 1500 (1.5R)
      { high: 60500, low: 58900 }, // stopped out
    ];

    const autopsy = engine.diagnoseTrade(trade, candles);
    assert.equal(autopsy.slTightness, 'TOO_TIGHT');
    assert.ok(autopsy.lessons.length > 0);
  });

  it('diagnoses trailing stop efficiency when trailing stop secured profit', () => {
    const trade = {
      id: 'trade-trailing-win',
      symbol: 'ETHUSDT',
      strategyId: 'pullback_v1',
      direction: 'LONG',
      entry: 2500,
      stopLoss: 2450,
      takeProfit: 2650,
      exitPrice: 2570,
      positionSize: 1,
      pnl: 70,
      outcome: 'WIN',
      exitReason: 'TRAILING_STOP_HIT',
      regime: 'PULLBACK',
    };

    const autopsy = engine.diagnoseTrade(trade);
    assert.equal(autopsy.trailingEfficiency, 'PROTECTIVE');
    assert.ok(autopsy.lessons.some(l => l.includes('Trailing stop successfully secured profit')));
  });

  it('saves and retrieves autopsy records from SQLite store', () => {
    const stored = journal.getAutopsies(10);
    assert.ok(stored.length > 0, 'Should have saved autopsies');
    const specific = journal.getAutopsyByTradeId('trade-win-101');
    assert.ok(specific, 'Should find autopsy by trade_id');
    assert.equal(specific.symbol, 'SOLUSDT');
  });

  it('similarity engine provides historical setup context', () => {
    const opp = {
      symbol: 'SOLUSDT',
      strategyId: 'gps_v1',
      direction: 'LONG',
      regime: 'STRONG_TREND',
    };

    const sim = engine.findSimilarSetups(opp);
    assert.ok(typeof sim.sampleSize === 'number');
    assert.ok(typeof sim.winRate === 'number');
    assert.ok(sim.recommendation);
  });
});
