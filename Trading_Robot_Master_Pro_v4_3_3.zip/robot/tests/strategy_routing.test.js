'use strict';

const { describe, it, after } = require('node:test');
const assert = require('node:assert');
const { StrategyRouter } = require('../src/strategy/registry');

describe('Strategy Router', () => {
  let router;

  function setup() {
    const { createDefaultRegistry } = require('../src/strategy/registry');
    const registry = createDefaultRegistry();
    router = new StrategyRouter(registry);
  }

  it('routes STRONG_TREND to GPS + Pullback strategies', () => {
    setup();
    const strategyIds = router.getStrategiesForRegime({ canonicalRegime: 'STRONG_TREND', regime: 'TRENDING_UP' });
    assert.ok(Array.isArray(strategyIds), 'strategies should be an array');
    assert.ok(strategyIds.length > 0, 'should route to at least one strategy');
    assert.ok(strategyIds.includes('gps_v1') && strategyIds.includes('pullback_v1'),
      `Expected gps_v1 and pullback_v1 in [${strategyIds.join(', ')}]`);
  });

  it('routes RANGE to MeanReversion strategy', () => {
    setup();
    const strategyIds = router.getStrategiesForRegime({ canonicalRegime: 'RANGE', regime: 'RANGING' });
    assert.ok(strategyIds.includes('mean_reversion_v1'),
      `Expected mean_reversion_v1 in [${strategyIds.join(', ')}]`);
  });

  it('routes BREAKOUT to Breakout strategy', () => {
    setup();
    const strategyIds = router.getStrategiesForRegime({ canonicalRegime: 'BREAKOUT', regime: 'HIGH_VOLATILITY' });
    assert.ok(strategyIds.includes('breakout_v1'),
      `Expected breakout_v1 in [${strategyIds.join(', ')}]`);
  });

  it('returns empty array (NO_TRADE) for UNCLEAR regime', () => {
    setup();
    const strategyIds = router.getStrategiesForRegime({ canonicalRegime: 'UNCLEAR', regime: 'UNCERTAIN' });
    assert.strictEqual(strategyIds.length, 0, 'Expected empty strategies for UNCLEAR regime');
  });

  it('routeAndEvaluate emits explicit NO_TRADE for unclear regime (ROUTED mode)', async () => {
    setup();
    const cfg = require('../src/config');
    const prev = cfg.strategyMode; cfg.strategyMode = 'ROUTED';
    after(() => { cfg.strategyMode = prev; });
    const result = await router.routeAndEvaluate({
      symbol: 'TESTUSDT',
      candles4H: [],
      candles1H: [],
      candles15M: [],
    });
    assert.ok(Array.isArray(result), 'result should be an array');
    assert.strictEqual(result[0].qualified, false);
    assert.ok(result[0].criticalFail === 'UNCLEAR_REGIME' || result[0].rejectionReason);
  });

  it('handles all canonical regimes without throwing', () => {
    setup();
    const regimes = ['STRONG_TREND', 'WEAK_TREND', 'RANGE', 'BREAKOUT', 'PULLBACK', 'COMPRESSION', 'UNCLEAR'];
    for (const r of regimes) {
      const ids = router.getStrategiesForRegime({ canonicalRegime: r, regime: r });
      assert.ok(Array.isArray(ids), `Expected strategies array for ${r}`);
    }
  });
});
