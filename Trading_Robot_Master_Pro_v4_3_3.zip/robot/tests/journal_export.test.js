'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert');
const journal = require('../src/journal/store');

describe('Journal Store & Persistence', () => {

  it('getDb initializes and returns a valid database handle', () => {
    const db = journal.getDb();
    assert.ok(db, 'getDb should return database handle');
  });

  it('can save and retrieve a paper trade', () => {
    const trade = {
      id: `TEST_TRADE_${Date.now()}`,
      strategyId: 'gps_v1',
      strategyName: 'GPS Strategy',
      strategyVersion: '1.0.0',
      symbol: 'BTCUSDT',
      direction: 'LONG',
      entry: 50000,
      stopLoss: 49500,
      takeProfit: 51000,
      positionSize: 0.001,
      score: 88,
      riskReward: 2.0,
      regime: 'TRENDING_UP',
      cluster: 'LAYER_1',
      mode: 'PAPER',
      openTime: Date.now(),
    };

    journal.savePaperTrade(trade);
    const openTrades = journal.getOpenPaperTrades();
    assert.ok(Array.isArray(openTrades), 'getOpenPaperTrades should return array');
    assert.ok(openTrades.some(t => t.id === trade.id), 'Saved trade should be found in open paper trades');
  });

  it('saveScanSession stores session and getLatestScanSession retrieves it', () => {
    const sessionId = `scan_sess_${Date.now()}`;
    journal.saveScanSession({
      id: sessionId,
      sessionId,
      status: 'RUNNING',
      startedAt: Date.now(),
      updatedAt: Date.now(),
      currentAssetClass: 'CRYPTO',
      currentInstrument: 'SOLUSDT',
      totalMarkets: 200,
      analyzedCount: 50,
      remainingCount: 150,
      qualifiedCount: 3,
      rejectedCount: 47,
      errorCount: 0,
      completedSymbols: ['BTCUSDT', 'ETHUSDT'],
      failedSymbols: [],
      qualifiedSetups: [],
      config: { batchSize: 5 },
    });

    const latest = journal.getLatestScanSession();
    assert.ok(latest, 'getLatestScanSession should return an object');
    assert.strictEqual(latest.id, sessionId);
    assert.strictEqual(latest.status, 'RUNNING');
    assert.strictEqual(latest.analyzedCount, 50);
  });

  it('saveSnapshot stores command center state and getSnapshots retrieves it', () => {
    const snapshotId = `snap_${Date.now()}`;
    journal.saveSnapshot({
      id: snapshotId,
      timestamp: Date.now(),
      accountState: { equity: 100, balance: 100 },
      positions: [],
      scannerState: { status: 'RUNNING' },
      topOpportunities: [{ symbol: 'BTCUSDT', score: 90 }],
      riskSettings: { riskPerTrade: 0.005 },
      summary: 'Automated test snapshot',
    });

    const snapshots = journal.getSnapshots();
    assert.ok(Array.isArray(snapshots), 'getSnapshots should return an array');
    assert.ok(snapshots.some(s => s.id === snapshotId), 'Saved snapshot should be in list');

    const single = journal.getSnapshot(snapshotId);
    assert.ok(single, 'getSnapshot should return single snapshot');
    assert.strictEqual(single.id, snapshotId);
    assert.strictEqual(single.summary, 'Automated test snapshot');
  });
});
