'use strict';

// v4.3: websocket client + Bybit stream, sim exchange, microstructure, validator, live stats, dataFeed cache
const os = require('os');
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'gps-v43-'));
process.env.ROBOT_DATA_DIR = TMP;

const { describe, it, after } = require('node:test');
const assert = require('node:assert/strict');
const MiniWebSocket = require('../src/exchanges/ws/miniws');
const { BybitPublicStream } = require('../src/exchanges/ws/bybitStream');
const sim = require('../src/exchanges/sim');
const micro = require('../src/market/microstructure');
const { stats, monteCarlo } = require('../src/validation/metrics');
const { computeLiveStats } = require('../src/validation/liveStats');
const { validate, aggregate, simulate } = require('../src/validation/validator');
const { liquidationPrice } = require('../src/risk/engine');
const exchange = require('../src/exchanges');
const dataFeed = require('../src/market/dataFeed');

// ── tiny RFC6455 server (text frames only) ──
function frame(str) { const p = Buffer.from(str); const h = p.length < 126 ? Buffer.from([0x81, p.length]) : Buffer.from([0x81, 126, p.length >> 8, p.length & 255]); return Buffer.concat([h, p]); }
function decode(buf) { // client->server masked frames, returns [texts]
  const out = []; let o = 0;
  while (o + 6 <= buf.length) {
    let len = buf[o + 1] & 0x7f, off = o + 2;
    if (len === 126) { len = buf.readUInt16BE(off); off += 2; }
    const mask = buf.slice(off, off + 4); off += 4;
    const p = Buffer.from(buf.slice(off, off + len)); for (let i = 0; i < p.length; i++) p[i] ^= mask[i & 3];
    if ((buf[o] & 0x0f) === 1) out.push(p.toString()); o = off + len;
  }
  return out;
}
function startServer(onMsg) {
  const sockets = new Set();
  const server = http.createServer();
  server.on('upgrade', (req, sock) => {
    const accept = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
    sock.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
    sockets.add(sock); sock.on('close', () => sockets.delete(sock)); sock.on('error', () => {});
    sock.on('data', (d) => decode(d).forEach(m => onMsg(JSON.parse(m), (obj) => sock.write(frame(JSON.stringify(obj))))));
  });
  return new Promise(r => server.listen(0, '127.0.0.1', () => r({ server, port: server.address().port, sockets })));
}
const wait = (ms) => new Promise(r => setTimeout(r, ms));

describe('WebSocket client + Bybit public stream', () => {
  it('handshakes, merges ticker snapshot+delta, applies order-book deltas, reconnects and resubscribes', async () => {
    const subs = [];
    const { server, port, sockets } = await startServer((m, reply) => {
      if (m.op === 'subscribe') {
        subs.push(...m.args);
        for (const t of m.args) {
          if (t.startsWith('tickers.')) { reply({ topic: t, type: 'snapshot', ts: Date.now(), data: { symbol: 'AAAUSDT', lastPrice: '100', markPrice: '99.9', fundingRate: '0.0001' } }); reply({ topic: t, type: 'delta', ts: Date.now(), data: { symbol: 'AAAUSDT', lastPrice: '101.5' } }); }
          if (t.startsWith('orderbook.')) { reply({ topic: t, type: 'snapshot', ts: Date.now(), data: { s: 'AAAUSDT', b: [['100', '5'], ['99.9', '7']], a: [['100.1', '4']], u: 1 } }); reply({ topic: t, type: 'delta', ts: Date.now(), data: { s: 'AAAUSDT', b: [['100', '0'], ['99.95', '3']], a: [], u: 2 } }); }
        }
      }
    });
    const st = new BybitPublicStream({ url: `ws://127.0.0.1:${port}/`, Impl: MiniWebSocket });
    st.sock.minBackoffMs = 50;
    st.start();
    st.subscribe(['tickers.AAAUSDT', 'orderbook.50.AAAUSDT']);
    await wait(400);
    assert.equal(st.getTicker('AAAUSDT').lastPrice, '101.5');
    assert.equal(st.getTicker('AAAUSDT').markPrice, '99.9', 'delta must not erase unchanged fields');
    const book = st.getBook('AAAUSDT');
    assert.deepEqual(book.bids.map(b => b[0]), ['99.95', '99.9']);
    // drop connection -> reconnect + resubscribe
    const before = subs.length;
    sockets.forEach(s => s.destroy());
    await wait(900);
    assert.ok(st.sock.connected, 'reconnected');
    assert.ok(subs.length > before, 'resubscribed after reconnect');
    assert.ok(st.status().reconnects >= 1);
    st.stop(); server.close();
  });
});

describe('simulated exchange + facade', () => {
  it('is deterministic and Bybit-shaped', async () => {
    const a = await sim.getKlines('SOLUSDT', '15', 50, null, Date.UTC(2026, 5, 1));
    const b = await sim.getKlines('SOLUSDT', '15', 50, null, Date.UTC(2026, 5, 1));
    assert.deepEqual(a, b);
    assert.ok(a.every(c => c.high >= Math.max(c.open, c.close) && c.low <= Math.min(c.open, c.close)));
    const h4 = await sim.getKlines('SOLUSDT', '240', 10, null, Date.UTC(2026, 5, 1));
    assert.equal(h4[1].time - h4[0].time, 4 * 3600000);
    const t = await sim.getTickers(); assert.ok(t.length >= 3 && Number(t[0].turnover24h) > 1e6);
    const ob = await sim.getOrderBook('SOLUSDT'); assert.ok(ob.bids.length === 50 && +ob.bids[0][0] < +ob.asks[0][0]);
  });
  it('facade delegates to the active adapter and has safe fallbacks', async () => {
    assert.equal(exchange.name, 'bybit');
    exchange._use({ getKlines: async () => ['stub'] });
    assert.deepEqual(await exchange.getKlines('X', '15', 1), ['stub']);
    assert.equal(await exchange.getOrderBook('X'), null);        // optional method falls back
    await assert.rejects(async () => exchange.getInstruments(), /does not implement/);
    exchange._use(null);
  });
});

describe('microstructure', () => {
  const book = { bids: [['99.99', 10], ['99.5', 100]], asks: [['100.01', 10], ['100.5', 100]] };
  it('computes spread, depth, slippage and imbalance', () => {
    const m = micro.analyzeBook(book, 'LONG', 500);
    assert.ok(Math.abs(m.spreadBps - 2) < 0.1);
    assert.ok(m.slipBps < 5 && m.depthUsd > 1000);
    assert.equal(micro.analyzeBook(book, 'LONG', 1e9).slipBps, 999, 'order bigger than the book');
  });
  it('funding and open-interest momentum', () => {
    assert.equal(micro.fundingMomentum([{ fundingRate: '0.0008' }, { fundingRate: '0.0004' }, { fundingRate: '0.0001' }]).crowded, 'LONG');
    assert.equal(micro.fundingMomentum([{ fundingRate: '0.0008' }, { fundingRate: '0.0004' }, { fundingRate: '0.0001' }]).trend, 'RISING');
    assert.equal(micro.oiMomentum([{ openInterest: '120' }, { openInterest: '100' }]).trend, 'BUILDING');
  });
  it('vetoes a thin book via the sim exchange; passes a tiny order', async () => {
    exchange._use(sim);
    try {
      const big = await micro.evaluate('SOLUSDT', 'LONG', 5e8);
      assert.equal(big.ok, false);
      const small = await micro.evaluate('ETHUSDT', 'LONG', 50);
      assert.equal(small.ok, true, small.vetoes.join());
    } finally { exchange._use(null); }
  });
});

describe('liquidation price', () => {
  it('10x long liquidates ~9.5% below entry, short ~9.5% above', () => {
    assert.ok(Math.abs(liquidationPrice('LONG', 100, 10, 0.005) - 90.5) < 1e-9);
    assert.ok(Math.abs(liquidationPrice('SHORT', 100, 10, 0.005) - 109.5) < 1e-9);
  });
});

describe('validation toolkit', () => {
  it('stats / monteCarlo are sane', () => {
    const s = stats([{ netR: 2, exitTime: 1 }, { netR: -1, exitTime: 2 }, { netR: 2, exitTime: 3 }, { netR: -1, exitTime: 4 }]);
    assert.equal(s.trades, 4); assert.equal(s.winRate, 50); assert.equal(s.expectancyR, 0.5); assert.equal(s.profitFactor, 2); assert.equal(s.maxDrawdownR, 1);
    const mc = monteCarlo(Array(60).fill(0).map((_, i) => (i % 3 ? 1 : -1)), { sims: 200, riskPct: 0.01 });
    assert.ok(mc.finalEquity.p50 > 1 && mc.fan.p50.length > 10 && mc.probProfit > 50);
    assert.equal(monteCarlo([1, 2], {}), null);
  });
  it('aggregate() buckets 15m into 1h without look-ahead gaps', () => {
    const c = Array.from({ length: 8 }, (_, i) => ({ time: i * 900000, open: 1, high: 2 + i, low: 0.5, close: 1.5, volume: 1 }));
    const h = aggregate(c, 60); assert.equal(h.length, 2); assert.equal(h[0].high, 5); assert.equal(h[1].time, 3600000);
  });
  it('simulate(): stop is checked before target in the same candle, costs reduce R', () => {
    const c = [{ time: 0, open: 100, high: 100, low: 100, close: 100 }, { time: 1, open: 100, high: 110, low: 94, close: 100 }];
    const r = simulate({ direction: 'LONG', stopLoss: 95, takeProfit: 105 }, c, 1, { trailing: false });
    assert.equal(r.exitReason, 'SL'); assert.ok(r.netR < -1, 'a full stop loses more than 1R after fees/slippage');
    const w = simulate({ direction: 'LONG', stopLoss: 95, takeProfit: 105 }, [c[0], { time: 1, open: 100, high: 106, low: 99, close: 105 }], 1, { trailing: false });
    assert.equal(w.exitReason, 'TP'); assert.ok(w.netR > 0.7 && w.netR < 1);
  });
  it('end-to-end validate() on the sim exchange returns every report section', async () => {
    const r = await validate({ exchange: sim, symbols: ['SOLUSDT', 'ETHUSDT'], years: 0.12, step: 8, sims: 100, windows: 3 });
    for (const k of ['headline', 'strategies', 'byStrategyRegime', 'scoreSweep', 'walkForward', 'selectionTest', 'warnings']) assert.ok(k in r, k);
    assert.equal(r.scoreSweep.length, 7);
    assert.ok(r.scoreSweep[0].trades >= r.scoreSweep[6].trades, 'higher minScore never has more trades');
  });
  it('live strategy stats group closed journal rows by strategy and regime in R', () => {
    const rows = [
      { strategy_id: 'a', strategy_name: 'A', regime: '{"regime":"TREND"}', pnl: 3, initial_risk: 1, position_size: 1, close_time: 1 },
      { strategy_id: 'a', strategy_name: 'A', regime: '{"regime":"TREND"}', pnl: -1, initial_risk: 1, position_size: 1, close_time: 2 },
      { strategy_id: 'b', strategy_name: 'B', regime: 'RANGE', pnl: -1, initial_risk: 1, position_size: 1, close_time: 3 },
    ];
    const s = computeLiveStats(rows);
    assert.equal(s.overall.trades, 3);
    assert.equal(s.byStrategy.find(x => x.id === 'a').expectancyR, 1);
    assert.ok(s.byStrategyRegime.find(x => x.strategyId === 'a' && x.regime === 'TREND'));
  });
});

describe('dataFeed candle cache', () => {
  it('fetches full history once, then only refreshes the tail', async () => {
    dataFeed.clearCache();
    const calls = [];
    const base = Array.from({ length: 200 }, (_, i) => ({ time: i * 900000, open: 1, high: 2, low: 0.5, close: 1, volume: 1 }));
    exchange._use({ getKlines: async (s, iv, limit) => { calls.push(limit); return limit >= 200 ? base : [{ ...base[199], close: 9 }, { time: 200 * 900000, open: 9, high: 9, low: 9, close: 9, volume: 1 }]; } });
    const a = await dataFeed.getCandles('CACHEUSDT', '15m', 200);
    assert.equal(a.length, 200);
    const b = await dataFeed.getCandles('CACHEUSDT', '15m', 200);   // within TTL -> no call
    assert.equal(calls.length, 1);
    exchange._use(null);
    dataFeed.clearCache();
  });
});
