'use strict';

const { describe, it, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { EventBus, eventBus } = require('../src/events/bus');

describe('EventBus Engine', () => {

  let bus;
  beforeEach(() => {
    bus = new EventBus();
  });

  it('publishes and subscribes to events with payload and metadata', () => {
    let received = null;
    bus.on('opportunity.found', (payload, meta) => {
      received = { payload, meta };
    });

    bus.emitEvent('opportunity.found', { symbol: 'SOLUSDT', score: 92 });

    assert.ok(received, 'Listener should have received the event');
    assert.equal(received.payload.symbol, 'SOLUSDT');
    assert.equal(received.payload.score, 92);
    assert.equal(received.meta.event, 'opportunity.found');
    assert.ok(received.meta.timestamp > 0);
  });

  it('supports wildcard * listener for stream aggregators', () => {
    const events = [];
    bus.on('*', (name, payload) => {
      events.push({ name, payload });
    });

    bus.emitEvent('scanner.checkpoint', { count: 10 });
    bus.emitEvent('position.opened', { id: 'p1' });

    assert.equal(events.length, 2);
    assert.equal(events[0].name, 'scanner.checkpoint');
    assert.equal(events[1].name, 'position.opened');
  });

  it('records and returns recent events history with filtering', () => {
    bus.emitEvent('risk.breach', { reason: 'MAX_EXPOSURE' });
    bus.emitEvent('opportunity.qualified', { symbol: 'BTCUSDT' });
    bus.emitEvent('risk.breach', { reason: 'CONSECUTIVE_LOSS' });

    const allRecent = bus.getRecentEvents(10);
    assert.equal(allRecent.length, 3);
    assert.equal(allRecent[0].event, 'risk.breach');

    const filtered = bus.getRecentEvents(10, 'opportunity.qualified');
    assert.equal(filtered.length, 1);
    assert.equal(filtered[0].payload.symbol, 'BTCUSDT');
  });

  it('global eventBus singleton is available and operational', () => {
    assert.ok(eventBus instanceof EventBus);
    let captured = false;
    eventBus.once('test.ping', () => { captured = true; });
    eventBus.emitEvent('test.ping', {});
    assert.equal(captured, true);
  });
});
