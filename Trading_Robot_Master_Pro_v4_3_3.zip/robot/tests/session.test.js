'use strict';

/**
 * Market Session Tests — Crypto-Only Mode
 *
 * Crypto (Bybit USDT perpetuals) is 24/7. The session module always returns OPEN.
 */

const { describe, it } = require('node:test');
const assert = require('node:assert');
const { getSessionStatus, isSessionActive } = require('../src/market/session');

describe('Market Session Module (Crypto-Only)', () => {

  const TUESDAY_14H_UTC   = new Date('2025-09-16T14:00:00Z').getTime();
  const SATURDAY_12H_UTC  = new Date('2025-09-20T12:00:00Z').getTime();
  const SUNDAY_22H_UTC    = new Date('2025-09-21T22:00:00Z').getTime();
  const SUNDAY_EARLY_UTC  = new Date('2025-09-21T03:00:00Z').getTime();

  it('CRYPTO is always OPEN on Tuesday', () => {
    const s = getSessionStatus('CRYPTO', TUESDAY_14H_UTC);
    assert.strictEqual(s.status, 'OPEN');
    assert.strictEqual(s.allowsTrading, true);
    assert.strictEqual(s.assetClass, 'CRYPTO');
  });

  it('CRYPTO is always OPEN on Saturday', () => {
    const s = getSessionStatus('CRYPTO', SATURDAY_12H_UTC);
    assert.strictEqual(s.status, 'OPEN');
    assert.strictEqual(s.allowsTrading, true);
  });

  it('CRYPTO is always OPEN on Sunday night', () => {
    const s = getSessionStatus('CRYPTO', SUNDAY_22H_UTC);
    assert.strictEqual(s.status, 'OPEN');
    assert.strictEqual(s.allowsTrading, true);
  });

  it('CRYPTO is always OPEN on Sunday early morning', () => {
    const s = getSessionStatus('CRYPTO', SUNDAY_EARLY_UTC);
    assert.strictEqual(s.status, 'OPEN');
    assert.strictEqual(s.allowsTrading, true);
  });

  it('result always has required fields: status, allowsTrading, assetClass', () => {
    const s = getSessionStatus('CRYPTO', TUESDAY_14H_UTC);
    assert.ok('status' in s, 'result should have status');
    assert.ok('allowsTrading' in s, 'result should have allowsTrading');
    assert.ok('assetClass' in s, 'result should have assetClass');
  });

  it('isSessionActive always returns true for crypto', () => {
    assert.strictEqual(isSessionActive('CRYPTO', TUESDAY_14H_UTC), true);
    assert.strictEqual(isSessionActive('CRYPTO', SATURDAY_12H_UTC), true);
    assert.strictEqual(isSessionActive('CRYPTO', SUNDAY_EARLY_UTC), true);
  });

  it('defaults to CRYPTO behaviour when no asset class is provided', () => {
    const s = getSessionStatus(undefined, SATURDAY_12H_UTC);
    assert.strictEqual(s.allowsTrading, true);
    assert.strictEqual(s.status, 'OPEN');
  });
});
