'use strict';

const { describe, test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const RiskEngine = require('../src/risk/engine');
const LiveExecution = require('../src/execution/live');
const PaperEngine = require('../src/paper/engine');
const journal = require('../src/journal/store');
const config = require('../src/config');

describe('Risk Management & Trading Safety', () => {
  beforeEach(() => {
    journal.setState('emergency_stop', false);
  });
  test('Risk Engine calculates position size and enforces max positions', () => {
    const risk = new RiskEngine({
      accountBalance: 10000,
      riskPerTrade: 0.01, // $100 risk
      maxOpenPositions: 2,
      minRR: 2.0
    });

    const signal = {
      symbol: 'SOLUSDT',
      direction: 'LONG',
      entry: 100,
      stopLoss: 95, // $5 risk per unit -> 20 units
      takeProfit: 115,
      riskReward: 3.0
    };

    const res1 = risk.check(signal, []);
    assert.equal(res1.approved, true);
    assert.equal(res1.positionSize, 20);

    // Max positions exceeded
    const openPositions = [{ id: 1 }, { id: 2 }];
    const res2 = risk.check(signal, openPositions);
    assert.equal(res2.approved, false);
    assert.ok(res2.reason.includes('MAX_POSITIONS_REACHED'));
  });

  test('Emergency stop disables any trade execution immediately', () => {
    const risk = new RiskEngine();
    const signal = {
      symbol: 'SOLUSDT',
      direction: 'LONG',
      entry: 100,
      stopLoss: 95,
      takeProfit: 115,
      riskReward: 3.0
    };

    risk.emergencyStop();
    const check = risk.check(signal, []);
    assert.equal(check.approved, false);
    assert.equal(check.reason, 'KILL_SWITCH_ACTIVE');

    // Trying to enable trading while kill switch is active must fail
    assert.equal(risk.enableTrading(), false);

    risk.resetKillSwitch();
    risk.enableTrading();
    assert.equal(risk.check(signal, []).approved, true);
  });

  test('Live execution safety gates block unauthorized execution by default', async () => {
    const live = new LiveExecution();
    const signal = {
      symbol: 'SOLUSDT',
      direction: 'LONG',
      entry: 100,
      stopLoss: 95,
      takeProfit: 115
    };

    const gates = live.verifyGates(signal, { approved: true });
    assert.equal(gates.ok, false);
    assert.ok(/MODE=|LIVE_TRADING_ENABLED|Missing Bybit API/.test(gates.reason));

    const orderRes = await live.submitOrder(signal, 10);
    assert.equal(orderRes.success, false);
  });

  test('Paper engine protects against duplicates and manages positions', async () => {
    const paper = new PaperEngine();
    assert.equal(paper.balance, config.accountBalance);

    const perf = paper.getPerformance();
    assert.equal(perf.mode, 'PAPER');
    assert.equal(perf.totalTrades, 0);
  });
});
