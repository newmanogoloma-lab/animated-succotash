'use strict';

/**
 * Market Universe Crypto Filtering Tests
 *
 * System is CRYPTO ONLY — Bybit USDT perpetuals.
 * All symbols passed through the universe are crypto; no filtering needed.
 */

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const { isLegitimateCrypto, classifyAssetClass } = require('../src/market/universe');

describe('Market Universe Crypto Filtering', () => {

  test('approves legitimate crypto assets', () => {
    assert.equal(isLegitimateCrypto('SOLUSDT', 'SOL').isCrypto, true);
    assert.equal(isLegitimateCrypto('ETHUSDT', 'ETH').isCrypto, true);
    assert.equal(isLegitimateCrypto('SUIUSDT', 'SUI').isCrypto, true);
    assert.equal(isLegitimateCrypto('1000PEPEUSDT', '1000PEPE').isCrypto, true);
    assert.equal(isLegitimateCrypto('TAOUSDT', 'TAO').isCrypto, true);
  });

  test('all symbols are treated as CRYPTO in crypto-only mode', () => {
    // System is Bybit USDT perpetuals only — all listed instruments are crypto
    assert.equal(isLegitimateCrypto('BTCUSDT', 'BTC').isCrypto, true);
    assert.equal(isLegitimateCrypto('AVAXUSDT', 'AVAX').isCrypto, true);
    assert.equal(isLegitimateCrypto('DOGEUSDT', 'DOGE').isCrypto, true);
    assert.equal(isLegitimateCrypto('XRPUSDT', 'XRP').isCrypto, true);
  });

  test('classifyAssetClass always returns CRYPTO', () => {
    // All Bybit USDT linear perps are crypto
    assert.equal(classifyAssetClass('SOLUSDT', 'SOL'), 'CRYPTO');
    assert.equal(classifyAssetClass('BTCUSDT', 'BTC'), 'CRYPTO');
    assert.equal(classifyAssetClass('BNBUSDT', 'BNB'), 'CRYPTO');
  });

  test('isLegitimateCrypto returns object with isCrypto field', () => {
    const result = isLegitimateCrypto('BTCUSDT', 'BTC');
    assert.ok(typeof result === 'object');
    assert.ok('isCrypto' in result);
    assert.strictEqual(result.isCrypto, true);
  });
});
