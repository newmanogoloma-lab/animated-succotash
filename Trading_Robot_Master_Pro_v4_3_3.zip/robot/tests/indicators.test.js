'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const indicators = require('../src/indicators');

describe('Technical Indicators Engine', () => {
  const createMockCandles = (count, startPrice = 100, trend = 1) => {
    const candles = [];
    let price = startPrice;
    for (let i = 0; i < count; i++) {
      const open = price;
      const close = price + trend * (i % 2 === 0 ? 1.5 : -0.5);
      const high = Math.max(open, close) + 1.0;
      const low = Math.min(open, close) - 1.0;
      const volume = 1000 + (i % 5) * 200;
      candles.push({
        time: 1700000000000 + i * 900000,
        open, high, low, close, volume
      });
      price = close;
    }
    return candles;
  };

  test('SMA calculates correctly', () => {
    const values = [10, 20, 30, 40, 50];
    const res = indicators.sma(values, 3);
    assert.equal(isNaN(res[0]), true);
    assert.equal(isNaN(res[1]), true);
    assert.equal(res[2], 20);
    assert.equal(res[3], 30);
    assert.equal(res[4], 40);
  });

  test('EMA calculates without NaN once initialized', () => {
    const values = [10, 20, 30, 40, 50, 60, 70];
    const res = indicators.ema(values, 3);
    assert.equal(res[res.length - 1] > 0, true);
    assert.equal(isNaN(res[res.length - 1]), false);
  });

  test('RSI handles bounds and returns values between 0 and 100', () => {
    const candles = createMockCandles(50, 100, 2);
    const rsiRes = indicators.rsi(candles, 14);
    const lastRsi = rsiRes[rsiRes.length - 1];
    assert.equal(lastRsi >= 0, true);
    assert.equal(lastRsi <= 100, true);
  });

  test('ATR produces positive volatility values', () => {
    const candles = createMockCandles(30);
    const atrRes = indicators.atr(candles, 14);
    const lastAtr = atrRes[atrRes.length - 1];
    assert.equal(lastAtr > 0, true);
  });

  test('Alligator produces jaw, teeth, and lips', () => {
    const candles = createMockCandles(50);
    const ally = indicators.alligator(candles);
    assert.ok(ally.jaw);
    assert.ok(ally.teeth);
    assert.ok(ally.lips);
    assert.equal(ally.jaw.length, candles.length);
  });

  test('Volume ratio detects surges', () => {
    const candles = createMockCandles(30);
    candles[candles.length - 1].volume = 10000;
    const ratios = indicators.volumeRatio(candles, 20);
    const lastRatio = ratios[ratios.length - 1];
    assert.equal(lastRatio > 2.0, true);
  });

  test('Detect trend returns valid states', () => {
    const bullCandles = createMockCandles(60, 100, 3);
    const trend = indicators.detectTrend(bullCandles, 3);
    assert.ok(['BULLISH', 'BEARISH', 'RANGING', 'INSUFFICIENT'].includes(trend));
  });
});
