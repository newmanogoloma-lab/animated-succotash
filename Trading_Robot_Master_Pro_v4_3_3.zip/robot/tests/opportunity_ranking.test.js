'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert');
const { rankOpportunities, calculateRankScore } = require('../src/scoring/ranking');

describe('Opportunity Ranking', () => {

  const mockOpportunity = (overrides = {}) => ({
    symbol: 'BTCUSDT',
    score: 88,
    direction: 'LONG',
    regime: { confidence: 80, canonicalRegime: 'STRONG_TREND', atrRatio: 1.1 },
    cluster: 'LAYER_1',
    riskReward: 2.5,
    entry: 50000,
    stopLoss: 49500,
    takeProfit: 51250,
    riskAmount: 0.50,
    qualified: true,
    ...overrides,
  });

  it('calculateRankScore returns an object with rankScore between 0 and 100', () => {
    const opp = mockOpportunity();
    const result = calculateRankScore(opp);
    assert.ok(typeof result === 'object', 'result should be an object');
    assert.ok(typeof result.rankScore === 'number', 'rankScore should be a number');
    assert.ok(result.rankScore >= 0 && result.rankScore <= 100, `rankScore ${result.rankScore} should be between 0 and 100`);
    assert.ok(Array.isArray(result.whySelected), 'whySelected should be array');
    assert.ok(Array.isArray(result.whyNotTrade), 'whyNotTrade should be array');
  });

  it('higher GPS score produces higher rank score', () => {
    const high = calculateRankScore(mockOpportunity({ score: 95 })).rankScore;
    const low = calculateRankScore(mockOpportunity({ score: 70 })).rankScore;
    assert.ok(high > low, `High score (${high}) should rank above low score (${low})`);
  });

  it('higher R:R produces higher rank score', () => {
    const goodRR = calculateRankScore(mockOpportunity({ riskReward: 3.5 })).rankScore;
    const poorRR = calculateRankScore(mockOpportunity({ riskReward: 1.2 })).rankScore;
    assert.ok(goodRR > poorRR, `Better R:R (${goodRR}) should rank higher than poor R:R (${poorRR})`);
  });

  it('rankOpportunities returns sorted array (descending rank)', () => {
    const opps = [
      mockOpportunity({ symbol: 'BTCUSDT', score: 75, riskReward: 1.8 }),
      mockOpportunity({ symbol: 'ETHUSDT', score: 92, riskReward: 3.0 }),
      mockOpportunity({ symbol: 'SOLUSDT', score: 85, riskReward: 2.2 }),
    ];
    const ranked = rankOpportunities(opps);
    assert.ok(Array.isArray(ranked), 'should return array');
    assert.strictEqual(ranked.length, 3, 'should return all opportunities');
    assert.ok(ranked[0].rankScore >= ranked[1].rankScore,
      `First (${ranked[0].rankScore}) should be >= second (${ranked[1].rankScore})`);
    assert.ok(ranked[1].rankScore >= ranked[2].rankScore,
      `Second (${ranked[1].rankScore}) should be >= third (${ranked[2].rankScore})`);
  });

  it('rankOpportunities handles empty array', () => {
    const result = rankOpportunities([]);
    assert.ok(Array.isArray(result));
    assert.strictEqual(result.length, 0);
  });

  it('each ranked opportunity has whySelected or reason field', () => {
    const opps = [mockOpportunity(), mockOpportunity({ symbol: 'ETHUSDT', score: 82 })];
    const ranked = rankOpportunities(opps);
    for (const opp of ranked) {
      assert.ok(opp.whySelected || opp.reason || opp.rankScore !== undefined,
        'Ranked opportunity should have whySelected, reason, or rankScore');
    }
  });

  it('active session gets higher rank than closed session', () => {
    const active = calculateRankScore(mockOpportunity(), { sessionStatus: 'OPEN' }).rankScore;
    const closed = calculateRankScore(mockOpportunity(), { sessionStatus: 'CLOSED' }).rankScore;
    assert.ok(active > closed, `OPEN (${active}) should rank > CLOSED (${closed})`);
  });
});
