'use strict';

// Isolated database so these tests never touch (or depend on) the real data/robot.db
const os = require('os');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'gps-sync-'));
process.env.ROBOT_DATA_DIR = TMP;

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const journal = require('../src/journal/store');
const PaperEngine = require('../src/paper/engine');
const TradingRobot = require('../src/robot');

function openTradeRow(over = {}) {
  const openTime = over.openTime || Date.now() - 60000;
  return {
    id: `SOLUSDT_gps_v1_${openTime}`,
    symbol: 'SOLUSDT', strategyId: 'gps_v1', strategyName: 'GPS v1', strategyVersion: '1.0.0',
    direction: 'LONG', entry: 100, stopLoss: 98, takeProfit: 106, positionSize: 2,
    score: 90, riskReward: 3, cluster: 'ALT_GENERAL', openTime,
    initialRisk: 2, initialStopLoss: 98, trailingActive: false, trailingStopPrice: null,
    ...over,
  };
}

describe('A2 — database path is anchored to the repository', () => {
  it('resolves the same absolute DB file regardless of process.cwd()', () => {
    const repo = path.resolve(__dirname, '..');
    const out = execFileSync(process.execPath, ['-e',
      `process.stdout.write(require(${JSON.stringify(path.join(repo, 'src/journal/store'))}).getDbPath())`],
      { cwd: os.tmpdir(), env: { ...process.env, ROBOT_DATA_DIR: '' }, stdio: ['ignore', 'pipe', 'ignore'] }).toString();
    assert.equal(out, path.join(repo, 'data', 'robot.db'));
  });

  it('honours ROBOT_DATA_DIR', () => {
    assert.equal(journal.getDbPath(), path.join(TMP, 'robot.db'));
  });
});

describe('A1 — command queue (dashboard -> robot)', () => {
  it('enqueue -> claim -> complete lifecycle', () => {
    const id = journal.enqueueCommand('CLOSE_POSITION', { id: 'X' });
    assert.equal(journal.getCommand(id).status, 'PENDING');
    const claimed = journal.claimPendingCommands(10);
    assert.ok(claimed.some(c => c.id === id && c.payload.id === 'X'));
    assert.equal(journal.getCommand(id).status, 'PROCESSING');
    assert.equal(journal.claimPendingCommands(10).filter(c => c.id === id).length, 0, 'never claimed twice');
    journal.completeCommand(id, 'DONE', { ok: 1 });
    assert.deepEqual(journal.getCommand(id).result, { ok: 1 });
  });

  it('stale commands are failed instead of hanging forever', () => {
    const id = journal.enqueueCommand('CLOSE_ALL', {});
    journal.getDb().prepare('UPDATE commands SET created_at = ? WHERE id = ?').run(Date.now() - 120000, id);
    journal.expireStaleCommands(60000);
    assert.equal(journal.getCommand(id).status, 'FAILED');
  });
});

describe('A5 — event stream table', () => {
  it('appends, reads since an id, and prunes', () => {
    const a = journal.appendEvent('position.opened', { symbol: 'AAA' });
    const b = journal.appendEvent('position.closed', { symbol: 'AAA' });
    const since = journal.getEventsSince(a - 1, 10);
    assert.deepEqual(since.map(e => e.event).slice(0, 2), ['position.opened', 'position.closed']);
    assert.equal(journal.getEventsSince(b, 10).length, 0);
    assert.ok(journal.getLatestEventId() >= b);
    journal.pruneEvents(1);
    assert.ok(journal.getRecentEventsDb(10).length <= 2);
  });
});

describe('A3 — manual close needs a real price', () => {
  it('throws without exitPrice and books correct PnL with one', () => {
    const e = new PaperEngine();
    const t = openTradeRow();
    e.openTrades.set('SOLUSDT_gps_v1', t);
    assert.throws(() => e.closeTrade(t.id, 'MANUAL'), /exitPrice is required/);
    assert.equal(e.openTrades.size, 1, 'trade must remain open after a rejected close');
    const closed = e.closeTrade(t.id, 'MANUAL', 105);
    assert.equal(closed.exitPrice, 105);
    assert.ok(closed.pnl > 0 && closed.outcome === 'WIN');
  });

  it('closeAllTrades(strict) refuses to close a symbol with no price', () => {
    const e = new PaperEngine();
    e.openTrades.set('SOLUSDT_gps_v1', openTradeRow());
    const closed = e.closeAllTrades('X', () => null, { strict: true });
    assert.equal(closed.length, 0);
    assert.equal(closed.failed.length, 1);
    assert.equal(e.openTrades.size, 1);
  });
});

describe('A4 — journal write failures are never silent', () => {
  it('queues a failed write and recovers it', () => {
    const e = new PaperEngine();
    const t = openTradeRow({ id: 'RETRY_1' });
    const real = journal.savePaperTrade;
    journal.savePaperTrade = () => { throw new Error('database is locked'); };
    try {
      assert.equal(e._persist(t), false);
      assert.equal(e.getPendingWrites(), 1);
    } finally { journal.savePaperTrade = real; }
    assert.equal(e.flushOutbox(), 0);
    assert.ok(journal.getOpenPaperTrades().some(r => r.id === 'RETRY_1'));
  });
});

describe('Restart safety — open positions are restored and managed', () => {
  it('restoreFromJournal rebuilds open trades, then TP closes and persists them', () => {
    const t = openTradeRow({ id: 'RESTORE_1', symbol: 'RSTUSDT' });
    journal.savePaperTrade(t);
    const e = new PaperEngine();
    assert.ok(e.restoreFromJournal() >= 1);
    const restored = e.getOpenTrades().find(x => x.id === 'RESTORE_1');
    assert.ok(restored);
    assert.equal(restored.initialRisk, 2);
    const closed = e.updateTrades('RSTUSDT', 107);
    assert.equal(closed.length, 1);
    assert.equal(closed[0].exitReason, 'TAKE_PROFIT_HIT');
    assert.ok(!journal.getOpenPaperTrades().some(r => r.id === 'RESTORE_1'));
    assert.ok(journal.getClosedPaperTrades(100).some(r => r.id === 'RESTORE_1'));
  });

  it('re-entering the same symbol+strategy no longer overwrites the earlier closed trade', () => {
    const first = openTradeRow({ id: 'DUP_gps_v1_1', symbol: 'DUPUSDT', openTime: 1 });
    const second = openTradeRow({ id: 'DUP_gps_v1_2', symbol: 'DUPUSDT', openTime: 2 });
    journal.savePaperTrade({ ...first, exitPrice: 99, closeTime: 5, outcome: 'LOSS', pnl: -2 });
    journal.savePaperTrade(second);
    const rows = journal.getTradesBySymbol('DUPUSDT', 10);
    assert.equal(rows.length, 2);
  });

  it('trailing-stop moves are persisted (stop_loss + trailing_stop columns)', () => {
    const t = openTradeRow({ id: 'TRAIL_1', symbol: 'TRLUSDT' });
    journal.savePaperTrade(t);
    const e = new PaperEngine();
    e.restoreFromJournal();
    e.updateTrades('TRLUSDT', 103);   // +1.5R -> trailing activates, not stopped out
    const row = journal.getOpenPaperTrades().find(r => r.id === 'TRAIL_1');
    assert.ok(row.trailing_active === 1);
    assert.ok(row.trailing_stop > 98 && row.stop_loss === row.trailing_stop);
  });
});

describe('Robot command executor', () => {
  function makeRobot() {
    const r = new TradingRobot();
    r.notifier = { notifyTradeClosed: async () => {} };
    return r;
  }

  it('CLOSE_POSITION closes at the live price and reports PnL', async () => {
    const r = makeRobot();
    const t = openTradeRow({ id: 'CMD_1', symbol: 'CMDUSDT' });
    r.paperEngine.openTrades.set('CMDUSDT_gps_v1', t);
    r._getTickerMap = async () => ({ CMDUSDT: { lastPrice: 104, markPrice: 104 } });
    const res = await r._executeCommand({ type: 'CLOSE_POSITION', payload: { id: 'CMD_1' } });
    assert.equal(res.closed.exitPrice, 104);
    assert.ok(res.closed.pnl > 0);
  });

  it('CLOSE_POSITION fails (and keeps the trade) when no market price is available', async () => {
    const r = makeRobot();
    r.paperEngine.openTrades.set('NOPUSDT_gps_v1', openTradeRow({ id: 'CMD_2', symbol: 'NOPUSDT' }));
    r._getTickerMap = async () => ({});
    await assert.rejects(() => r._executeCommand({ type: 'CLOSE_POSITION', payload: { id: 'CMD_2' } }), /No live market price/);
    assert.equal(r.paperEngine.openTrades.size, 1);
  });

  it('PAUSE / RESUME / EMERGENCY flow', async () => {
    const r = makeRobot();
    assert.equal((await r._executeCommand({ type: 'PAUSE', payload: {} })).paused, true);
    assert.equal(r.paused, true);
    assert.equal((await r._executeCommand({ type: 'RESUME', payload: {} })).paused, false);
    await r._executeCommand({ type: 'EMERGENCY_STOP', payload: {} });
    await assert.rejects(() => r._executeCommand({ type: 'RESUME', payload: {} }), /Emergency stop active/);
    await r._executeCommand({ type: 'EMERGENCY_RESET', payload: {} });
    assert.equal((await r._executeCommand({ type: 'RESUME', payload: {} })).paused, false);
  });

  it('CONFIG_UPDATE is applied to the robot engine and unknown commands are rejected', async () => {
    const r = makeRobot();
    await r._executeCommand({ type: 'CONFIG_UPDATE', payload: { riskPerTrade: 0.02, maxOpenPositions: 3 } });
    assert.equal(r.paperEngine.riskEngine.cfg.riskPerTrade, 0.02);
    assert.equal(r.paperEngine.riskEngine.cfg.maxOpenPositions, 3);
    await assert.rejects(() => r._executeCommand({ type: 'NOPE', payload: {} }), /Unknown command/);
  });

  it('the position monitor closes a trade whose SL/TP is hit without waiting for a scan', async () => {
    const r = makeRobot();
    r.running = true;
    r.paperEngine.openTrades.set('MONUSDT_gps_v1', openTradeRow({ id: 'MON_1', symbol: 'MONUSDT' }));
    journal.savePaperTrade(r.paperEngine.openTrades.get('MONUSDT_gps_v1'));
    r._getTickerMap = async () => ({ MONUSDT: { lastPrice: 107, markPrice: 107 } });
    await r._monitorTick();
    assert.equal(r.paperEngine.openTrades.size, 0);
    assert.ok(journal.getClosedPaperTrades(100).some(x => x.id === 'MON_1'));
    const hb = journal.getState('robot_heartbeat');
    assert.ok(hb && hb.alive && hb.pid === process.pid);
  });
});
