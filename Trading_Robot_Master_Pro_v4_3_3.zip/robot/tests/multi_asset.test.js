'use strict';

/**
 * Crypto Universe Tests
 *
 * System is CRYPTO ONLY — Bybit USDT perpetuals.
 * All instruments on Bybit USDT Linear are classified as CRYPTO.
 */

const { describe, it } = require('node:test');
const assert = require('node:assert');
const { classifyAssetClass, isLegitimateCrypto, KNOWN_NON_CRYPTO_BASE } = require('../src/market/universe');

describe('Crypto Universe Classification (Crypto-Only Mode)', () => {

  it('classifies all symbols as CRYPTO (system is crypto-only)', () => {
    // All Bybit USDT perps are crypto — no non-crypto classification
    assert.strictEqual(classifyAssetClass('BTCUSDT', 'BTC'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('ETHUSDT', 'ETH'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('SOLUSDT', 'SOL'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('DOGEUSDT', 'DOGE'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('PEPEUSDT', 'PEPE'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('XRPUSDT', 'XRP'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('BNBUSDT', 'BNB'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('AVAXUSDT', 'AVAX'), 'CRYPTO');
  });

  it('isLegitimateCrypto always returns true in crypto-only mode', () => {
    const btcCheck = isLegitimateCrypto('BTCUSDT', 'BTC');
    assert.strictEqual(btcCheck.isCrypto, true);

    const solCheck = isLegitimateCrypto('SOLUSDT', 'SOL');
    assert.strictEqual(solCheck.isCrypto, true);

    // In crypto-only mode any symbol is treated as crypto
    const anyCheck = isLegitimateCrypto('ANYTHINGUSDT');
    assert.strictEqual(anyCheck.isCrypto, true);
  });

  it('KNOWN_NON_CRYPTO_BASE is empty (no non-crypto classification needed)', () => {
    assert.ok(KNOWN_NON_CRYPTO_BASE instanceof Set);
    assert.strictEqual(KNOWN_NON_CRYPTO_BASE.size, 0);
  });

  it('classifyAssetClass return value is always the string CRYPTO', () => {
    const result = classifyAssetClass('ANYTHINGUSDT');
    assert.strictEqual(typeof result, 'string');
    assert.strictEqual(result, 'CRYPTO');
  });
});
