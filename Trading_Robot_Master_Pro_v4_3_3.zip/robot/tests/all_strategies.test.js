'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { createDefaultRegistry, StrategyRegistry } = require('../src/strategy/registry');
const GPSStrategy = require('../src/strategy/gps');
const MeanReversionStrategy = require('../src/strategy/meanReversion');
const BreakoutStrategy = require('../src/strategy/breakout');
const PullbackStrategy = require('../src/strategy/pullback');
const RangeFadingStrategy = require('../src/strategy/rangeFading');
const MomentumSRStrategy = require('../src/strategy/momentumSR');
const OpeningRangeBreakoutStrategy = require('../src/strategy/orb');

// Helper to generate simulated synthetic candle series
function makeCandles(count = 50, startPrice = 100, trend = 0.005, volatility = 0.01) {
  const candles = [];
  let price = startPrice;
  const now = Date.now();

  for (let i = 0; i < count; i++) {
    const time = now - (count - i) * 3600000;
    const move = (Math.random() - 0.48 + trend) * price * volatility;
    const open = price;
    const close = price + move;
    const high = Math.max(open, close) + Math.random() * price * volatility * 0.5;
    const low = Math.min(open, close) - Math.random() * price * volatility * 0.5;
    const volume = 1000 + Math.random() * 5000;

    candles.push({ time, open, high, low, close, volume });
    price = close;
  }
  return candles;
}

describe('All 9 Production Strategies Pipeline', () => {

  const defaultRegistry = createDefaultRegistry();

  it('verifies all 7 distinct strategies are registered in createDefaultRegistry()', () => {
    const all = defaultRegistry.getAll();
    assert.equal(all.length, 7, 'Registry must have all 7 production strategies');

    const expectedIds = [
      'gps_v1',
      'mean_reversion_v1',
      'breakout_v1',
      'pullback_v1',
      'range_fading_v1',
      'momentum_sr_v1',
      'orb_v1',
    ];

    for (const id of expectedIds) {
      const strat = defaultRegistry.get(id);
      assert.ok(strat, `Strategy ${id} must be registered`);
      assert.equal(strat.enabled, true);
    }
  });

  // 1. GPS Strategy
  it('1. GPS Strategy evaluates market data cleanly', () => {
    const strat = new GPSStrategy();
    const marketData = {
      symbol: 'SOLUSDT',
      candles4H: makeCandles(60, 150, 0.01),
      candles1H: makeCandles(60, 150, 0.01),
      candles15M: makeCandles(60, 150, 0.01),
    };
    const res = strat.evaluate(marketData);
    assert.equal(res.strategyId, 'gps_v1');
    assert.ok(typeof res.score === 'number');
    assert.ok(typeof res.qualified === 'boolean');
  });

  // 2. Mean Reversion
  it('2. Mean Reversion Strategy evaluates range conditions', () => {
    const strat = new MeanReversionStrategy();
    const marketData = {
      symbol: 'ETHUSDT',
      candles4H: makeCandles(60, 2500, 0, 0.005),
      candles1H: makeCandles(60, 2500, 0, 0.005),
      candles15M: makeCandles(60, 2500, 0, 0.005),
    };
    const res = strat.evaluate(marketData);
    assert.equal(res.strategyId, 'mean_reversion_v1');
    assert.ok(res.entry > 0);
  });

  // 3. Breakout Strategy
  it('3. Breakout Strategy detects structural breaks', () => {
    const strat = new BreakoutStrategy();
    const marketData = {
      symbol: 'BTCUSDT',
      candles4H: makeCandles(60, 60000, 0.02, 0.015),
      candles1H: makeCandles(60, 60000, 0.02, 0.015),
      candles15M: makeCandles(60, 60000, 0.02, 0.015),
    };
    const res = strat.evaluate(marketData);
    assert.equal(res.strategyId, 'breakout_v1');
    assert.ok(typeof res.score === 'number');
  });

  // 4. Pullback Continuation
  it('4. Pullback Strategy handles trend pullback retracements', () => {
    const strat = new PullbackStrategy();
    const marketData = {
      symbol: 'AVAXUSDT',
      candles4H: makeCandles(60, 30, 0.01),
      candles1H: makeCandles(60, 30, 0.01),
      candles15M: makeCandles(60, 30, 0.01),
    };
    const res = strat.evaluate(marketData);
    assert.equal(res.strategyId, 'pullback_v1');
    assert.ok(res.stopLoss > 0);
  });

  // 5. Range Fading
  it('5. Range Fading Strategy detects outer boundaries', () => {
    const strat = new RangeFadingStrategy();
    const marketData = {
      symbol: 'DOGEUSDT',
      candles4H: makeCandles(60, 0.15, 0, 0.008),
      candles1H: makeCandles(60, 0.15, 0, 0.008),
      candles15M: makeCandles(60, 0.15, 0, 0.008),
    };
    const res = strat.evaluate(marketData);
    assert.equal(res.strategyId, 'range_fading_v1');
    assert.ok(typeof res.score === 'number');
    assert.ok(res.conditions);
  });

  // 6. Momentum & S/R
  it('6. Momentum & S/R Strategy checks key level retests', () => {
    const strat = new MomentumSRStrategy();
    const marketData = {
      symbol: 'LINKUSDT',
      candles4H: makeCandles(60, 12, 0.01),
      candles1H: makeCandles(60, 12, 0.01),
      candles15M: makeCandles(60, 12, 0.01),
    };
    const res = strat.evaluate(marketData);
    assert.equal(res.strategyId, 'momentum_sr_v1');
    assert.ok(typeof res.riskReward === 'number');
  });

  // 7. Opening Range Breakout (ORB)
  it('7. Opening Range Breakout (ORB) Strategy captures opening ranges', () => {
    const strat = new OpeningRangeBreakoutStrategy();
    const marketData = {
      symbol: 'SUIUSDT',
      candles4H: makeCandles(60, 2.5, 0.015),
      candles1H: makeCandles(60, 2.5, 0.015),
      candles15M: makeCandles(60, 2.5, 0.015),
    };
    const res = strat.evaluate(marketData);
    assert.equal(res.strategyId, 'orb_v1');
    assert.ok(typeof res.score === 'number');
  });

});
