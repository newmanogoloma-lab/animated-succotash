'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const WalkForwardEngine = require('../src/backtest/walkForward');

describe('Walk-Forward Validation Engine', () => {
  test('gracefully handles missing or insufficient historical data', async () => {
    const wf = new WalkForwardEngine();
    const res = await wf.run('TESTUSDT', { maxCandles: 20 });
    assert.equal(res.status, 'INCOMPLETE');
    assert.ok(res.reason.includes('INSUFFICIENT HISTORICAL CANDLES'));
  });
});
