# v4.3.3 — startup fix
- Fix: dashboard crashed with `EADDRINUSE :::3000` (an older copy was still running) and took the robot down with it. `npm run start:all` now finds a free port automatically (3000, then 3001, ...), tells you which one it used, and prints the command to stop the old copy.
- Fix: `PORT=5000` was ignored (only `DASHBOARD_PORT` was read). Both are honoured now (`DASHBOARD_PORT` wins).
- `npm run dashboard` on its own now prints a clear message instead of a stack trace if the port is taken.
- Cleanup: "Strategy registered" lines moved to debug level (each internal component builds its own registry, which looked like duplicate registration).
