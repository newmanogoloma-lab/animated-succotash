# v4.3.1 — database init hotfix
- store.js: connection cached only after schema created AND verified (13 required tables); SQLITE_BUSY retry with backoff; WAL falls back to DELETE journal; corrupt DB moved to robot.db.corrupt-<ts>; PRAGMA user_version=2.
- start-all.js: initialises DB once before spawning robot + dashboard (no creation race).
- config.js: .env read from repo root; inline `# comments` stripped (STRATEGY_MODE was becoming 'ALL # ALL = ...').
- New: npm run db:check / db:reset -- --yes / setup; .devcontainer/devcontainer.json (Node 22, port 3000).
- Tests: tests/db_init.test.js (6) -> 211 total.
