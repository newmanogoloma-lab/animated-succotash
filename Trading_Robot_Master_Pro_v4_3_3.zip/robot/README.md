# GPS Automated Crypto Trading Robot

A simple, modular, and resilient cryptocurrency trading robot built from scratch for Bybit USDT Perpetual (linear) contracts. Built with Node.js 24 and designed with zero external runtime dependencies using native Node.js capabilities (`node:sqlite`, `node:test`, native `fetch`, `node:http`, and `node:crypto`).

---

## 1. Features

- **Automated Market Discovery**: Automatically discovers all active Bybit linear USDT perpetual markets with 24h volume > 1,000,000 USDT (excludes BTCUSDT & ETHUSDT by default from trading while keeping them as market reference).
- **Multi-Timeframe Technical Analysis**:
  - **4H**: Trend detection (swing structure, HH/HL/LH/LL)
  - **1H**: Market structure & Williams Alligator alignment
  - **15M**: Trigger candle confirmation, RSI (14), and Volume MA ratio surge
  - **Market Meta**: Funding rate filter and Open Interest checks
- **Deterministic Setup Scoring**: Transparent 0–100 score representing setup quality (not win probability). Strict NO-TRADE filtering with explicit rejection reasons.
- **Pluggable Multi-Strategy Registry**: Add, enable, disable, or rename strategies dynamically without breaking historical data or schema.
- **Centralized Risk Engine**: Mandatory gate before any execution. Enforces position sizing based on risk per trade, maximum open positions, maximum portfolio exposure, max daily loss, and consecutive loss limits.
- **True Historical Backtesting**: Chronological candle processing without look-ahead bias. Includes fee simulation and in-sample vs. out-of-sample data splitting.
- **Strategy Experiment Engine**: Multi-configuration grid testing (score, R:R, volume thresholds) ranked by Profit Factor and Expectancy, with small sample size warnings.
- **Paper Trading**: Real-time simulated execution with Bybit public ticker and candle data.
- **Independent Robot Process**: Runs headless as a daemon or CLI process without needing a browser or dashboard open.
- **Minimal Control Panel**: Lightweight HTTP dashboard on port 3000 for monitoring status, recent signals, open positions, and emergency stop controls.
- **Telegram Notifications**: Pre-formatted HTML alerts for qualified setups, trade entries/exits, errors, and emergency stop with cooldown deduplication.
- **Live Trading Multi-Gated Isolation**: Triple-gated protection (disabled by default; requires explicit environment flags and runtime confirmation).

---

## 2. Project Architecture

```text
crypto-trading-robot/
├── config/
├── src/
│   ├── config.js               # Zero-dependency config & .env loader
│   ├── robot.js                # Main autonomous robot process
│   ├── exchanges/
│   │   └── bybit.js            # Public REST client (native fetch, retries)
│   ├── market/
│   │   ├── universe.js         # Dynamic USDT perp discovery
│   │   └── dataFeed.js         # Multi-timeframe OHLCV, funding & OI
│   ├── indicators/
│   │   └── index.js            # RSI, EMA, ATR, Alligator, Volume, Swings
│   ├── strategy/
│   │   ├── registry.js         # Pluggable multi-strategy registry
│   │   └── gps/
│   │       └── index.js        # Primary GPS 4H/1H/15M strategy
│   ├── scoring/
│   │   └── engine.js           # Signal scoring & NO-TRADE filtering
│   ├── risk/
│   │   └── engine.js           # Position sizing & risk gatekeeper
│   ├── backtest/
│   │   ├── engine.js           # Chronological backtesting engine
│   │   └── experiment.js       # Configuration comparison matrix
│   ├── paper/
│   │   └── engine.js           # Paper trade execution simulator
│   ├── execution/
│   │   └── live.js             # Live safety gates & order execution stub
│   ├── notifications/
│   │   └── telegram.js         # Telegram bot alerts with deduplication
│   ├── journal/
│   │   └── store.js            # Native SQLite storage (node:sqlite)
│   ├── scripts/
│   │   ├── markets.js          # CLI: dynamic market universe
│   │   ├── scan.js             # CLI: scan active markets
│   │   ├── backtest.js         # CLI: historical backtester
│   │   ├── experiment.js       # CLI: strategy parameter experiments
│   │   └── status.js           # CLI: robot status & performance
│   └── utils/
│       └── logger.js           # Structured level-based logger
├── dashboard/
│   ├── server.js               # Zero-dependency HTTP control panel server
│   └── public/
│       └── index.html          # Clean status & control panel UI
├── tests/
│   ├── indicators.test.js      # Technical indicator tests
│   ├── strategy_scoring.test.js# Strategy & scoring tests
│   ├── risk_safety.test.js     # Risk engine & safety gate tests
│   └── backtest.test.js        # Backtesting & metrics tests
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── FINAL_REPORT.md
```

---

## 3. Installation & Setup

### Requirements
- Node.js >= 20.0.0 (Node.js 24 recommended)
- Internet connection for Bybit public endpoints

### Setup
```bash
# Clone or extract project
cd CRYPTO

# Copy environment template
cp .env.example .env
```

Because this architecture leverages Node.js 24 native built-ins (`node:sqlite`, native `fetch`, `node:test`), it runs with zero external npm dependencies required for standard operation!

---

## 4. Commands & Usage

### Run Test Suite
```bash
npm test
```

### Discover Bybit Markets
```bash
npm run markets
```

### Scan Discovered Markets
```bash
npm run scan
```

### Run Historical Backtest
```bash
# Default (SOLUSDT)
npm run backtest

# Custom symbol and thresholds
npm run backtest -- --symbol=SUIUSDT --minScore=85 --minRR=2.0
```

### Run Strategy Parameter Experiments
```bash
# Compare score thresholds (75, 80, 85, 90)
npm run experiment -- --symbol=SOLUSDT --type=score

# Compare Risk:Reward ratios (1.5, 2.0, 2.5, 3.0)
npm run experiment -- --symbol=SOLUSDT --type=rr
```

### Start Robot in Paper Trading Mode
```bash
npm run paper
# or
npm run robot
```

### Check Robot Status
```bash
npm run status
```

### Launch Minimal Control Panel
```bash
npm run dashboard
# Open http://localhost:3000 in your browser
```

---

## 5. Strategy Management

### Strategy Interface
Every strategy implements a standard interface:
```javascript
{
  id: 'gps_v1',           // Stable internal identifier (never changes)
  name: 'GPS',            // Renamable display name
  version: '1.0.0',       // Strategy version
  enabled: true,          // Active toggle
  configuration: { ... }, // Parameter snapshot
  evaluate(marketData)    // Returns setup scoring & trade levels
}
```

### Renaming a Strategy
You can rename the display name (e.g. from `GPS` to `Quantum Trend`) without breaking historical trades or database relations:
```javascript
const registry = createDefaultRegistry();
registry.rename('gps_v1', 'Quantum Trend');
```

### Adding a New Strategy
1. Create a strategy class under `src/strategy/my_strategy/index.js` implementing `evaluate()`.
2. Register it with the strategy registry:
```javascript
const registry = createDefaultRegistry();
registry.register(new MyStrategy());
```

---

## 6. Risk Engine & Emergency Controls

Every signal must pass through the Risk Engine before entering Paper or Live execution:
- **Risk Per Trade**: Default 1% of account balance
- **Max Open Positions**: Default 5 simultaneous positions
- **Max Portfolio Exposure**: Default 30% of portfolio
- **Max Daily Loss**: Default 5% daily drawdown limit
- **Max Consecutive Losses**: Circuit breaker after 5 consecutive losses
- **Emergency Stop**: Instantly stops new trades via CLI or control panel button.

---

## 7. Live Trading Isolation

Live trading is **OFF BY DEFAULT**. Live execution requires ALL of the following independent gates to be satisfied simultaneously:
1. `TRADING_MODE=LIVE` in `.env`
2. `LIVE_TRADING_ENABLED=true` in `.env`
3. Valid `BYBIT_API_KEY` and `BYBIT_API_SECRET`
4. Runtime confirmation via `confirmLiveMode()`
5. Risk Engine validation pass
6. Duplicate trade protection pass

If any condition fails, execution defaults to `NO_TRADE`.

---

## 8. Known Limitations

1. **Exchange Scope**: Designed for Bybit linear USDT perpetuals. Does not include Spot or Inverse contracts.
2. **Historical Data Depth**: Bybit public kline endpoints paginate backward up to available exchange liquidity history (typically 2,000 4H candles).
3. **Live Execution Orders**: Contains fully integrated safety verification gates; exchange private order submission is isolated as a safety stub.

---

## v4.1 — Dashboard sync, live updates & new chart page

### How to run (Codespaces or local)

```bash
npm run start:all      # robot + dashboard together (recommended). Open the forwarded port 3000.
# or, in two terminals:
npm run robot          # the ONLY process that opens/closes/monitors positions
npm run dashboard      # read/command UI
```

Both processes log the **same absolute database path** at startup (`DATABASE: …/data/robot.db`).
The path is anchored to the repository, not to the folder you launch from; override with `ROBOT_DATA_DIR`.

### Process model

- The **robot** owns every position. The **dashboard never trades** — close / close-all / pause / resume /
  emergency / config buttons are written to a `commands` table and executed by the robot within ~1 s
  (the API returns the robot's result, or `409` if the robot is offline).
- The robot writes a **heartbeat** every few seconds; the header shows `RUNNING / PAUSED / ROBOT OFFLINE`
  from it, plus a red banner for DB-path mismatch, open-count mismatch, pending writes or stale prices.
- Robot events (`position.opened/closed/trailing_updated`, emergency) are stored in an `events` table and pushed
  to the browser over **Server-Sent Events** (`/api/stream`). The badge shows `LIVE` (push) or `POLLING` (5 s fallback).
- Open positions are **restored from the journal on restart**, so SL/TP/trailing keep being managed.
- A **position monitor** checks open trades every `MONITOR_INTERVAL_SECONDS` (default 5) instead of waiting for a full scan.

### Chart page

TradingView lightweight-charts v4.2 (loaded from jsDelivr, pinned): crosshair + OHLC legend, zoom/pan, volume pane,
timeframes 1m/5m/15m/1h/4h/1d, EMA20/EMA50/VWAP overlays, live candle every 3 s, entry/SL/TP/trailing price lines
with live unrealized PnL, trade entry/exit markers, dotted lines for *signal-only* levels. If the CDN is unreachable
the page falls back to the basic canvas renderer and says so.

`GET /api/dashboard/chart/:symbol?interval=15m&limit=300&since=<unix sec>&indicators=ema20,ema50,vwap`

### Notes

- Closing a **live** (real-money) position from the dashboard is intentionally not supported — close it on the exchange.
- See `CHANGELOG_v4_1.md` for every change and `tests/sync_fixes.test.js`, `tests/dashboard_sync.test.js` for coverage.
