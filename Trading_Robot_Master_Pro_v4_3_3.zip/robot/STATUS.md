# STATUS.md — GPS Crypto Robot (resume file)
> New chat? Upload the latest zip + this file and say "continue from STATUS.md". Do NOT re-read the old chat. Update this file after every stage.

**Version:** 1.3.1 (v4.3.1 DB-init hotfix) · Node >=20 (tested 22), zero npm deps, SQLite via `node:sqlite` · Codespaces: `npm run start:all`, forward port 3000 · PAPER mode (live is triple-gated)
**Tests:** `npm test` (all must pass; 192+ at last run) · Offline demo: `EXCHANGE=sim npm run start:all` · `npm run validate:quick`

## User decisions (final)
Paper balance $100 default, any amount allowed (50/300/1500…), reset anytime · only setups score >= 85 trade (FILL off) · leverage 10x · NO cap on open positions / total risk / daily loss / consecutive losses (all = 0 → unlimited) · risk/trade 1.5% minimum (can be higher) · black & teal theme · must work in Codespaces · save tokens.

## Stage checklist
- [x] v4.2: blank scanner/journal/opportunities fixed; 10+ positions; ALL strategies; SL/TP on qualified; close-orphan fix; theme
- [x] S1 Account: unlimited caps, equity sizing, depleted guard, `RESET_ACCOUNT` cmd + `/api/account/reset`, `/api/dashboard/account`, Risk-tab account card
- [x] S2 Liquidation awareness: `liquidationPrice()`, SL must be inside 80% of liq distance (`LIQ_SAFETY`), Liq Price column
- [x] S3 Exchange layer: `src/exchanges/index.js` facade (EXCHANGE=bybit|sim), `sim.js` deterministic offline exchange, base.js contract extended (getOrderBook/getFundingHistory/getOpenInterestHistory)
- [x] S4 WebSocket: `src/exchanges/ws/{miniws,managed,bybitStream}.js` (zero-dep RFC6455 client, reconnect/heartbeat/stale watchdog, public tickers+kline+orderbook, private auth stream), `src/market/liveFeed.js`, REST fallback, event-driven SL/TP on ticks. Client cross-checked against the `ws` lib (frames up to 64-bit, ping/pong, reconnect+resubscribe) — NOT tested against real Bybit (sandbox has no access).
- [x] S5 `dataFeed` candle cache (full fetch once, then tail refresh) + WS kline overlay; meta cache 5 min
- [x] S6 Microstructure `src/market/microstructure.js`: spread, depth, slippage walk, imbalance, funding momentum, OI momentum; vetoes (spread/slippage/thin book; funding veto optional)
- [x] S7 Validation: `src/validation/{metrics,validator,evidence,liveStats}.js`, `npm run validate[:quick]`, writes data/validation/latest.json + reports/VALIDATION_REPORT.md; walk-forward windows, regime-selection OOS test, score sweep, Monte Carlo, `EVIDENCE_GATING` (off by default)
- [x] S8 Dashboard: Data Feed tab, Strategy Lab tab, account card, feed pill, Liq column, blocked badges
- [x] S9 UI alignment fixed; e2e run on sim exchange OK (scan→open→liq price→feed→reset)
- [x] S10 205 tests pass; CHANGELOG_v4_3.md; zip delivered as Trading_Robot_Master_Pro_v4_3.zip
- [x] S10b v4.3.1 hotfix: `no such table: paper_trades` = failed init (e.g. 'database is locked' while robot+dashboard start together) was CACHED as a schema-less handle. Fixed in `src/journal/store.js` (cache only after verified init, busy-retry, WAL->DELETE fallback, corrupt file quarantined), `start-all.js` inits DB once first, `.env` loader strips inline comments + reads repo-root .env, new `npm run db:check | db:reset -- --yes | setup`, `.devcontainer/`, tests/db_init.test.js (211 pass)
- [ ] S11 (**NEXT, user in Codespaces**) 1) update .env from .env.example 2) `npm run start:all`, check Data Feed tab shows WS LIVE 3) run `npm run validate -- --years=2 --top=15` in Codespaces on REAL Bybit data, then decide `EVIDENCE_GATING`
- [ ] Deferred: 2nd real exchange (Binance/OKX), kill-switch persistence, sentiment layer

## Where things live
robot loop `src/robot.js` (analyse all → rank → micro check → open → persist; `_onLiveTicker`) · paper `src/paper/engine.js` · risk `src/risk/engine.js` · router `src/strategy/router.js` · feed `src/market/{dataFeed,liveFeed,microstructure}.js` · server `dashboard/server.js` · UI `dashboard/public/index.html` (v4.2/4.2.1 JS blocks at the end of the script)

## Key env
`RISK_PER_TRADE=0.015 MAX_OPEN_POSITIONS=0 MAX_PORTFOLIO_EXPOSURE=0 MAX_DAILY_LOSS=0 MIN_SCORE=85 FILL_TO_TARGET=false EXCHANGE=bybit WS_ENABLED=true MICRO_CHECKS=true MAX_SPREAD_BPS=15 MAX_SLIP_BPS=30 MIN_DEPTH_MULTIPLE=3 FUNDING_VETO=false EVIDENCE_GATING=false ENFORCE_FREE_MARGIN=false LIQ_SAFETY=0.8 SIZE_ON_EQUITY=true MAX_NEW_PER_SCAN=10`

## Caveats to tell the user
Sim/validation numbers on synthetic data prove nothing about real edge · paper allows margin > equity (real exchange would reject; set ENFORCE_FREE_MARGIN=true before going live) · old `.env` values override new defaults
