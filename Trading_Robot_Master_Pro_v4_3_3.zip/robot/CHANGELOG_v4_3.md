# CHANGELOG — v4.3 (account freedom, WebSockets, exchange layer, validation lab)
205 tests pass (+27 new). Verified end-to-end on the simulated exchange (robot + dashboard + reset). **Not** verified against live Bybit (no network in the build sandbox) — first run in Codespaces should be watched.

## Your decisions applied
- Paper balance $100 default, any amount via dashboard (Risk tab → Paper account) · **Reset account** closes open trades at live prices, starts a fresh balance, keeps journal history.
- Only setups scoring **>= 85** trade (FILL off) · leverage 10x · risk/trade 1.5% (editable, up to 50%).
- **No caps**: open positions, total exposure, daily loss, consecutive losses all default to `0 = unlimited`. Risk % now applies to *current* balance (`SIZE_ON_EQUITY`). Balance <= 0 blocks trading until reset.
- Honest guard-rails kept (they protect against impossible trades, not against risk): stop must sit inside 80% of the distance to **liquidation**; optional `ENFORCE_FREE_MARGIN` (off for paper, always on live).

## 1. Data feed — WebSockets
- Zero-dependency RFC6455 client (`src/exchanges/ws/miniws.js`) — works on Node 20 (Codespaces default) and 22; cross-checked against the `ws` library (64-bit frames, ping/pong, reconnect).
- Bybit V5 **public** (tickers with delta merge, kline, orderbook snapshot+delta) and **private** (HMAC auth; order/position/execution/wallet, live mode only) streams: exponential back-off reconnect, 20 s heartbeat, stale-socket watchdog, automatic **REST fallback**.
- SL/TP/trailing now evaluate on **every price tick** (was every 5 s). Candle cache: full history once, then tail refresh only (≈5x fewer REST calls); 15m candle patched live by WS.
- Fixed: the scan loop used `market.lastPrice` that could be 15 scans old to move trades.

## 2. Strategy validation
- `npm run validate` (real history, run in Codespaces) / `npm run validate:quick` (offline demo): replays all 9 strategies over many symbols/years, no look-ahead, next-bar entry, fees + slippage + funding + trailing stop.
- Reports expectancy (R), profit factor, win %, max drawdown, trade count **per strategy, per regime, per symbol**; **score sweep** (cost of each minScore); **walk-forward** windows with consistency; **out-of-sample test of regime-aware selection**; **Monte Carlo** (1000 bootstrap runs, fan chart, ruin probabilities).
- `EVIDENCE_GATING=true` mutes strategy×regime pairs with negative validated expectancy (needs >= 30 trades; off by default).
- Dashboard **Strategy Lab** tab: live paper stats per strategy, strategy×regime heat-map, validation report.

## 3. Exchange coupling
- `src/exchanges/index.js` facade; `EXCHANGE=bybit|sim`. New **simulated exchange** (deterministic, offline, Bybit-shaped incl. order book/funding/OI) — demos, CI, repeatable validation. Contract extended in `base.js`.
- **Depth & liquidity**: spread, depth within 1%, walk-the-book slippage, imbalance → veto thin/wide books before entry. **Funding momentum** + **open-interest momentum** (optional crowded-funding veto). **Liquidation price** shown per position.
- Dashboard **Data Feed** tab: WS state/latency/msg rate/reconnects, adapters, per-symbol microstructure table.

## Fixes
Two position tables had mismatched columns (overview header had 14 columns for 19 cells) · "/ 5" hard-coded counter · DB "locked" race when robot and dashboard start together · scanner "latest scan" window.
