'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('../src/config');
const journal = require('../src/journal/store');
const logger = require('../src/utils/logger');
const bybit = require('../src/exchanges');
const dataFeed = require('../src/market/dataFeed');
const { createDefaultRegistry } = require('../src/strategy/registry');
const { defaultNotifier } = require('../src/notifications/index');
const {
  calculateTradeMetrics,
  calculatePortfolioMetrics,
  calculatePerformanceStats,
  calculateRiskStatus,
} = require('../src/dashboard/analytics');
const { getPersistentScanner } = require('../src/scanner/persistentScanner');
const indicators = require('../src/indicators');
const { rankOpportunities } = require('../src/scoring/ranking');
const { generateRecommendations } = require('../src/monitoring/recommendations');
const { eventBus } = require('../src/events/bus');
const { autopsyEngine } = require('../src/learning/autopsy');

const registry = createDefaultRegistry();
const persistentScanner = getPersistentScanner({ registry });

// Lightweight in-memory ticker cache (5s TTL) to prevent spamming Bybit
let cachedTickers = {};
let lastTickerFetch = 0;
let tickersStale = false;

const HEARTBEAT_ALIVE_MS = 20000;

/** Robot liveness comes from its heartbeat (written every few seconds), not from a boolean flag */
function getRobotSync() {
  const hb = journal.getState('robot_heartbeat');
  const ageMs = hb && hb.ts ? Date.now() - hb.ts : null;
  const alive = !!(hb && hb.alive !== false && ageMs !== null && ageMs < HEARTBEAT_ALIVE_MS);
  const dbOpen = journal.getOpenPaperTrades().length;
  const robotOpen = hb && typeof hb.openTrades === 'number' ? hb.openTrades : null;
  return {
    hasHeartbeat: !!hb,
    alive,
    heartbeatAgeMs: ageMs,
    paused: !!(hb && hb.paused),
    pid: hb ? hb.pid : null,
    robotDbPath: hb ? hb.dbPath : null,
    dbPath: journal.getDbPath(),
    robotOpenCount: robotOpen,
    dbOpenCount: dbOpen,
    pendingWrites: hb ? (hb.pendingWrites || 0) : 0,
    dbPathMismatch: !!(hb && hb.dbPath && hb.dbPath !== journal.getDbPath()),
    mismatch: !!(alive && robotOpen !== null && robotOpen !== dbOpen),
  };
}

/**
 * Send a command to the robot process through the shared journal and (optionally) wait for the result.
 * The dashboard never executes trades itself — it only asks the one process that owns the positions.
 */
async function dispatchCommand(type, payload = {}, { wait = true, timeoutMs = 8000 } = {}) {
  const sync = getRobotSync();
  if (!sync.alive) {
    return { status: 'OFFLINE', error: 'Robot process is not running (no heartbeat). Start it with: npm run robot' };
  }
  const id = journal.enqueueCommand(type, payload);
  if (!wait) return { status: 'QUEUED', id };
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    await new Promise(r => setTimeout(r, 120));
    const c = journal.getCommand(id);
    if (c && (c.status === 'DONE' || c.status === 'FAILED')) {
      return { status: c.status, id, result: c.result || {}, error: c.status === 'FAILED' ? (c.result && c.result.error) : null };
    }
  }
  return { status: 'QUEUED', id };
}

async function getLiveTickers() {
  const now = Date.now();
  if (now - lastTickerFetch < 5000 && Object.keys(cachedTickers).length > 0) {
    return cachedTickers;
  }
  try {
    const list = await bybit.getTickers();
    const map = {};
    for (const t of list) {
      map[t.symbol] = {
        lastPrice: parseFloat(t.lastPrice || 0),
        markPrice: parseFloat(t.markPrice || t.lastPrice || 0),
        turnover24h: parseFloat(t.turnover24h || 0),
        fundingRate: parseFloat(t.fundingRate || 0),
      };
    }
    cachedTickers = map;
    lastTickerFetch = now;
    tickersStale = false;
    return cachedTickers;
  } catch (err) {
    logger.warn(`Ticker fetch failed in dashboard: ${err.message}`);
    tickersStale = true;
    return cachedTickers;
  }
}

// ── Chart helpers ─────────────────────────────────────────────────────────
const CHART_INTERVALS = ['1m', '5m', '15m', '1h', '4h', '1d'];
const SYMBOL_RE = /^[A-Z0-9]{2,20}USDT$/;
const chartCache = new Map();      // key -> { at, data }
const chartInflight = new Map();   // key -> Promise

async function getChartCandles(symbol, tf, limit) {
  const key = `${symbol}|${tf}|${limit}`;
  const ttl = (tf === '1m' || tf === '5m') ? 3000 : 10000;
  const hit = chartCache.get(key);
  if (hit && Date.now() - hit.at < ttl) return hit.data;
  if (chartInflight.has(key)) return chartInflight.get(key);
  const p = dataFeed.getCandles(symbol, tf, limit).then(data => {
    chartCache.set(key, { at: Date.now(), data });
    if (chartCache.size > 200) chartCache.delete(chartCache.keys().next().value);
    return data;
  }).finally(() => chartInflight.delete(key));
  chartInflight.set(key, p);
  return p;
}

function parseBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        resolve({});
      }
    });
  });
}

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  // Static Assets
  if (method === 'GET' && (pathname === '/' || pathname === '/index.html')) {
    const htmlPath = path.join(__dirname, 'public', 'index.html');
    if (fs.existsSync(htmlPath)) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store, max-age=0' });
      return fs.createReadStream(htmlPath).pipe(res);
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // DEDICATED MODULAR DASHBOARD ENDPOINTS
  // ══════════════════════════════════════════════════════════════════════════

  // 1. Dashboard Summary: Top header & Account Cards
  if (method === 'GET' && pathname === '/api/dashboard/summary') {
    try {
      const running = journal.getState('robot_running') || false;
      const mode = journal.getState('robot_mode') || config.mode;
      const emergencyStop = journal.getState('emergency_stop') === true;
      const lastScan = journal.getState('last_scan') || null;
      const watchdog = journal.getState('watchdog_status') || { status: 'HEALTHY' };
      const recon = journal.getState('reconciliation_status') || { status: 'HEALTHY' };
      const sync = getRobotSync();

      const tickers = await getLiveTickers();
      const rawOpenPaper = journal.getOpenPaperTrades();
      const rawOpenLive = journal.getOpenLiveTrades();
      const allOpen = [...rawOpenPaper, ...rawOpenLive];

      const enrichedOpen = allOpen.map(t => {
        const mark = tickers[t.symbol]?.markPrice || t.entry;
        return calculateTradeMetrics(t, mark, config.defaultLeverage);
      });

      const closedPaper = journal.getClosedPaperTrades(500);
      const closedLive = journal.getClosedLiveTrades(500);
      const allClosed = [...closedPaper, ...closedLive];

      const portfolio = calculatePortfolioMetrics(
        enrichedOpen,
        config.accountBalance,
        config.defaultLeverage,
        allClosed,
        config.maxPortfolioExposure
      );

      let operationalState = 'PAPER';
      if (emergencyStop) operationalState = 'EMERGENCY_STOP';
      else if (mode === 'LIVE') operationalState = config.liveEnabled ? 'LIVE_AUTHORIZED' : 'LIVE_LOCKED';

      let status;
      if (emergencyStop) status = 'EMERGENCY_STOP';
      else if (sync.hasHeartbeat) status = sync.alive ? (sync.paused ? 'PAUSED' : 'RUNNING') : 'OFFLINE';
      else status = running ? 'RUNNING' : 'STOPPED';

      return sendJson(res, 200, {
        status,
        sync,
        tickersStale,
        serverTime: Date.now(),
        operationalState,
        mode,
        isLive: mode === 'LIVE' && config.liveEnabled,
        liveTradingEnabled: config.liveEnabled,
        emergencyStop,
        running,
        lastScan,
        lastMarketUpdate: lastTickerFetch || Date.now(),
        watchdog,
        reconciliation: recon,
        portfolio,
        maxOpenPositions: config.maxOpenPositions,
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 2. Open Positions: Live Mark Price, Notional, Margin, Progress Bar
  if (method === 'GET' && pathname === '/api/dashboard/positions') {
    try {
      const tickers = await getLiveTickers();
      const rawOpenPaper = journal.getOpenPaperTrades();
      const rawOpenLive = journal.getOpenLiveTrades();
      const allOpen = [...rawOpenPaper, ...rawOpenLive];

      // Fetched ONCE (was once per position)
      let recentSignals = [];
      try { recentSignals = journal.getRecentSignals(30); } catch (_) { /* ignore */ }

      try { await require('../src/exchanges/rules').refresh(); } catch (_) { /* rules optional */ }
      const positions = allOpen.map(t => {
        const tk = tickers[t.symbol];
        const live = tk && (tk.markPrice || tk.lastPrice);
        const mark = live || t.entry;
        const priceSource = live ? (tickersStale ? 'STALE' : 'LIVE') : 'ENTRY_FALLBACK';
        const metrics = calculateTradeMetrics(t, mark, config.defaultLeverage);

        let conditions = {};
        try {
          const matched = recentSignals.find(s => s.symbol === t.symbol && s.direction === t.direction);
          if (matched && matched.conditions) {
            conditions = typeof matched.conditions === 'string' ? JSON.parse(matched.conditions) : matched.conditions;
          }
        } catch (_) { /* ignore */ }

        const { liquidationPrice } = require('../src/risk/engine');
        const liqPrice = liquidationPrice(metrics.direction, metrics.entry, config.defaultLeverage, config.maintenanceMarginRate);
        const distToLiqPct = liqPrice && mark ? parseFloat((Math.abs(mark - liqPrice) / mark * 100).toFixed(2)) : null;
        const sigLike = { symbol: t.symbol, direction: metrics.direction, entry: metrics.entry, stopLoss: t.initial_stop_loss ?? metrics.stopLoss, takeProfit: metrics.takeProfit };
        let ticket = null, freshness = null;
        try { ticket = require('../src/exchanges/rules').buildTicket(sigLike); } catch (_) { /* ignore */ }
        try { freshness = require('../src/signals/expiry').evaluate({ ...sigLike, openTime: t.open_time }, mark); } catch (_) { /* ignore */ }
        return {
          id: t.id,
          openTime: t.open_time || null,
          ticket, freshness,
          ...metrics,
          liqPrice, distToLiqPct,
          conditions,
          priceSource,
          trailingActive: !!t.trailing_active,
          trailingStop: t.trailing_stop ?? null,
          initialStopLoss: t.initial_stop_loss ?? null,
        };
      });

      return sendJson(res, 200, {
        positions,
        count: positions.length,
        leverage: config.defaultLeverage,
        tickersStale,
        serverTime: Date.now(),
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 3. Scanner Command Center: Counts & Table with "Why Not Trade"
  if (method === 'GET' && pathname === '/api/dashboard/scanner') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '300', 10);
      const totalScanned = journal.getState('market_count') || 0;
      const rawSignals = journal.getLatestScanSignals(limit);
      const openSyms = new Set([...journal.getOpenPaperTrades(), ...journal.getOpenLiveTrades()].map(t => t.symbol));
      const scanSummary = journal.getState('last_scan_summary') || null;

      let fillCount = 0;
      let qualifiedCount = 0;
      let watchCount = 0;
      let rejectedCount = 0;
      let dqBlockedCount = 0;

      const signals = rawSignals.map(s => {
        const score = s.score || 0;
        const decision = s.decision || '';
        const reason = s.rejection_reason || s.rejectionReason || '';
        const isDQ = decision === 'DATA_QUALITY_BLOCK' || reason.includes('DATA_QUALITY');

        if (isDQ) dqBlockedCount++;
        else if (decision === 'FILL') { fillCount++; qualifiedCount++; }
        else if (s.qualified === 1 || decision === 'TRADE') qualifiedCount++;
        else if (score >= 75 && score < 85) watchCount++;
        else rejectedCount++;

        let regimeStr = 'UNCERTAIN';
        if (s.regime) {
          try {
            const parsed = typeof s.regime === 'string' ? JSON.parse(s.regime) : s.regime;
            regimeStr = parsed.regime || s.regime;
          } catch (_) { regimeStr = s.regime; }
        }

        let conditionObj = {};
        if (s.conditions) {
          try {
            conditionObj = typeof s.conditions === 'string' ? JSON.parse(s.conditions) : s.conditions;
          } catch (_) {}
        }

        const metrics = calculateTradeMetrics(s, s.entry, config.defaultLeverage);
        // Sizing preview for setups that have no open trade yet: what WOULD be risked / won at current risk settings
        const ent = s.entry || 0, slv = s.stop_loss || 0, tpv = s.take_profit || 0;
        if (ent && slv && tpv && Math.abs(ent - slv) > 0) {
          const ov = journal.getState('config_overrides') || {};
          const riskAmt = (ov.accountBalance || config.accountBalance) * (ov.riskPerTrade || config.riskPerTrade);
          const size = riskAmt / Math.abs(ent - slv);
          metrics.riskAmount = parseFloat(riskAmt.toFixed(2));
          metrics.expectedReward = parseFloat((size * Math.abs(tpv - ent)).toFixed(2));
        }

        return {
          id: s.id,
          symbol: s.symbol,
          strategyId: s.strategy_id,
          strategyName: s.strategy_name,
          direction: s.direction || '—',
          score,
          decision,
          tier: decision === 'FILL' ? 'FILL' : ((s.qualified === 1 || decision === 'TRADE') ? 'QUALIFIED' : null),
          opened: openSyms.has(s.symbol),
          qualified: !!s.qualified || decision === 'TRADE' || decision === 'FILL',
          regime: regimeStr,
          cluster: s.cluster || metrics.cluster,
          entry: s.entry || 0,
          stopLoss: s.stop_loss || s.stopLoss || 0,
          takeProfit: s.take_profit || s.takeProfit || 0,
          riskReward: s.risk_reward || s.riskReward || 0,
          riskAmount: metrics.riskAmount,
          expectedReward: metrics.expectedReward,
          rejectionReason: reason || (score < config.minScore ? `Score ${score} < minimum ${config.minScore}` : 'None'),
          timestamp: s.timestamp,
          conditions: conditionObj,
          mode: s.mode || 'PAPER',
        };
      });

      return sendJson(res, 200, {
        totalScanned,
        qualifiedCount,
        fillCount,
        watchCount,
        rejectedCount,
        dqBlockedCount,
        scanSummary,
        targetOpenPositions: config.targetOpenPositions,
        signals,
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 4. Performance & Analytics: Equity curves, Expectancy, R-distribution
  if (method === 'GET' && pathname === '/api/dashboard/performance') {
    try {
      const closedPaper = journal.getClosedPaperTrades(1000);
      const closedLive = journal.getClosedLiveTrades(1000);
      const allClosed = [...closedPaper, ...closedLive];

      const stats = calculatePerformanceStats(allClosed, config.accountBalance);
      return sendJson(res, 200, stats);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 5. Risk Command Center: Real exposure, cluster bars, circuit breakers
  if (method === 'GET' && pathname === '/api/dashboard/risk') {
    try {
      const perf = journal.getState('performance') || {};
      const riskStatus = perf.riskStatus || {};
      const rawOpenPaper = journal.getOpenPaperTrades();
      const rawOpenLive = journal.getOpenLiveTrades();
      const allOpen = [...rawOpenPaper, ...rawOpenLive];

      const riskState = calculateRiskStatus(riskStatus, config, allOpen, config.accountBalance);
      return sendJson(res, 200, riskState);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 6. Strategy Configuration & Explanations
  if (method === 'GET' && pathname === '/api/dashboard/strategy') {
    try {
      const strat = registry.get('gps_v1') || {};
      const conditionsMeta = [
        { key: 'trend4H', name: '4H Trend Alignment', weight: 20, description: '4H Higher Highs/Lows structure and EMA trend direction' },
        { key: 'sweep', name: 'Liquidity Sweep', weight: 10, description: 'Key swing high or low swept to capture opposing liquidity' },
        { key: 'reclaim', name: 'Structure Reclaim', weight: 10, description: 'Price closes back inside key level indicating fakeout absorption' },
        { key: 'structure1H', name: '1H Structure', weight: 15, description: '1H trend consistency and swing alignment' },
        { key: 'trigger15M', name: '15M Trigger Bar', weight: 15, description: 'Confirmation candle close in direction of the setup' },
        { key: 'rsi', name: 'RSI Momentum', weight: 10, description: 'RSI(14) not overbought on Longs (<70) or oversold on Shorts (>30)' },
        { key: 'alligator', name: 'Williams Alligator', weight: 8, description: 'Jaw, Teeth, and Lips properly fanned in trend alignment' },
        { key: 'volume', name: 'Volume Ratio Surge', weight: 7, description: 'Current volume >= 1.2x of 20-period moving average' },
        { key: 'funding', name: 'Funding Rate Bias', weight: 3, description: 'Negative/neutral funding for Longs, positive/neutral for Shorts' },
        { key: 'openInterest', name: 'Open Interest Status', weight: 2, description: 'Open interest data verified available from exchange' },
      ];

      const ov = journal.getState('strategy_overrides') || {};
      const strategies = registry.status().map(x => ({ ...x, enabled: ov[x.id] !== undefined ? !!ov[x.id] : x.enabled }));
      return sendJson(res, 200, {
        strategies,
        strategyMode: config.strategyMode,
        strategy: {
          id: strat.id || 'gps_v1',
          name: strat.name || 'GPS',
          version: strat.version || '1.0.0',
          enabled: strat.enabled !== false,
          timeframes: '4H / 1H / 15M',
          minScore: config.minScore,
          minRR: config.minRR,
          riskPerTradePct: (config.riskPerTrade * 100) + '%',
          leverage: config.defaultLeverage + 'x',
          conditions: conditionsMeta,
        },
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 7. System Health Matrix
  if (method === 'GET' && pathname === '/api/dashboard/system') {
    try {
      const running = journal.getState('robot_running') || false;
      const lastScan = journal.getState('last_scan') || null;
      const scanCount = journal.getState('scan_count') || 0;
      const emergencyStop = journal.getState('emergency_stop') === true;
      const watchdog = journal.getState('watchdog_status') || { status: 'HEALTHY' };
      const recon = journal.getState('reconciliation_status') || { status: 'HEALTHY' };
      const notifications = defaultNotifier.getRecentDeliveries();

      // Quick Bybit Ping
      let bybitStatus = 'CONNECTED';
      let bybitLatency = 0;
      const pingStart = Date.now();
      try {
        await bybit.getServerTime();
        bybitLatency = Date.now() - pingStart;
      } catch (e) {
        bybitStatus = 'ERROR';
      }

      // Quick Database Latency
      let dbStatus = 'HEALTHY';
      let dbLatency = 0;
      const dbStart = Date.now();
      try {
        journal.getDb().prepare('SELECT 1').get();
        dbLatency = Date.now() - dbStart;
      } catch (e) {
        dbStatus = 'ERROR';
      }

      return sendJson(res, 200, {
        marketData: {
          status: bybitStatus === 'CONNECTED' ? 'CONNECTED' : 'STALE',
          latencyMs: bybitLatency,
        },
        bybitApi: {
          status: bybitStatus,
          latencyMs: bybitLatency,
          environment: config.bybit.testnet ? 'TESTNET' : 'MAINNET',
        },
        database: {
          status: dbStatus,
          engine: 'SQLite WAL (Native)',
          latencyMs: dbLatency,
        },
        scanner: {
          status: running ? 'RUNNING' : 'STOPPED',
          lastScan,
          scanCount,
        },
        paperEngine: {
          status: getRobotSync().alive ? 'RUNNING' : 'OFFLINE',
          openTradesCount: journal.getOpenPaperTrades().length,
        },
        sync: getRobotSync(),
        liveEngine: {
          status: config.liveEnabled ? 'ENABLED' : 'LOCKED (SAFETY GATED)',
          mode: config.mode,
          state: emergencyStop ? 'EMERGENCY_STOP' : (config.isLive ? 'LIVE_AUTHORIZED' : 'LIVE_LOCKED'),
        },
        watchdog,
        reconciliation: recon,
        notifications: {
          channels: {
            telegram: config.notifications.telegram.enabled,
            email: config.notifications.email.enabled,
            whatsapp: config.notifications.whatsapp.enabled,
          },
          recentDeliveries: notifications.slice(0, 10),
        },
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 8. Chart endpoint: candles (+indicators), trade levels, trade markers, incremental updates
  if (method === 'GET' && pathname.startsWith('/api/dashboard/chart/')) {
    try {
      const symbol = decodeURIComponent(pathname.replace('/api/dashboard/chart/', '')).toUpperCase().trim();
      if (!SYMBOL_RE.test(symbol)) {
        return sendJson(res, 400, { error: 'Invalid symbol. Expected a Bybit USDT perpetual such as BTCUSDT.' });
      }
      const reqInterval = parsedUrl.searchParams.get('interval') || '15m';
      const tf = CHART_INTERVALS.includes(reqInterval) ? reqInterval : '15m';
      const limit = Math.min(500, Math.max(50, parseInt(parsedUrl.searchParams.get('limit') || '300', 10) || 300));
      const sinceSec = parseInt(parsedUrl.searchParams.get('since') || '0', 10) || 0;
      const wanted = (parsedUrl.searchParams.get('indicators') || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);

      const raw = await getChartCandles(symbol, tf, limit);
      const candles = raw.map(c => ({
        time: Math.floor(c.time / 1000),
        open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume,
      }));

      // Indicators are computed on the whole window, then trimmed for incremental requests
      const trim = (arr) => (sinceSec ? arr.filter(p => p.time >= sinceSec) : arr);
      const line = (vals) => trim(vals
        .map((v, i) => ({ time: candles[i].time, value: v }))
        .filter(p => Number.isFinite(p.value)));
      const ind = {};
      if (wanted.includes('ema20')) ind.ema20 = line(indicators.ema(candles.map(c => c.close), 20));
      if (wanted.includes('ema50')) ind.ema50 = line(indicators.ema(candles.map(c => c.close), 50));
      if (wanted.includes('vwap')) ind.vwap = line(indicators.vwap(candles));

      const lastClose = candles.length ? candles[candles.length - 1].close : null;

      // Levels: an OPEN TRADE always wins; a signal is only a hint and is labelled as such
      const openTrades = [...journal.getOpenPaperTrades(), ...journal.getOpenLiveTrades()];
      const trade = openTrades.find(t => t.symbol === symbol);
      let levels = null;
      if (trade) {
        const tickers = await getLiveTickers();
        const mark = (tickers[symbol] && (tickers[symbol].markPrice || tickers[symbol].lastPrice)) || lastClose || trade.entry;
        const dir = String(trade.direction || 'LONG').toUpperCase();
        const pnl = (dir === 'LONG' ? mark - trade.entry : trade.entry - mark) * (trade.position_size || 0);
        levels = {
          source: 'OPEN_TRADE',
          tradeId: trade.id,
          direction: dir,
          entry: trade.entry,
          stopLoss: trade.stop_loss,
          takeProfit: trade.take_profit,
          trailingStop: trade.trailing_stop ?? null,
          trailingActive: !!trade.trailing_active,
          initialStopLoss: trade.initial_stop_loss ?? null,
          strategy: trade.strategy_name || trade.strategy_id || null,
          score: trade.score ?? null,
          markPrice: mark,
          unrealizedPnl: parseFloat(pnl.toFixed(4)),
          openTime: Math.floor((trade.open_time || 0) / 1000),
        };
      } else {
        const sig = journal.getRecentSignals(30).find(x => x.symbol === symbol && x.qualified);
        if (sig) {
          levels = {
            source: 'SIGNAL',
            direction: sig.direction,
            entry: sig.entry,
            stopLoss: sig.stop_loss || sig.stopLoss,
            takeProfit: sig.take_profit || sig.takeProfit,
            trailingStop: null,
            strategy: sig.strategy_name || null,
            score: sig.score ?? null,
            markPrice: lastClose,
            unrealizedPnl: null,
            signalTime: Math.floor((sig.timestamp || 0) / 1000),
          };
        }
      }

      const trades = journal.getTradesBySymbol(symbol, 30).map(t => ({
        id: t.id,
        side: String(t.direction || '').toUpperCase(),
        entry: t.entry,
        openTime: Math.floor((t.open_time || 0) / 1000),
        closeTime: t.close_time ? Math.floor(t.close_time / 1000) : null,
        exitPrice: t.exit_price ?? null,
        pnl: t.pnl ?? null,
        outcome: t.outcome || null,
        exitReason: t.exit_reason || null,
        open: !t.close_time,
        mode: t.mode,
      }));

      return sendJson(res, 200, {
        symbol,
        interval: tf,
        candles: sinceSec ? candles.filter(c => c.time >= sinceSec) : candles,
        incremental: !!sinceSec,
        levels,
        trades,
        indicators: ind,
        stale: tickersStale,
        serverTime: Date.now(),
      });
    } catch (err) {
      return sendJson(res, 502, { error: `Chart data unavailable: ${err.message}` });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BACKWARD COMPATIBILITY ENDPOINTS (Preserved)
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/status') {
    try {
      const running = journal.getState('robot_running') || false;
      const mode = journal.getState('robot_mode') || config.mode;
      const marketCount = journal.getState('market_count') || 0;
      const scanCount = journal.getState('scan_count') || 0;
      const lastScan = journal.getState('last_scan') || null;
      const emergencyStop = journal.getState('emergency_stop') === true;
      const watchdogStatus = journal.getState('watchdog_status') || { status: 'HEALTHY' };
      const reconStatus = journal.getState('reconciliation_status') || { status: 'HEALTHY' };
      const perf = journal.getState('performance') || {
        mode,
        totalTrades: 0,
        openTrades: 0,
        wins: 0,
        losses: 0,
        winRate: 0,
        netPnl: 0,
        returnPct: 0,
        currentBalance: config.accountBalance,
      };

      const recentSignals = journal.getRecentSignals(15);
      const paperTrades = journal.getPaperTrades(25);
      const liveTrades = journal.getLiveTrades(25);
      const recentAlerts = journal.getRecentAlerts(20);

      let operationalState = 'PAPER';
      if (emergencyStop) operationalState = 'EMERGENCY_STOP';
      else if (mode === 'LIVE') operationalState = config.liveEnabled ? 'LIVE_AUTHORIZED' : 'LIVE_LOCKED';

      return sendJson(res, 200, {
        status: emergencyStop ? 'EMERGENCY_STOP' : (running ? 'RUNNING' : 'STOPPED'),
        operationalState,
        mode,
        liveTradingEnabled: config.liveEnabled,
        tradingEnabled: !emergencyStop,
        marketCount,
        scanCount,
        lastScan,
        performance: perf,
        watchdog: watchdogStatus,
        reconciliation: reconStatus,
        strategies: registry.status(),
        recentSignals,
        paperTrades,
        liveTrades,
        recentAlerts,
        config: {
          minScore: config.minScore,
          minRR: config.minRR,
          riskPerTrade: config.riskPerTrade,
          maxOpenPositions: config.maxOpenPositions,
          maxPortfolioExposure: config.maxPortfolioExposure,
          maxCorrelatedExposure: config.maxCorrelatedExposure,
          maxDailyLoss: config.maxDailyLoss,
          defaultLeverage: config.defaultLeverage,
        },
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/signals') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '50', 10);
      const signals = journal.getRecentSignals(limit);
      return sendJson(res, 200, { signals });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/trades') {
    try {
      const lim = Math.min(2000, parseInt(parsedUrl.searchParams.get('limit') || '300', 10));
      const paper = journal.getPaperTrades(lim);
      const live = journal.getLiveTrades(lim);
      return sendJson(res, 200, { paper, live });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/alerts') {
    try {
      const alerts = journal.getRecentAlerts(50);
      const notifications = defaultNotifier.getRecentDeliveries();
      return sendJson(res, 200, { alerts, notifications });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // Control APIs
  if (method === 'POST' && pathname === '/api/control/start') {
    const wasEmergency = journal.getState('emergency_stop') === true;
    journal.setState('emergency_stop', false);
    logger.info('Control Panel: Robot START (resume) requested');
    let robot = { status: 'OFFLINE' };
    if (wasEmergency) robot = await dispatchCommand('EMERGENCY_RESET', {}, { wait: false });
    robot = await dispatchCommand('RESUME', {}, { wait: false });
    return sendJson(res, 200, {
      ok: true,
      robotAlive: robot.status !== 'OFFLINE',
      message: robot.status === 'OFFLINE'
        ? 'Robot process is not running — start it with: npm run robot'
        : 'Resume command sent to robot',
    });
  }

  if (method === 'POST' && pathname === '/api/control/stop') {
    logger.info('Control Panel: Robot PAUSE requested');
    const robot = await dispatchCommand('PAUSE', {}, { wait: false });
    return sendJson(res, 200, {
      ok: true,
      robotAlive: robot.status !== 'OFFLINE',
      message: robot.status === 'OFFLINE'
        ? 'Robot process is not running'
        : 'Pause command sent — no new entries; open positions keep being managed',
    });
  }

  if (method === 'POST' && pathname === '/api/control/emergency-stop') {
    journal.setState('emergency_stop', true);
    logger.risk('Control Panel: EMERGENCY STOP triggered');
    await dispatchCommand('EMERGENCY_STOP', {}, { wait: false });
    await defaultNotifier.notifyEmergencyStop('Triggered from UI Control Panel');
    return sendJson(res, 200, { ok: true, message: 'EMERGENCY STOP activated' });
  }

  if (method === 'POST' && pathname === '/api/control/emergency-reset') {
    journal.setState('emergency_stop', false);
    logger.risk('Control Panel: Emergency stop reset');
    await dispatchCommand('EMERGENCY_RESET', {}, { wait: false });
    return sendJson(res, 200, { ok: true, message: 'Emergency stop state cleared' });
  }

  // Strategy Management
  if (method === 'POST' && pathname === '/api/strategy/rename') {
    const body = await parseBody(req);
    const { id, newName } = body;
    if (!id || !newName) return sendJson(res, 400, { error: 'id and newName required' });
    try {
      registry.rename(id, newName);
      const strat = registry.get(id);
      if (strat) journal.saveStrategy(strat);
      return sendJson(res, 200, { ok: true, id, newName });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/strategy/toggle') {
    const body = await parseBody(req);
    const { id, enabled } = body;
    if (!id || enabled === undefined) return sendJson(res, 400, { error: 'id and enabled required' });
    try {
      registry.setEnabled(id, !!enabled);
      const strat = registry.get(id);
      if (strat) journal.saveStrategy(strat);
      // The robot owns the strategies that actually trade — tell it too (previously only this process changed)
      const r = await dispatchCommand('STRATEGY_TOGGLE', { id, enabled: !!enabled });
      if (r.status === 'OFFLINE') {
        const st = journal.getState('strategy_overrides') || {}; st[id] = !!enabled; journal.setState('strategy_overrides', st);
      }
      return sendJson(res, 200, { ok: true, id, enabled: !!enabled, robotApplied: r.status === 'DONE' });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PERSISTENT SCANNER ENDPOINTS
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/scanner/state') {
    return sendJson(res, 200, persistentScanner.getState());
  }

  if (method === 'POST' && pathname === '/api/scanner/start') {
    try {
      const state = await persistentScanner.start();
      journal.setState('robot_running', true);
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/pause') {
    try {
      const state = await persistentScanner.pause();
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/resume') {
    try {
      const state = await persistentScanner.resume();
      journal.setState('robot_running', true);
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/stop') {
    try {
      const state = await persistentScanner.stop();
      journal.setState('robot_running', false);
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/restart') {
    try {
      const state = await persistentScanner.restartFullScan();
      journal.setState('robot_running', true);
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/rescan-failed') {
    try {
      const state = await persistentScanner.rescanFailed();
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // POSITION MANAGEMENT ENDPOINTS
  // ══════════════════════════════════════════════════════════════════════════

  function replyToCommand(res, r, okBody) {
    if (r.status === 'OFFLINE') return sendJson(res, 409, { ok: false, error: r.error });
    if (r.status === 'FAILED') {
      const notFound = /not found/i.test(r.error || '');
      return sendJson(res, notFound ? 404 : 422, { ok: false, error: r.error });
    }
    if (r.status === 'QUEUED') {
      return sendJson(res, 202, { ok: true, queued: true, commandId: r.id, message: 'Command queued — the robot has not confirmed yet' });
    }
    return sendJson(res, 200, { ok: true, ...okBody(r.result || {}) });
  }

  if (method === 'POST' && (pathname.startsWith('/api/positions/close/') || pathname === '/api/positions/close')) {
    const body = await parseBody(req);
    const id = decodeURIComponent(pathname.replace('/api/positions/close/', '')) || body.id;
    if (!id || id === '/api/positions/close') {
      return sendJson(res, 400, { error: 'Position ID is required' });
    }
    const r = await dispatchCommand('CLOSE_POSITION', { id, reason: body.reason || 'MANUAL_DASHBOARD_CLOSE' });
    return replyToCommand(res, r, (result) => ({ closed: result.closed }));
  }

  if (method === 'POST' && pathname === '/api/positions/close-all') {
    const body = await parseBody(req);
    const r = await dispatchCommand('CLOSE_ALL', { reason: body.reason || 'MANUAL_DASHBOARD_CLOSE_ALL' }, { timeoutMs: 15000 });
    return replyToCommand(res, r, (result) => ({ count: result.count || 0, closed: result.closed || [], failed: result.failed || [] }));
  }

  // ══════════════════════════════════════════════════════════════════════════
  // CONFIGURATION UPDATE ENDPOINT ($100 default, $50-$500, leverage, risk)
  // ══════════════════════════════════════════════════════════════════════════

  // ── Data feed / exchange / microstructure status (written by the robot) ──
  if (method === 'GET' && pathname === '/api/dashboard/feed') {
    try {
      const feed = journal.getState('feed_status') || null;
      const hb = getRobotSync();
      return sendJson(res, 200, { feed, robotAlive: !!hb.alive, micro: journal.getState('micro') || {}, exchange: require('../src/exchanges').info(),
        limits: { maxSpreadBps: config.maxSpreadBps, maxSlipBps: config.maxSlipBps, minDepthMultiple: config.minDepthMultiple, fundingVeto: config.fundingVeto, microChecks: config.microChecks, wsEnabled: config.wsEnabled } });
    } catch (err) { return sendJson(res, 500, { error: err.message }); }
  }

  // ── Live strategy performance (from the robot's closed paper trades) ──
  if (method === 'GET' && pathname === '/api/dashboard/strategy-stats') {
    try { return sendJson(res, 200, require('../src/validation/liveStats').computeLiveStats(journal.getClosedPaperTrades(20000))); }
    catch (err) { return sendJson(res, 500, { error: err.message }); }
  }

  // ── Latest offline validation report (npm run validate) ──
  if (method === 'GET' && pathname === '/api/validation/latest') {
    try {
      const ev = require('../src/validation/evidence'); ev.reset();
      const r = ev.load();
      return sendJson(res, 200, r ? { available: true, report: r, gating: config.evidenceGating } : { available: false, hint: 'Run: npm run validate   (or npm run validate:quick for an offline demo on simulated data)' });
    } catch (err) { return sendJson(res, 500, { error: err.message }); }
  }

  // ── Paper account snapshot ──
  if (method === 'GET' && pathname === '/api/dashboard/account') {
    try {
      const perf = journal.getState('performance') || {};
      const ov = journal.getState('config_overrides') || {};
      const epoch = journal.getState('account_epoch') || null;
      const tickers = await getLiveTickers();
      const open = [...journal.getOpenPaperTrades()];
      let unreal = 0, margin = 0;
      for (const t of open) { const px = tickers[t.symbol]?.markPrice || t.entry; const m = calculateTradeMetrics(t, px, config.defaultLeverage); unreal += m.unrealizedPnl; margin += m.margin; }
      const balance = perf.currentBalance ?? ov.accountBalance ?? config.accountBalance;
      const equity = balance + unreal;
      return sendJson(res, 200, { balance: +balance.toFixed(2), equity: +equity.toFixed(2), unrealized: +unreal.toFixed(2), usedMargin: +margin.toFixed(2),
        freeMargin: +(equity - margin).toFixed(2), marginUsedPct: equity > 0 ? +(margin / equity * 100).toFixed(1) : null, openCount: open.length,
        riskPerTrade: ov.riskPerTrade || config.riskPerTrade, leverage: config.defaultLeverage, depleted: balance <= 0, epoch,
        limits: { maxOpenPositions: ov.maxOpenPositions ?? config.maxOpenPositions, maxDailyLoss: ov.maxDailyLoss ?? config.maxDailyLoss, enforceFreeMargin: config.enforceFreeMargin } });
    } catch (err) { return sendJson(res, 500, { error: err.message }); }
  }

  if (method === 'POST' && pathname === '/api/account/reset') {
    const body = await parseBody(req);
    const balance = parseFloat(body.balance);
    if (!(balance > 0)) return sendJson(res, 400, { ok: false, error: 'balance must be a positive number' });
    const r = await dispatchCommand('RESET_ACCOUNT', { balance }, { timeoutMs: 15000 });
    return replyToCommand(res, r, (result) => ({ balance: result.balance, closed: result.closed }));
  }

  if (method === 'POST' && pathname === '/api/config/update') {
    const body = await parseBody(req);
    if (body.accountBalance !== undefined) {
      const b = parseFloat(body.accountBalance);
      if (b > 0) {
        config.accountBalance = b;
      }
    }
    if (body.riskPerTrade !== undefined) {
      const r = parseFloat(body.riskPerTrade);
      if (r > 0 && r <= 0.5) {
        config.riskPerTrade = r;
      }
    }
    if (body.defaultLeverage !== undefined) {
      const lev = parseInt(body.defaultLeverage, 10);
      if (lev >= 1 && lev <= 100) {
        config.defaultLeverage = lev;
      }
    }
    if (body.maxOpenPositions !== undefined) {
      const m = parseInt(body.maxOpenPositions, 10);
      if (m >= 0 && m <= 1000) {
        config.maxOpenPositions = m;
      }
    }
    if (body.maxDailyLoss !== undefined) {
      const mdl = parseFloat(body.maxDailyLoss);
      if (mdl >= 0 && mdl <= 1) {
        config.maxDailyLoss = mdl;
      }
    }

    // Persist as overrides (robot re-applies them after a restart) and push to the live robot
    const overrides = { ...(journal.getState('config_overrides') || {}) };
    if (body.accountBalance !== undefined && parseFloat(body.accountBalance) > 0) overrides.accountBalance = parseFloat(body.accountBalance);
    if (body.riskPerTrade !== undefined && parseFloat(body.riskPerTrade) > 0 && parseFloat(body.riskPerTrade) <= 0.5) overrides.riskPerTrade = parseFloat(body.riskPerTrade);
    if (body.maxOpenPositions !== undefined && parseInt(body.maxOpenPositions, 10) >= 0 && parseInt(body.maxOpenPositions, 10) <= 1000) overrides.maxOpenPositions = parseInt(body.maxOpenPositions, 10);
    if (body.maxDailyLoss !== undefined && parseFloat(body.maxDailyLoss) >= 0 && parseFloat(body.maxDailyLoss) <= 1) overrides.maxDailyLoss = parseFloat(body.maxDailyLoss);
    journal.setState('config_overrides', overrides);
    const pushed = await dispatchCommand('CONFIG_UPDATE', overrides, { wait: false });

    logger.info(`Dashboard config updated: Balance=$${config.accountBalance}, Risk=${(config.riskPerTrade * 100).toFixed(2)}%, Lev=${config.defaultLeverage}x`);

    return sendJson(res, 200, {
      ok: true,
      appliedToRobot: pushed.status !== 'OFFLINE',
      config: {
        accountBalance: config.accountBalance,
        riskPerTrade: config.riskPerTrade,
        defaultLeverage: config.defaultLeverage,
        maxOpenPositions: config.maxOpenPositions,
        maxDailyLoss: config.maxDailyLoss,
      },
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // GLOBAL OPPORTUNITY BOARD & RECOMMENDATIONS
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/dashboard/opportunities') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '200', 10);
      const rawSignals = journal.getLatestScanSignals(limit);
      const openTrades = [...journal.getOpenPaperTrades(), ...journal.getOpenLiveTrades()];
      const ranked = rankOpportunities(rawSignals, { openPositions: openTrades });
      return sendJson(res, 200, { count: ranked.length, opportunities: ranked });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/dashboard/recommendations') {
    try {
      const openTrades = [...journal.getOpenPaperTrades(), ...journal.getOpenLiveTrades()];
      const rawSignals = journal.getRecentSignals(30);
      const perf = journal.getState('performance') || {};
      const watchdog = journal.getState('watchdog_status') || { status: 'HEALTHY' };
      const recs = generateRecommendations({
        openPositions: openTrades,
        recentSignals: rawSignals,
        performance: perf,
        config,
        systemHealth: { watchdog },
      });
      return sendJson(res, 200, recs);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // JOURNAL EXPORT (CSV / JSON)
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/journal/export') {
    try {
      const format = (parsedUrl.searchParams.get('format') || 'json').toLowerCase();
      const paperTrades = journal.getPaperTrades(10000);
      const liveTrades = journal.getLiveTrades(10000);
      const allTrades = [...paperTrades, ...liveTrades];

      if (format === 'xlsx' || format === 'excel') {
        const { buildJournalXlsx } = require('../src/journal/export');
        const buf = buildJournalXlsx(allTrades);
        res.writeHead(200, {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'Content-Disposition': `attachment; filename="gps_journal_${new Date().toISOString().slice(0, 10)}.xlsx"`,
          'Content-Length': buf.length,
          'Cache-Control': 'no-cache',
        });
        return res.end(buf);
      }

      if (format === 'csv') {
        const headers = [
          'id', 'timestamp', 'date', 'symbol', 'assetClass', 'strategy', 'regime', 'direction',
          'entry', 'exitPrice', 'stopLoss', 'takeProfit', 'positionSize', 'leverage',
          'accountBalance', 'riskPct', 'riskReward', 'fee', 'slippage', 'pnl',
          'outcome', 'exitReason', 'score', 'mode'
        ];

        const rows = allTrades.map(t => {
          const dt = t.close_time ? new Date(t.close_time).toISOString() : (t.open_time ? new Date(t.open_time).toISOString() : '');
          return [
            `"${t.id || ''}"`,
            t.close_time || t.open_time || '',
            `"${dt}"`,
            `"${t.symbol || ''}"`,
            `"${t.asset_class || 'CRYPTO'}"`,
            `"${t.strategy_name || t.strategy_id || 'GPS'}"`,
            `"${typeof t.regime === 'object' ? JSON.stringify(t.regime) : (t.regime || '')}"`,
            `"${t.direction || ''}"`,
            t.entry || '',
            t.exit_price || '',
            t.stop_loss || '',
            t.take_profit || '',
            t.position_size || '',
            config.defaultLeverage,
            config.accountBalance,
            (config.riskPerTrade * 100) + '%',
            t.risk_reward || '',
            t.fee || 0,
            t.slippage || 0,
            t.pnl || 0,
            `"${t.outcome || ''}"`,
            `"${t.exit_reason || ''}"`,
            t.score || '',
            `"${t.mode || 'PAPER'}"`,
          ].join(',');
        });

        const csvString = [headers.join(','), ...rows].join('\n');
        res.writeHead(200, {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': `attachment; filename="journal_export_${Date.now()}.csv"`,
          'Cache-Control': 'no-cache',
        });
        return res.end(csvString);
      }

      // Default JSON export
      res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="journal_export_${Date.now()}.json"`,
        'Cache-Control': 'no-cache',
      });
      return res.end(JSON.stringify({
        exportedAt: Date.now(),
        accountBalance: config.accountBalance,
        totalTrades: allTrades.length,
        trades: allTrades,
      }, null, 2));
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SYSTEM SNAPSHOTS
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'POST' && pathname === '/api/snapshot/save') {
    try {
      const openTrades = [...journal.getOpenPaperTrades(), ...journal.getOpenLiveTrades()];
      const scannerState = persistentScanner.getState();
      const rawSignals = journal.getRecentSignals(10);
      const ranked = rankOpportunities(rawSignals, { openPositions: openTrades });

      const snapshot = {
        id: crypto.randomUUID(),
        timestamp: Date.now(),
        accountState: {
          balance: config.accountBalance,
          defaultLeverage: config.defaultLeverage,
          riskPerTrade: config.riskPerTrade,
          maxDailyLoss: config.maxDailyLoss,
        },
        positions: openTrades,
        scannerState,
        topOpportunities: ranked.slice(0, 5),
        riskSettings: {
          maxOpenPositions: config.maxOpenPositions,
          maxPortfolioExposure: config.maxPortfolioExposure,
          maxCorrelatedExposure: config.maxCorrelatedExposure,
        },
        summary: `Snapshot at ${new Date().toISOString()} | ${openTrades.length} open positions | Scanner: ${scannerState.progressPct}%`,
      };

      journal.saveSnapshot(snapshot);
      logger.info(`System snapshot saved: ${snapshot.id}`);
      return sendJson(res, 200, { ok: true, snapshotId: snapshot.id, snapshot });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/snapshot/list') {
    try {
      const list = journal.getSnapshots(20);
      return sendJson(res, 200, { count: list.length, snapshots: list });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname.startsWith('/api/snapshot/')) {
    try {
      const id = pathname.replace('/api/snapshot/', '');
      const list = journal.getSnapshots(100);
      const found = list.find(s => s.id === id);
      if (!found) return sendJson(res, 404, { error: 'Snapshot not found' });
      return sendJson(res, 200, found);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // LEARNING, AUTOPSIES & SIMILARITY
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/learning/autopsies') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '50', 10);
      const list = journal.getAutopsies(limit);
      return sendJson(res, 200, { count: list.length, autopsies: list });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/learning/similarity') {
    try {
      const symbol = parsedUrl.searchParams.get('symbol') || '';
      const strategyId = parsedUrl.searchParams.get('strategy') || '';
      const direction = parsedUrl.searchParams.get('direction') || '';
      const regime = parsedUrl.searchParams.get('regime') || '';

      const match = autopsyEngine.findSimilarSetups({
        symbol,
        strategyId,
        direction,
        regime,
      });

      return sendJson(res, 200, match);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // EVENT BUS STREAM / RECENT EVENTS
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/events/recent') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '50', 10);
      const filter = parsedUrl.searchParams.get('event') || null;
      // Robot events live in the shared journal; this process's own bus is merged in too.
      const fromDb = journal.getRecentEventsDb(limit, filter);
      const fromBus = eventBus.getRecentEvents(limit, filter);
      const events = [...fromDb, ...fromBus].sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0)).slice(0, limit);
      return sendJson(res, 200, { count: events.length, events });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // Server-Sent Events: pushes robot events (position opened/closed/trailing...) to the browser
  if (method === 'GET' && pathname === '/api/stream') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-store',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
      'Access-Control-Allow-Origin': '*',
    });
    let lastId = parseInt(req.headers['last-event-id'] || parsedUrl.searchParams.get('lastId') || '', 10);
    if (!Number.isFinite(lastId)) lastId = journal.getLatestEventId();
    res.write('retry: 3000\n\n');
    res.write(`event: hello\ndata: ${JSON.stringify({ lastId, ts: Date.now() })}\n\n`);
    const tick = setInterval(() => {
      try {
        for (const e of journal.getEventsSince(lastId, 100)) {
          lastId = e.id;
          res.write(`id: ${e.id}\nevent: ${e.event}\ndata: ${JSON.stringify(e)}\n\n`);
        }
      } catch (_) { /* DB busy — next tick */ }
    }, 1000);
    const ping = setInterval(() => { try { res.write(': ping\n\n'); } catch (_) { /* closed */ } }, 15000);
    req.on('close', () => { clearInterval(tick); clearInterval(ping); });
    return;
  }

  // Fallback 404
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Endpoint Not Found' }));
});

if (require.main === module) {
  const port = config.dashboardPort || 3000;
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      logger.error(`Port ${port} is already in use — an older copy of the dashboard is probably still running.`);
      logger.error(`Fix: stop it with   pkill -f dashboard/server.js ; pkill -f src/robot.js   — or use another port: DASHBOARD_PORT=3001 npm run dashboard`);
      process.exit(1);
    }
    throw err;
  });
  server.listen(port, () => {
    logger.info(`GPS Command Center Dashboard running on http://localhost:${port}`);
    logger.info(`DATABASE: ${journal.getDbPath()}  (PID ${process.pid})`);
    if (process.env.CODESPACE_NAME && process.env.GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN) {
      logger.info(`Codespaces URL: https://${process.env.CODESPACE_NAME}-${port}.${process.env.GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN}`);
    }
    setTimeout(() => {
      if (!getRobotSync().alive) logger.warn('No robot heartbeat — start the trading robot (npm run robot) or run both together: npm run start:all');
    }, 10000).unref();
  });
}

module.exports = server;
