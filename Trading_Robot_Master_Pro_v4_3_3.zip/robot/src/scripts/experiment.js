'use strict';

const ExperimentEngine = require('../backtest/experiment');

async function main() {
  const args = process.argv.slice(2);
  function getArg(name, def) {
    const a = args.find(a => a.startsWith(`--${name}=`));
    return a ? a.split('=')[1] : def;
  }

  const symbol = getArg('symbol', 'SOLUSDT');
  const type   = getArg('type', 'score'); // score | rr | volume

  console.log('\n═══ GPS ROBOT — EXPERIMENT ENGINE ═══\n');
  console.log(`Symbol:     ${symbol}`);
  console.log(`Test type:  ${type}`);
  console.log('');

  const engine = new ExperimentEngine();
  let configs;

  if (type === 'rr')     configs = ExperimentEngine.rrThresholds();
  else if (type === 'volume') configs = ExperimentEngine.volumeThresholds();
  else configs = ExperimentEngine.scoreThresholds();

  console.log(`Configurations to test: ${configs.map(c => c.label).join(', ')}`);
  console.log('Fetching data and running backtests...\n');

  const result = await engine.run(symbol, configs);

  console.log(`── RESULTS: ${result.symbol} ──\n`);
  console.log('Config'.padEnd(22) + 'Trades'.padEnd(8) + 'Win%'.padEnd(8) + 'ProfitFactor'.padEnd(14) + 'Expectancy'.padEnd(12) + 'AvgR'.padEnd(8) + 'MaxDD%');
  console.log('─'.repeat(80));

  for (const exp of result.experiments) {
    if (exp.status !== 'COMPLETE' || !exp.outOfSample) {
      console.log(`${exp.label.padEnd(22)} ERROR: ${exp.error || exp.status}`);
      continue;
    }
    const m = exp.outOfSample;
    console.log(
      exp.label.padEnd(22) +
      String(m.totalTrades).padEnd(8) +
      String(m.winRate + '%').padEnd(8) +
      String(m.profitFactor).padEnd(14) +
      String(m.expectancy).padEnd(12) +
      String(m.avgR).padEnd(8) +
      String(m.maxDrawdownPct + '%')
    );
    if (exp.warning) console.log(`  ${exp.warning}`);
  }

  if (result.comparison) {
    console.log('\n── RANKED (by out-of-sample Profit Factor) ──\n');
    result.comparison.ranked.forEach((r, i) => {
      console.log(`  #${i + 1}: ${r.label}  PF=${r.profitFactor}  WinRate=${r.winRate}%  Trades=${r.totalTrades}${r.smallSample ? ' ⚠ small' : ''}`);
    });
    console.log(`\n  Best: ${result.comparison.best?.label || 'N/A'}`);
    console.log(`  Note: ${result.comparison.note}`);
  }

  console.log(`\n${result.summary.note}`);
  process.exit(0);
}

main().catch(err => { console.error('Experiment failed:', err.message); process.exit(1); });
