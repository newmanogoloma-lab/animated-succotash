'use strict';

/**
 * npm run validate                     -> top-liquidity symbols on the active exchange, 1 year
 * npm run validate -- --years=3 --top=15 --step=4 --sims=2000
 * npm run validate -- --exchange=sim --quick      (offline, deterministic, ~1 minute)
 * Candles are cached in data/history so reruns are fast. Writes data/validation/latest.json + reports/VALIDATION_REPORT.md
 */
const fs = require('fs');
const path = require('path');
const arg = (n, d) => { const a = process.argv.slice(2).find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : (process.argv.includes(`--${n}`) ? true : d); };
if (arg('exchange')) process.env.EXCHANGE = arg('exchange');
const config = require('../config');
const exchange = require('../exchanges');
const { validate } = require('../validation/validator');
const evidence = require('../validation/evidence');
const { discoverMarkets } = require('../market/universe');

const quick = !!arg('quick', false);
const years = parseFloat(arg('years', quick ? 0.35 : 1));
const top = parseInt(arg('top', quick ? 4 : 12), 10);
const step = parseInt(arg('step', quick ? 8 : 4), 10);
const sims = parseInt(arg('sims', 1000), 10);
const minScore = parseFloat(arg('minScore', config.minScore));
const HIST = path.join(path.dirname(evidence.DIR), 'history');

async function loadCandles(sym, yrs) {
  fs.mkdirSync(HIST, { recursive: true });
  const f = path.join(HIST, `${config.exchange}_${sym}_15_${yrs}.json`);
  if (config.exchange !== 'sim' && fs.existsSync(f) && Date.now() - fs.statSync(f).mtimeMs < 86400000 && !arg('refresh', false)) return JSON.parse(fs.readFileSync(f, 'utf8'));
  const c = await exchange.getKlineHistory(sym, '15', Math.round(yrs * 35040));
  if (config.exchange !== 'sim') fs.writeFileSync(f, JSON.stringify(c));
  return c;
}

function markdown(r) {
  const f = (x) => (x === null || x === undefined ? '—' : x);
  const lines = [`# Strategy Validation Report`, '', `Generated ${new Date(r.generatedAt).toISOString()} · exchange **${r.exchange}** · ${r.symbols.length} symbols · ${r.spanDays} days · minScore ${r.minScore} · risk/trade ${(r.riskPerTrade * 100).toFixed(2)}%`,
    `Costs: fee ${(r.costs.feePerSide * 100).toFixed(3)}%/side, slippage ${(r.costs.slippagePerSide * 100).toFixed(3)}%/side, funding ${(r.costs.funding8h * 100).toFixed(3)}%/8h, trailing stop on.`, '',
    `## Headline (score >= ${r.minScore})`, `Trades ${r.headline.trades} · win ${r.headline.winRate}% · expectancy ${r.headline.expectancyR}R · PF ${r.headline.profitFactor} · maxDD ${r.headline.maxDrawdownR}R · sample ${r.headline.sample}`, '',
    '## Per strategy', '| Strategy | Trades | Win % | Expectancy R | PF | Max DD R | Sample |', '|---|---|---|---|---|---|---|',
    ...r.strategies.map(s => `| ${s.name} | ${s.trades} | ${s.winRate} | ${s.expectancyR} | ${s.profitFactor} | ${s.maxDrawdownR} | ${s.sample} |`), '',
    '## Score sweep (what each minScore costs / earns)', '| minScore | Trades | Trades/day | Expectancy R | PF | Win % |', '|---|---|---|---|---|---|',
    ...r.scoreSweep.map(s => `| ${s.minScore} | ${s.trades} | ${f(s.perDay)} | ${s.expectancyR} | ${s.profitFactor} | ${s.winRate} |`), '',
    '## Regime selection test (out-of-sample)', `${r.selectionTest.verdict} — unfiltered ${r.selectionTest.unfiltered.trades} trades @ ${r.selectionTest.unfiltered.expectancyR}R vs selected ${r.selectionTest.selected.trades} trades @ ${r.selectionTest.selected.expectancyR}R`, '',
    '## Monte Carlo', r.monteCarlo ? `Final equity P5/P50/P95: ${r.monteCarlo.finalEquity.p5} / ${r.monteCarlo.finalEquity.p50} / ${r.monteCarlo.finalEquity.p95} · P(profit) ${r.monteCarlo.probProfit}% · median max DD ${r.monteCarlo.maxDrawdown.p50}% (P95 ${r.monteCarlo.maxDrawdown.p95}%) · P(DD>=50%) ${r.monteCarlo.probDrawdown50}%` : 'Not enough trades.', '',
    '## Warnings', ...(r.warnings.length ? r.warnings.map(w => `- ${w}`) : ['- none']), ''];
  return lines.join('\n');
}

(async () => {
  console.log(`\n═══ STRATEGY VALIDATION — exchange=${config.exchange} years=${years} top=${top} step=${step} minScore=${minScore} ═══`);
  const symbols = arg('symbols', null) ? String(arg('symbols')).split(',') : (await discoverMarkets(true)).slice(0, top).map(m => m.symbol);
  console.log(`Symbols: ${symbols.join(', ')}\n`);
  const report = await validate({ exchange, symbols, years, step, sims, minScore, loadCandles,
    onProgress: (p) => { if (p.stage === 'replay') console.log(`  replaying ${p.symbol} (${p.i + 1}/${p.n}, ${p.candles} candles)`); if (p.stage === 'skip') console.log(`  skipped ${p.symbol}: ${p.reason}`); } });
  fs.mkdirSync(evidence.DIR, { recursive: true });
  fs.writeFileSync(evidence.latestPath(), JSON.stringify(report));
  fs.writeFileSync(path.join(evidence.DIR, `report_${new Date().toISOString().slice(0, 10)}.json`), JSON.stringify(report));
  const md = markdown(report);
  const outDir = path.resolve(__dirname, '..', '..', 'reports'); fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, 'VALIDATION_REPORT.md'), md);
  console.log('\n' + md);
  console.log(`Saved: ${evidence.latestPath()}  and  reports/VALIDATION_REPORT.md  (open the "Strategy Lab" tab in the dashboard)`);
  process.exit(0);
})().catch(e => { console.error('Validation failed:', e.message); process.exit(1); });
