'use strict';

const { discoverMarkets } = require('../market/universe');
const dataFeed = require('../market/dataFeed');
const { createDefaultRegistry } = require('../strategy/registry');
const { scoreSignal, formatRejection } = require('../scoring/engine');

async function main() {
  console.log('\n═══ GPS ROBOT — MARKET SCAN ═══\n');

  const concurrency = Math.max(
    1,
    parseInt(process.env.SCAN_CONCURRENCY || '8', 10)
  );

  const startTime = Date.now();
  const scanMarkets = await discoverMarkets(true);
  console.log(`Scanning ${scanMarkets.length} markets (concurrency: ${concurrency})...\n`);

  const registry = createDefaultRegistry();
  const results = [];
  let completed = 0;
  let errors = 0;

  async function scanMarket(market) {
    try {
      const [mtf, meta] = await Promise.all([
        dataFeed.getMultiTimeframe(
          market.symbol,
          ['4h', '1h', '15m'],
          200
        ),
        dataFeed.getMarketMeta(market.symbol),
      ]);

      const signals = await registry.evaluateAll({
        symbol: market.symbol,
        candles4H: mtf['4h'],
        candles1H: mtf['1h'],
        candles15M: mtf['15m'],
        meta: { symbol: market.symbol, ...meta },
      });

      return signals.map(signal => scoreSignal(signal));
    } catch (err) {
      errors++;
      return [];
    }
  }

  for (let i = 0; i < scanMarkets.length; i += concurrency) {
    const batch = scanMarkets.slice(i, i + concurrency);
    const batchResults = await Promise.all(
      batch.map(scanMarket)
    );

    for (const scoredSignals of batchResults) {
      results.push(...scoredSignals);
    }

    completed += batch.length;
    process.stdout.write(
      `\rProgress: ${completed}/${scanMarkets.length}`
    );
  }

  process.stdout.write('\n\n');

  const durationSec = ((Date.now() - startTime) / 1000).toFixed(1);

  const qualified = results.filter(r => r.decision === 'TRADE');
  const developing = results.filter(r => r.score >= 75 && r.score < 85 && r.direction);
  const noTrade = results.filter(r => r.decision === 'NO_TRADE' && r.direction);

  console.log('── QUALIFIED SETUPS ──');
  if (qualified.length === 0) {
    console.log('  No qualified setups at this time.');
  } else {
    for (const s of qualified.sort((a, b) => b.score - a.score)) {
      console.log(`  ${s.symbol.padEnd(14)} ${s.direction.padEnd(6)} Score: ${s.score}/100  R:R: ${s.riskReward}  Entry: ${s.entry}`);
    }
  }

  console.log('\n── DEVELOPING (75-84) ──');
  if (developing.length === 0) {
    console.log('  None');
  } else {
    for (const s of developing.sort((a, b) => b.score - a.score).slice(0, 5)) {
      console.log(`  ${s.symbol.padEnd(14)} ${s.direction.padEnd(6)} Score: ${s.score}/100  ${s.rejectionReason || ''}`);
    }
  }

  console.log(`\n── SUMMARY ──`);
  console.log(`  Scanned:   ${scanMarkets.length} markets`);
  console.log(`  Qualified: ${qualified.length}`);
  console.log(`  Developing: ${developing.length}`);
  console.log(`  No Trade:  ${noTrade.length}`);
  console.log(`  Errors:    ${errors}`);
  console.log(`  Duration:  ${durationSec}s`);

  process.exit(0);
}

main().catch(err => { console.error(err.message); process.exit(1); });
