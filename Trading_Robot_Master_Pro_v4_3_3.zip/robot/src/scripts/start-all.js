'use strict';

/**
 * Starts the trading robot AND the dashboard together with one command:  npm run start:all
 *
 * Both processes are launched from the repository root, so they always share the same
 * database (data/robot.db). Output of each process is prefixed so you can tell them apart.
 * Ctrl+C stops both cleanly. If one process dies, the other is stopped too (no half-running state).
 */

const { spawn } = require('child_process');
const net = require('net');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const extraArgs = process.argv.slice(2);   // e.g. --mode=paper is forwarded to the robot

// Initialise the database ONCE here, before the two child processes start, so they never
// race to create the schema (Codespaces' slower disk made that race possible).
try {
  const store = require('../journal/store');
  const rep = store.checkDb();
  process.stdout.write(`[DB] ready: ${rep.path} (journal=${rep.journalMode}, tables ok, integrity=${rep.integrity})\n`);
} catch (e) {
  process.stderr.write(`[DB] FAILED to initialise database: ${e.message}\nRun: npm run db:check   (or npm run db:reset -- --yes to start clean)\n`);
  process.exit(1);
}

// Pick a free dashboard port. DASHBOARD_PORT (or PORT) is preferred; if it is taken (usually an older copy
// still running in another terminal) use the next free one instead of crashing.
function isFree(port) {
  return new Promise(resolve => {
    const t = net.createServer().once('error', () => resolve(false)).once('listening', () => t.close(() => resolve(true)));
    t.listen(port);
  });
}
async function pickPort() {
  const want = parseInt(process.env.DASHBOARD_PORT || process.env.PORT || '3000', 10);
  for (let p = want; p < want + 20; p++) {
    if (await isFree(p)) {
      if (p !== want) {
        process.stdout.write(`[PORT] ${want} is already in use (older copy still running?) — using ${p} instead.\n`
          + `[PORT] To stop the old copy:  pkill -f dashboard/server.js ; pkill -f src/robot.js\n`);
      }
      return p;
    }
  }
  process.stderr.write(`[PORT] No free port found from ${want} to ${want + 19}.\n`);
  process.exit(1);
}

const procs = [
  { name: 'ROBOT    ', color: '\x1b[36m', args: ['src/robot.js', ...extraArgs] },
  { name: 'DASHBOARD', color: '\x1b[35m', args: ['dashboard/server.js'] },
];

let shuttingDown = false;
const children = [];

function pipe(stream, prefix, out) {
  let buf = '';
  stream.on('data', chunk => {
    buf += chunk.toString();
    const lines = buf.split('\n');
    buf = lines.pop();
    for (const l of lines) out.write(`${prefix} ${l}\n`);
  });
}

function shutdown(code = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  for (const c of children) { try { c.kill('SIGTERM'); } catch (_) { /* already gone */ } }
  setTimeout(() => process.exit(code), 1500);
}

let PORT;
(async () => {
  PORT = await pickPort();
  for (const p of procs) {
    const child = spawn(process.execPath, p.args, { cwd: ROOT, env: { ...process.env, DASHBOARD_PORT: String(PORT) }, stdio: ['ignore', 'pipe', 'pipe'] });
    const prefix = `${p.color}[${p.name}]\x1b[0m`;
    pipe(child.stdout, prefix, process.stdout);
    pipe(child.stderr, prefix, process.stderr);
    child.on('exit', (code, signal) => {
      if (shuttingDown) return;
      process.stderr.write(`${prefix} exited (code=${code}, signal=${signal}) — stopping everything\n`);
      shutdown(code || 1);
    });
    children.push(child);
  }
})();

process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));
