'use strict';

const { discoverMarkets, getReferenceMarkets } = require('../market/universe');

async function main() {
  console.log('\n═══ GPS ROBOT — MARKET UNIVERSE ═══\n');

  const [markets, refs] = await Promise.all([
    discoverMarkets(true),
    getReferenceMarkets().catch(() => []),
  ]);

  if (refs.length) {
    console.log('── Market Reference ──');
    for (const r of refs) {
      const chg = (r.change24h * 100).toFixed(2);
      console.log(`  ${r.symbol.padEnd(12)} $${r.lastPrice.toFixed(2).padStart(10)}  24h: ${chg}%`);
    }
    console.log();
  }

  console.log(`── Eligible Markets (${markets.length}) ──`);
  console.log('  SYMBOL         PRICE        VOLUME 24H (USDT)');
  for (const m of markets.slice(0, 50)) {
    const vol = (m.vol24hUSDT / 1e6).toFixed(1) + 'M';
    console.log(`  ${m.symbol.padEnd(14)} ${m.lastPrice.toFixed(4).padStart(12)}  ${vol.padStart(10)}`);
  }
  if (markets.length > 50) {
    console.log(`  ... and ${markets.length - 50} more`);
  }

  console.log(`\nTotal: ${markets.length} markets`);
  process.exit(0);
}

main().catch(err => { console.error(err.message); process.exit(1); });
