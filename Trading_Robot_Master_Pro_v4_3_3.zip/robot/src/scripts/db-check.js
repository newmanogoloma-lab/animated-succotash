'use strict';
/**
 * Database doctor.
 *   npm run db:check            -> create/repair schema if needed, print health report
 *   npm run db:reset -- --yes   -> back up data/robot.db (+wal/shm) then start from a fresh DB
 *   npm run setup               -> copy .env.example -> .env if missing, then db:check
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const args = process.argv.slice(2);

if (args.includes('--setup') && !fs.existsSync(path.join(ROOT, '.env'))) {
  fs.copyFileSync(path.join(ROOT, '.env.example'), path.join(ROOT, '.env'));
  console.log('Created .env from .env.example');
}

const store = require('../journal/store');
const dbPath = store.getDbPath();

if (args.includes('--reset')) {
  if (!args.includes('--yes')) {
    console.log(`This moves ${dbPath} aside (backup, not delete) and creates a fresh DB. Re-run with:  npm run db:reset -- --yes`);
    process.exit(1);
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  for (const suffix of ['', '-wal', '-shm']) {
    const f = dbPath + suffix;
    if (fs.existsSync(f)) { fs.renameSync(f, `${dbPath}.bak-${stamp}${suffix}`); console.log(`Backed up ${f}`); }
  }
}

try {
  const r = store.checkDb();
  console.log(`\nDatabase : ${r.path}`);
  console.log(`Size     : ${r.sizeBytes} bytes | journal=${r.journalMode} | schema v${r.userVersion} | integrity=${r.integrity}`);
  console.log(`Missing  : ${r.missing.length ? r.missing.join(', ') : 'none'}`);
  for (const [t, n] of Object.entries(r.rows)) console.log(`  ${t.padEnd(20)} ${n} rows`);
  process.exit(r.missing.length || r.integrity !== 'ok' ? 1 : 0);
} catch (e) {
  console.error(`DB check FAILED: ${e.message}`);
  process.exit(1);
}
