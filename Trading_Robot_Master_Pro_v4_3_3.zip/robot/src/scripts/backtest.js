'use strict';

const Backtester = require('../backtest/engine');

async function main() {
  const args = process.argv.slice(2);

  // Parse --symbol=SOLUSDT style args
  function getArg(name, def) {
    const a = args.find(a => a.startsWith(`--${name}=`));
    return a ? a.split('=')[1] : def;
  }

  const symbol  = getArg('symbol', 'SOLUSDT');
  const minScore = parseFloat(getArg('minScore', '85'));
  const minRR    = parseFloat(getArg('minRR', '2.0'));

  console.log('\n═══ GPS ROBOT — BACKTESTER ═══\n');
  console.log(`Symbol:    ${symbol}`);
  console.log(`Min Score: ${minScore}`);
  console.log(`Min R:R:   ${minRR}`);
  console.log('');

  const strategyConfig = { minScore, minRR };
  const backtester = new Backtester(strategyConfig);

  console.log('Fetching historical data (this may take a moment)...\n');

  const result = await backtester.run(symbol, { maxCandles: 2000 });

  if (result.status === 'INCOMPLETE') {
    console.log(`BACKTEST INCOMPLETE — ${result.reason}`);
    process.exit(0);
  }

  console.log(`Status:   ${result.status}`);
  console.log(`Symbol:   ${result.symbol}`);
  console.log(`Period:   ${result.period}`);
  console.log(`Candles:  4H=${result.candles['4h']} | 1H=${result.candles['1h']} | 15M=${result.candles['15m']}`);
  console.log(`Strategy: ${result.strategy.name} v${result.strategy.version}`);
  console.log();

  for (const section of [result.inSample, result.outOfSample]) {
    console.log(`── ${section.label} ──`);
    console.log(`  Period:           ${section.period}`);
    console.log(`  Trades:           ${section.totalTrades}`);
    if (section.totalTrades === 0) {
      console.log('  No trades generated in this period.');
      console.log();
      continue;
    }
    console.log(`  Wins/Losses:      ${section.wins}/${section.losses}`);
    console.log(`  Win Rate:         ${section.winRate}%`);
    console.log(`  Net Profit:       ${section.netProfit}`);
    console.log(`  Return:           ${section.returnPct}%`);
    console.log(`  Profit Factor:    ${section.profitFactor}`);
    console.log(`  Expectancy:       ${section.expectancy}`);
    console.log(`  Average R:        ${section.avgR}`);
    console.log(`  Max Drawdown:     ${section.maxDrawdownPct}%`);
    console.log(`  Largest Win:      ${section.largestWin}`);
    console.log(`  Largest Loss:     ${section.largestLoss}`);
    console.log(`  Win Streak:       ${section.winStreak}`);
    console.log(`  Loss Streak:      ${section.lossStreak}`);
    console.log(`  Avg Duration:     ${section.avgDurationH}h`);
    console.log(`  Long/Short:       ${section.longTrades}/${section.shortTrades}`);
    console.log();
  }

  if (result.outOfSample?.totalTrades < 20) {
    console.log('⚠ WARNING: Small sample size. Results may not be statistically reliable.');
  }

  process.exit(0);
}

main().catch(err => { console.error('Backtest failed:', err.message); process.exit(1); });
