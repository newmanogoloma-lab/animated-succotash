'use strict';
/**
 * Signal freshness for manual trading.
 *  FRESH   : price still inside the entry zone (within +/- tolR x R of entry, or pulled back toward SL by less than adverseR)
 *  EXPIRED : price ran past entry in the profit direction by more than tolR (don't chase),
 *            OR pulled back more than adverseR toward the stop (setup weakened),
 *            OR the signal is older than maxAgeMin.
 * R = |entry - stop|.
 */
const config = require('../config');

function evaluate(sig, mark, now = Date.now(), cfg = config.signalExpiry || {}) {
  const tolR = cfg.entryToleranceR ?? 0.25, adverseR = cfg.adverseExpireR ?? 0.6, maxAgeMin = cfg.maxAgeMin ?? 240;
  const long = String(sig.direction).toUpperCase() === 'LONG';
  const R = Math.abs(sig.entry - (sig.initialStopLoss ?? sig.stopLoss));
  const ageMin = sig.openTime ? (now - sig.openTime) / 60000 : null;
  if (!R || !mark) return { status: 'UNKNOWN', reason: null, movedR: null, ageMin, label: '—' };
  const movedR = (long ? mark - sig.entry : sig.entry - mark) / R; // + = in profit direction
  if (movedR > tolR) return { status: 'EXPIRED', reason: 'RAN_AWAY', movedR, ageMin, label: `EXPIRED · passed entry (+${movedR.toFixed(2)}R)` };
  if (movedR < -adverseR) return { status: 'EXPIRED', reason: 'WEAKENED', movedR, ageMin, label: `EXPIRED · ${movedR.toFixed(2)}R against` };
  if (ageMin !== null && ageMin > maxAgeMin) return { status: 'EXPIRED', reason: 'OLD', movedR, ageMin, label: `EXPIRED · older than ${Math.round(maxAgeMin / 60)}h` };
  return { status: 'FRESH', reason: null, movedR, ageMin, label: movedR < -0.05 ? `FRESH · pullback ${movedR.toFixed(2)}R` : 'FRESH · in entry zone' };
}

module.exports = { evaluate };
