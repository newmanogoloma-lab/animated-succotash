'use strict';

const dataFeed = require('../market/dataFeed');
const GPSStrategy = require('../strategy/gps');
const { scoreSignal } = require('../scoring/engine');
const RiskEngine = require('../risk/engine');
const logger = require('../utils/logger');
const config = require('../config');

const FEE_RATE = 0.00055; // Bybit taker fee

/**
 * Historical Backtester
 *
 * Rules:
 * - Chronological candle processing — never look ahead
 * - Each evaluation point uses only candles UP TO that point
 * - Simulates entry, SL hit, TP hit
 * - Records every simulated trade
 * - Accounts for fees
 */
class Backtester {
  constructor(strategyConfig = {}, riskConfig = {}) {
    this.strategyConfig = strategyConfig;
    this.riskConfig = riskConfig;
  }

  /**
   * Run backtest for a symbol
   * @param {string} symbol
   * @param {object} options — { startDate, endDate, maxCandles, inSampleRatio }
   */
  async run(symbol, options = {}) {
    const {
      maxCandles = 2000,
      inSampleRatio = 0.7,   // 70% in-sample, 30% out-of-sample
    } = options;

    let candles4H, candles1H, candles15M;
    if (options.candles) {
      candles4H = options.candles.candles4H || [];
      candles1H = options.candles.candles1H || [];
      candles15M = options.candles.candles15M || [];
    } else {
      logger.info(`BACKTEST: ${symbol} — fetching historical data...`);
      [candles4H, candles1H, candles15M] = await Promise.all([
        dataFeed.getHistoricalCandles(symbol, '4h', Math.min(maxCandles, 2000)),
        dataFeed.getHistoricalCandles(symbol, '1h', Math.min(maxCandles * 4, 5000)),
        dataFeed.getHistoricalCandles(symbol, '15m', Math.min(maxCandles * 16, 10000)),
      ]);
    }

    if (candles4H.length < 50) {
      return {
        status: 'INCOMPLETE',
        reason: 'INSUFFICIENT HISTORICAL DATA — fewer than 50 4H candles',
        symbol,
        candles4H: candles4H.length,
      };
    }

    // Split into in-sample / out-of-sample based on 4H candle count
    const splitIndex4H = Math.floor(candles4H.length * inSampleRatio);

    const inSample4H  = candles4H.slice(0, splitIndex4H);
    const outSample4H = candles4H.slice(splitIndex4H);

    logger.info(`${symbol}: ${candles4H.length} × 4H candles | ${candles1H.length} × 1H | ${candles15M.length} × 15M`);
    logger.info(`In-sample: ${inSample4H.length} | Out-of-sample: ${outSample4H.length}`);

    const inResult  = this._runOnCandles(symbol, inSample4H,  candles1H, candles15M, 'IN-SAMPLE');
    const outResult = this._runOnCandles(symbol, outSample4H, candles1H, candles15M, 'OUT-OF-SAMPLE');

    const periodStart = new Date(candles4H[0].time).toISOString().slice(0, 10);
    const periodEnd   = new Date(candles4H[candles4H.length - 1].time).toISOString().slice(0, 10);

    return {
      status: 'COMPLETE',
      symbol,
      period: `${periodStart} → ${periodEnd}`,
      candles: {
        '4h': candles4H.length,
        '1h': candles1H.length,
        '15m': candles15M.length,
      },
      strategy: {
        id: 'gps_v1',
        name: this.strategyConfig.name || 'GPS',
        version: '1.0.0',
        configuration: this.strategyConfig,
      },
      inSample:    { ...inResult,  label: 'IN-SAMPLE' },
      outOfSample: { ...outResult, label: 'OUT-OF-SAMPLE' },
    };
  }

  /** Run simulation on a candle set */
  _runOnCandles(symbol, candles4H, allCandles1H, allCandles15M, label) {
    const strategy = new GPSStrategy(this.strategyConfig);
    const riskEngine = new RiskEngine({
      ...this.riskConfig,
      accountBalance: this.riskConfig.accountBalance || config.accountBalance,
    });

    const trades = [];
    const openTrade = { active: false };
    let balance = riskEngine.cfg.accountBalance;
    const startBalance = balance;

    // Walk through 4H candles chronologically
    for (let i = 50; i < candles4H.length - 1; i++) {
      const c4H = candles4H.slice(0, i + 1);

      if (openTrade.active) {
        // Check SL/TP on subsequent candles
        const nextCandle = candles4H[i + 1];
        const result = this._checkTrade(openTrade, nextCandle);
        if (result) {
          const fee = openTrade.positionSize * openTrade.entry * FEE_RATE * 2;
          const pnl = result.pnl - fee;
          balance += pnl;
          riskEngine.onTradeClosed(pnl);

          trades.push({
            ...openTrade,
            exitPrice:  result.exitPrice,
            exitTime:   nextCandle.time,
            result:     result.outcome,
            pnl:        parseFloat(pnl.toFixed(4)),
            fee:        parseFloat(fee.toFixed(4)),
            balanceAfter: parseFloat(balance.toFixed(4)),
            duration:   Math.round((nextCandle.time - openTrade.entryTime) / (3600 * 1000)),
          });
          openTrade.active = false;
        }
        continue;
      }

      // Get aligned 1H and 15M candles (no look-ahead)
      const cutoff = c4H[c4H.length - 1].time;
      const c1H  = allCandles1H.filter(c => c.time <= cutoff);
      const c15M = allCandles15M.filter(c => c.time <= cutoff);

      if (c1H.length < 30 || c15M.length < 20) continue;

      // Evaluate strategy
      const signal = strategy.evaluate({
        symbol,
        candles4H: c4H,
        candles1H: c1H.slice(-200),
        candles15M: c15M.slice(-200),
        meta: { symbol, fundingRate: null, openInterest: null },
      });

      const scored = scoreSignal(signal, {
        minScore: this.strategyConfig.minScore,
        minRR: this.strategyConfig.minRR,
      });

      if (scored.decision !== 'TRADE') continue;

      const riskCheck = riskEngine.check(signal, trades.filter(t => t.active));
      if (!riskCheck.approved) continue;

      // Open simulated trade
      openTrade.active = true;
      openTrade.symbol = symbol;
      openTrade.direction = signal.direction;
      openTrade.entry = signal.entry;
      openTrade.stopLoss = signal.stopLoss;
      openTrade.takeProfit = signal.takeProfit;
      openTrade.riskReward = signal.riskReward;
      openTrade.score = signal.score;
      openTrade.entryTime = c4H[c4H.length - 1].time;
      openTrade.positionSize = riskCheck.positionSize;
      openTrade.strategyId = signal.strategyId;
      openTrade.strategyVersion = signal.strategyVersion;
    }

    if (trades.length === 0) {
      return this._emptyMetrics(label, candles4H);
    }

    return this._calcMetrics(trades, startBalance, label, candles4H);
  }

  _checkTrade(trade, candle) {
    const { direction, entry, stopLoss, takeProfit, positionSize } = trade;

    if (direction === 'LONG') {
      if (candle.low <= stopLoss) {
        const pnl = (stopLoss - entry) * positionSize;
        return { outcome: 'LOSS', exitPrice: stopLoss, pnl };
      }
      if (candle.high >= takeProfit) {
        const pnl = (takeProfit - entry) * positionSize;
        return { outcome: 'WIN', exitPrice: takeProfit, pnl };
      }
    } else {
      if (candle.high >= stopLoss) {
        const pnl = (entry - stopLoss) * positionSize;
        return { outcome: 'LOSS', exitPrice: stopLoss, pnl };
      }
      if (candle.low <= takeProfit) {
        const pnl = (entry - takeProfit) * positionSize;
        return { outcome: 'WIN', exitPrice: takeProfit, pnl };
      }
    }
    return null;
  }

  _calcMetrics(trades, startBalance, label, candles4H) {
    const wins   = trades.filter(t => t.result === 'WIN');
    const losses = trades.filter(t => t.result === 'LOSS');
    const longs  = trades.filter(t => t.direction === 'LONG');
    const shorts = trades.filter(t => t.direction === 'SHORT');

    const netPnl  = trades.reduce((s, t) => s + t.pnl, 0);
    const avgWin  = wins.length   ? wins.reduce((s, t) => s + t.pnl, 0) / wins.length   : 0;
    const avgLoss = losses.length ? losses.reduce((s, t) => s + Math.abs(t.pnl), 0) / losses.length : 0;
    const grossProfit = wins.reduce((s, t) => s + t.pnl, 0);
    const grossLoss   = Math.abs(losses.reduce((s, t) => s + t.pnl, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0;
    const expectancy = trades.length ? netPnl / trades.length : 0;
    const avgR = trades.length ? trades.reduce((s, t) => {
      const riskAmt = Math.abs(t.entry - t.stopLoss) * t.positionSize;
      return s + (riskAmt > 0 ? t.pnl / riskAmt : 0);
    }, 0) / trades.length : 0;

    // Drawdown
    let peak = startBalance;
    let balance = startBalance;
    let maxDD = 0;
    let maxDDPct = 0;
    for (const t of trades) {
      balance += t.pnl;
      if (balance > peak) peak = balance;
      const dd = peak - balance;
      const ddPct = peak > 0 ? dd / peak : 0;
      if (dd > maxDD) { maxDD = dd; maxDDPct = ddPct; }
    }

    // Streaks
    let winStreak = 0, lossStreak = 0, curWin = 0, curLoss = 0;
    for (const t of trades) {
      if (t.result === 'WIN') { curWin++; curLoss = 0; winStreak = Math.max(winStreak, curWin); }
      else { curLoss++; curWin = 0; lossStreak = Math.max(lossStreak, curLoss); }
    }

    const periodStart = candles4H.length ? new Date(candles4H[0].time).toISOString().slice(0, 10) : '';
    const periodEnd   = candles4H.length ? new Date(candles4H[candles4H.length - 1].time).toISOString().slice(0, 10) : '';

    return {
      label,
      period: `${periodStart} → ${periodEnd}`,
      totalTrades:   trades.length,
      wins:          wins.length,
      losses:        losses.length,
      winRate:       parseFloat((wins.length / trades.length * 100).toFixed(2)),
      netProfit:     parseFloat(netPnl.toFixed(4)),
      returnPct:     parseFloat((netPnl / startBalance * 100).toFixed(2)),
      avgWin:        parseFloat(avgWin.toFixed(4)),
      avgLoss:       parseFloat(avgLoss.toFixed(4)),
      avgR:          parseFloat(avgR.toFixed(3)),
      expectancy:    parseFloat(expectancy.toFixed(4)),
      profitFactor:  parseFloat(profitFactor.toFixed(3)),
      maxDrawdown:   parseFloat(maxDD.toFixed(4)),
      maxDrawdownPct: parseFloat((maxDDPct * 100).toFixed(2)),
      largestWin:    wins.length   ? parseFloat(Math.max(...wins.map(t => t.pnl)).toFixed(4)) : 0,
      largestLoss:   losses.length ? parseFloat(Math.min(...losses.map(t => t.pnl)).toFixed(4)) : 0,
      winStreak,
      lossStreak,
      avgDurationH:  parseFloat((trades.reduce((s, t) => s + (t.duration || 0), 0) / trades.length).toFixed(1)),
      longTrades:    longs.length,
      shortTrades:   shorts.length,
      trades: trades.map(t => ({
        symbol: t.symbol,
        direction: t.direction,
        entry: t.entry,
        stopLoss: t.stopLoss,
        takeProfit: t.takeProfit,
        exitPrice: t.exitPrice,
        result: t.result,
        pnl: t.pnl,
        score: t.score,
        riskReward: t.riskReward,
        durationH: t.duration,
      })),
    };
  }

  _emptyMetrics(label, candles4H) {
    const periodStart = candles4H.length ? new Date(candles4H[0].time).toISOString().slice(0, 10) : '';
    const periodEnd   = candles4H.length ? new Date(candles4H[candles4H.length - 1].time).toISOString().slice(0, 10) : '';
    return {
      label,
      period: `${periodStart} → ${periodEnd}`,
      totalTrades: 0,
      wins: 0, losses: 0, winRate: 0,
      netProfit: 0, returnPct: 0,
      avgWin: 0, avgLoss: 0, avgR: 0,
      expectancy: 0, profitFactor: 0,
      maxDrawdown: 0, maxDrawdownPct: 0,
      largestWin: 0, largestLoss: 0,
      winStreak: 0, lossStreak: 0,
      avgDurationH: 0, longTrades: 0, shortTrades: 0,
      trades: [],
    };
  }
}

module.exports = Backtester;
