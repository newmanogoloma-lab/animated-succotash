'use strict';

const logger = require('../utils/logger');

const MIN_CANDLE_COUNTS = {
  '4h':  30,
  '1h':  30,
  '15m': 20,
};

/**
 * Data-Quality Firewall
 * Inspects multi-timeframe candle datasets for corruption, gaps,
 * impossible OHLC geometry, duplicate timestamps, and stale feeds.
 *
 * @param {object} mtfData - { candles4H, candles1H, candles15M, symbol }
 * @param {object} options - { checkStaleness: boolean, maxStalenessMs: number }
 * @returns {object} - { valid: boolean, reason: string | null, details: object }
 */
function validateMarketData(mtfData, options = {}) {
  const { symbol = 'UNKNOWN', candles4H = [], candles1H = [], candles15M = [] } = mtfData;
  const { checkStaleness = false, maxStalenessMs = 6 * 3600 * 1000 } = options;

  // 1. History adequacy checks
  if (!candles4H || candles4H.length < MIN_CANDLE_COUNTS['4h']) {
    return _fail(symbol, `Insufficient 4H history: ${candles4H?.length || 0} < ${MIN_CANDLE_COUNTS['4h']}`);
  }
  if (!candles1H || candles1H.length < MIN_CANDLE_COUNTS['1h']) {
    return _fail(symbol, `Insufficient 1H history: ${candles1H?.length || 0} < ${MIN_CANDLE_COUNTS['1h']}`);
  }
  if (!candles15M || candles15M.length < MIN_CANDLE_COUNTS['15m']) {
    return _fail(symbol, `Insufficient 15M history: ${candles15M?.length || 0} < ${MIN_CANDLE_COUNTS['15m']}`);
  }

  // 2. Validate individual timeframes
  const checks = [
    { tf: '4h', candles: candles4H },
    { tf: '1h', candles: candles1H },
    { tf: '15m', candles: candles15M },
  ];

  for (const { tf, candles } of checks) {
    let lastTime = 0;
    const seenTimes = new Set();

    for (let i = 0; i < candles.length; i++) {
      const c = candles[i];

      // Structure and type checks
      if (!c || typeof c !== 'object') {
        return _fail(symbol, `Malformed candle object at index ${i} (${tf})`);
      }

      const { time, open, high, low, close, volume } = c;

      if (
        typeof time !== 'number' || isNaN(time) ||
        typeof open !== 'number' || isNaN(open) || open <= 0 ||
        typeof high !== 'number' || isNaN(high) || high <= 0 ||
        typeof low  !== 'number' || isNaN(low)  || low <= 0 ||
        typeof close!== 'number' || isNaN(close)|| close <= 0 ||
        typeof volume !== 'number' || isNaN(volume) || volume < 0
      ) {
        return _fail(symbol, `Invalid non-numeric or non-positive OHLCV at ${tf}[${i}]`);
      }

      // Impossible OHLC relationships
      if (high < low) {
        return _fail(symbol, `Impossible OHLC: high (${high}) < low (${low}) at ${tf}[${i}]`);
      }
      if (open > high || open < low) {
        return _fail(symbol, `Impossible open (${open}) outside high/low range at ${tf}[${i}]`);
      }
      if (close > high || close < low) {
        return _fail(symbol, `Impossible close (${close}) outside high/low range at ${tf}[${i}]`);
      }

      // Timestamp chronological progression
      if (i > 0 && time <= lastTime) {
        return _fail(symbol, `Non-chronological or duplicate timestamp at ${tf}[${i}]: ${time} <= ${lastTime}`);
      }
      if (seenTimes.has(time)) {
        return _fail(symbol, `Duplicate timestamp detected at ${tf}[${i}]: ${time}`);
      }

      seenTimes.add(time);
      lastTime = time;
    }
  }

  // 3. Optional staleness check (for live/paper feeds)
  if (checkStaleness && candles15M.length > 0) {
    const latest15M = candles15M[candles15M.length - 1];
    const ageMs = Date.now() - latest15M.time;
    if (ageMs > maxStalenessMs) {
      return _fail(symbol, `Stale 15M candle: last update ${(ageMs / 60000).toFixed(1)} mins ago`);
    }
  }

  return {
    valid: true,
    reason: null,
    details: {
      symbol,
      counts: { '4h': candles4H.length, '1h': candles1H.length, '15m': candles15M.length },
    },
  };
}

function _fail(symbol, reason) {
  logger.warn(`DATA_QUALITY_BLOCK [${symbol}]: ${reason}`);
  return {
    valid: false,
    reason: `DATA_QUALITY_BLOCK: ${reason}`,
    details: { symbol },
  };
}

module.exports = { validateMarketData, MIN_CANDLE_COUNTS };
