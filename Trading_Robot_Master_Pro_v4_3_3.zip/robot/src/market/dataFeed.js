'use strict';

const exchange = require('../exchanges');
const logger = require('../utils/logger');

// Bybit interval codes
const INTERVAL_MAP = {
  '1m':  '1',
  '5m':  '5',
  '15m': '15',
  '1h':  '60',
  '4h':  '240',
  '1d':  'D',
};

const TF_MS = { '1m': 60e3, '5m': 300e3, '15m': 900e3, '1h': 3600e3, '4h': 14400e3, '1d': 86400e3 };
const TTL_MS = { '1m': 3e3, '5m': 8e3, '15m': 15e3, '1h': 60e3, '4h': 300e3, '1d': 600e3 };
const candleCache = new Map();   // "SYM|tf" -> { candles, at }
const inflight = new Map();
const metaCache = new Map();
let live = null;

/** Attach the WebSocket live feed: the forming 15m candle is patched from the stream for watched symbols */
function attachLive(feed) { live = feed; }

function mergeTail(old, fresh) {
  const out = old.slice();
  for (const c of fresh) {
    const last = out[out.length - 1];
    if (last && c.time === last.time) out[out.length - 1] = c;
    else if (!last || c.time > last.time) out.push(c);
  }
  return out;
}

function overlayLive(symbol, timeframe, interval, candles) {
  const k = live && live.getKline(symbol, interval);
  if (!k || !candles.length) return candles;
  const out = candles.slice();
  const last = out[out.length - 1];
  if (k.time === last.time) out[out.length - 1] = { ...last, ...k };
  else if (k.time === last.time + TF_MS[timeframe]) out.push(k);
  return out;
}

/**
 * Fetch candles (cached). Full history is fetched once per symbol/timeframe; afterwards only the last few
 * candles are refreshed (~5x fewer/lighter REST calls per scan => far less rate-limit pressure).
 */
async function getCandles(symbol, timeframe, limit = 200) {
  const interval = INTERVAL_MAP[timeframe];
  if (!interval) throw new Error(`Unknown timeframe: ${timeframe}`);
  const key = `${symbol}|${timeframe}`;
  const now = Date.now();
  const hit = candleCache.get(key);
  if (hit && hit.candles.length >= limit && now - hit.at < TTL_MS[timeframe]) {
    return overlayLive(symbol, timeframe, interval, hit.candles.slice(-limit));
  }
  const fetchKey = `${key}|${limit}`;
  if (inflight.has(fetchKey)) return inflight.get(fetchKey).then(c => c.slice(-limit));
  const job = (async () => {
    let candles;
    if (hit && hit.candles.length >= limit && now - hit.at < TF_MS[timeframe] * 20) {
      candles = mergeTail(hit.candles, await exchange.getKlines(symbol, interval, 5));
    } else {
      candles = await exchange.getKlines(symbol, interval, Math.max(limit, hit ? hit.candles.length : 0));
    }
    candleCache.set(key, { candles, at: Date.now() });
    if (candleCache.size > 4000) candleCache.delete(candleCache.keys().next().value);
    return candles;
  })().finally(() => inflight.delete(fetchKey));
  inflight.set(fetchKey, job);
  const candles = await job;
  return overlayLive(symbol, timeframe, interval, candles.slice(-limit));
}

/**
 * Fetch multi-timeframe candles for a symbol
 * Returns { '4h': [], '1h': [], '15m': [] }
 */
async function getMultiTimeframe(symbol, timeframes = ['4h', '1h', '15m'], limit = 200) {
  const entries = await Promise.all(timeframes.map(async (tf) => {
    try { return [tf, await getCandles(symbol, tf, limit)]; }
    catch (err) { logger.warn(`Failed to get ${tf} candles for ${symbol}: ${err.message}`); return [tf, []]; }
  }));
  return Object.fromEntries(entries);
}

/**
 * Fetch full candle history for backtesting (paginated)
 */
async function getHistoricalCandles(symbol, timeframe, maxCandles = 1000) {
  const interval = INTERVAL_MAP[timeframe];
  if (!interval) throw new Error(`Unknown timeframe: ${timeframe}`);
  return exchange.getKlineHistory(symbol, interval, maxCandles);
}

/** Funding rate + open interest for a symbol (cached 5 min — these change slowly) */
async function getMarketMeta(symbol) {
  const hit = metaCache.get(symbol);
  if (hit && Date.now() - hit.at < 300000) return hit.val;
  const [funding, oi] = await Promise.allSettled([
    exchange.getFundingRate(symbol),
    exchange.getOpenInterest(symbol, '4h'),
  ]);
  const val = {
    fundingRate: funding.status === 'fulfilled' ? funding.value?.fundingRate : null,
    openInterest: oi.status === 'fulfilled' ? oi.value?.openInterest : null,
  };
  metaCache.set(symbol, { at: Date.now(), val });
  if (metaCache.size > 4000) metaCache.delete(metaCache.keys().next().value);
  return val;
}

function clearCache() { candleCache.clear(); metaCache.clear(); inflight.clear(); }

module.exports = { attachLive, clearCache, getCandles, getMultiTimeframe, getHistoricalCandles, getMarketMeta, INTERVAL_MAP };
