'use strict';

/**
 * Microstructure signals for a candidate trade: order-book spread / depth / expected slippage / imbalance,
 * funding momentum and open-interest momentum. Vetoes only on liquidity (spread, slippage, thin book);
 * funding crowding is a veto only when FUNDING_VETO=true. Everything degrades gracefully if data is missing.
 */
const exchange = require('../exchanges');
const liveFeed = require('./liveFeed');
const config = require('../config');

const cache = new Map();
async function cached(key, ttlMs, fn) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.val;
  const val = await fn();
  cache.set(key, { at: Date.now(), val });
  if (cache.size > 2000) cache.delete(cache.keys().next().value);
  return val;
}
const peek = (key, ttlMs) => { const h = cache.get(key); return h && Date.now() - h.at < ttlMs ? h.val : null; };

function analyzeBook(book, direction, notionalUsd) {
  const bids = (book?.bids || []).map(([p, s]) => [+p, +s]).filter(x => x[0] > 0).sort((a, b) => b[0] - a[0]);
  const asks = (book?.asks || []).map(([p, s]) => [+p, +s]).filter(x => x[0] > 0).sort((a, b) => a[0] - b[0]);
  if (!bids.length || !asks.length) return null;
  const bid = bids[0][0], ask = asks[0][0], mid = (bid + ask) / 2;
  const within = (lv, pct, side) => lv.filter(([p]) => (side === 'ask' ? p <= mid * (1 + pct) : p >= mid * (1 - pct))).reduce((s, [p, q]) => s + p * q, 0);
  const bid1 = within(bids, 0.01, 'bid'), ask1 = within(asks, 0.01, 'ask');
  const bidH = within(bids, 0.005, 'bid'), askH = within(asks, 0.005, 'ask');
  // walk the side we would consume
  const side = direction === 'SHORT' ? bids : asks;
  let need = notionalUsd, cost = 0, qty = 0;
  for (const [p, q] of side) { const take = Math.min(need, p * q); cost += take; qty += take / p; need -= take; if (need <= 1e-9) break; }
  const slipBps = need > 1e-6 ? 999 : Math.abs(cost / qty - mid) / mid * 1e4;
  return { bid, ask, mid, spreadBps: (ask - bid) / mid * 1e4, depthUsd: direction === 'SHORT' ? bid1 : ask1,
    bidDepthUsd: bid1, askDepthUsd: ask1, imbalance: (bidH + askH) ? (bidH - askH) / (bidH + askH) : 0, slipBps };
}

function fundingMomentum(hist) {
  const r = (hist || []).map(h => parseFloat(h.fundingRate)).filter(Number.isFinite);
  if (!r.length) return null;
  const delta = r[0] - r[Math.min(r.length - 1, 2)];
  return { rate: r[0], delta, trend: delta > 1e-5 ? 'RISING' : delta < -1e-5 ? 'FALLING' : 'FLAT',
    crowded: r[0] >= 0.0005 ? 'LONG' : r[0] <= -0.0005 ? 'SHORT' : null };
}

function oiMomentum(hist) {
  const v = (hist || []).map(h => parseFloat(h.openInterest)).filter(Number.isFinite);
  if (v.length < 2 || !v[v.length - 1]) return null;
  const deltaPct = (v[0] - v[v.length - 1]) / v[v.length - 1] * 100;
  return { deltaPct, trend: deltaPct > 2 ? 'BUILDING' : deltaPct < -2 ? 'UNWINDING' : 'FLAT' };
}

async function evaluate(symbol, direction, notionalUsd, { allowRest = true } = {}) {
  let raw = liveFeed.getBook(symbol);
  if (!raw && allowRest) raw = await cached(`book|${symbol}`, 5000, () => exchange.getOrderBook(symbol, 50)).catch(() => null);
  const book = analyzeBook(raw, direction, notionalUsd);

  const fk = `fund|${symbol}`, ok = `oi|${symbol}`;
  const [fh, oh] = allowRest
    ? await Promise.all([cached(fk, 600000, () => exchange.getFundingHistory(symbol, 8)).catch(() => null), cached(ok, 600000, () => exchange.getOpenInterestHistory(symbol, '1h', 6)).catch(() => null)])
    : [peek(fk, 600000), peek(ok, 600000)];
  const funding = fundingMomentum(fh), oi = oiMomentum(oh);

  const vetoes = [];
  if (book) {
    if (book.spreadBps > config.maxSpreadBps) vetoes.push(`SPREAD ${book.spreadBps.toFixed(1)}bps > ${config.maxSpreadBps}`);
    if (book.slipBps > config.maxSlipBps) vetoes.push(`SLIPPAGE ${book.slipBps >= 999 ? 'book too thin' : book.slipBps.toFixed(1) + 'bps'} > ${config.maxSlipBps}`);
    else if (book.depthUsd < notionalUsd * config.minDepthMultiple) vetoes.push(`THIN_BOOK depth $${Math.round(book.depthUsd)} < ${config.minDepthMultiple}x order`);
  }
  if (config.fundingVeto && funding && funding.crowded === direction && funding.trend === 'RISING') vetoes.push(`CROWDED_${direction}_FUNDING`);
  return { symbol, direction, ts: Date.now(), book, funding, oi, vetoes, ok: vetoes.length === 0 };
}

module.exports = { evaluate, analyzeBook, fundingMomentum, oiMomentum };
