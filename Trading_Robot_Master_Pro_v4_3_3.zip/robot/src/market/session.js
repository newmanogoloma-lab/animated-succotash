'use strict';

/**
 * Market Session — CRYPTO ONLY
 *
 * Crypto (Bybit USDT perpetuals) trades 24/7.
 * This module is kept for backwards compatibility but always returns OPEN.
 */

/**
 * Returns the session status for a crypto market.
 * Since crypto is 24/7, this always returns OPEN.
 *
 * @param {string} assetClass  - Ignored; kept for API compatibility
 * @param {number} _timestamp  - Ignored; kept for API compatibility
 * @returns {{ status: string, allowsTrading: boolean, sessionName: string, assetClass: string }}
 */
function getSessionStatus(assetClass = 'CRYPTO', _timestamp = Date.now()) {
  return {
    status: 'OPEN',
    allowsTrading: true,
    sessionName: '24/7 Continuous',
    assetClass: 'CRYPTO',
  };
}

/**
 * Returns true — crypto is always tradeable.
 * Kept for backwards compatibility.
 *
 * @returns {boolean}
 */
function isSessionActive(_assetClass = 'CRYPTO', _timestamp = Date.now()) {
  return true;
}

module.exports = {
  getSessionStatus,
  isSessionActive,
};
