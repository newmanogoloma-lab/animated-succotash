'use strict';

/**
 * Live feed manager: Bybit WebSocket (public + optional private) with automatic REST fallback.
 * Consumers ask liveFeed for fresh prices/books/klines; when the socket is down or data is stale they get
 * null/empty and fall back to REST, so the robot never depends on the stream being up.
 */
const { EventEmitter } = require('events');
const config = require('../config');
const logger = require('../utils/logger');
const { BybitPublicStream, BybitPrivateStream } = require('../exchanges/ws/bybitStream');

const PUBLIC_URL = config.bybit.testnet ? 'wss://stream-testnet.bybit.com/v5/public/linear' : 'wss://stream.bybit.com/v5/public/linear';
const PRIVATE_URL = config.bybit.testnet ? 'wss://stream-testnet.bybit.com/v5/private' : 'wss://stream.bybit.com/v5/private';

class LiveFeed extends EventEmitter {
  constructor() {
    super();
    this.pub = null; this.priv = null; this.started = false; this.watch = { klines: new Set(), books: new Set() };
  }

  enabled() { return config.wsEnabled && config.exchange === 'bybit'; }

  start(markets = [], deps = {}) {
    if (this.started || !this.enabled()) return this.started;
    this.pub = new BybitPublicStream({ url: deps.publicUrl || PUBLIC_URL, Impl: deps.Impl, staleMs: config.wsStaleMs });
    this.pub.on('ticker', t => this.emit('ticker', t));
    this.pub.on('kline', k => this.emit('kline', k));
    this.pub.start();
    this.started = true;
    this.setUniverse(markets);
    if (config.isLive && config.bybit.apiKey && config.bybit.apiSecret) {
      this.priv = new BybitPrivateStream({ url: deps.privateUrl || PRIVATE_URL, apiKey: config.bybit.apiKey, apiSecret: config.bybit.apiSecret, Impl: deps.Impl });
      for (const ev of ['order', 'position', 'execution', 'wallet']) this.priv.on(ev, d => this.emit(`private.${ev}`, d));
      this.priv.start();
    }
    logger.info(`LiveFeed: WebSocket streams started (${PUBLIC_URL})`);
    return true;
  }

  stop() { this.pub?.stop(); this.priv?.stop(); this.started = false; }

  setUniverse(markets) {
    if (!this.pub) return;
    const want = new Set(markets.map(m => `tickers.${m.symbol}`));
    const have = [...this.pub.topics].filter(t => t.startsWith('tickers.'));
    this.pub.unsubscribe(have.filter(t => !want.has(t)));
    this.pub.subscribe([...want].filter(t => !this.pub.topics.has(t)));
  }

  /** Streams 15m klines + order books for open positions and the best candidates only (keeps the socket light) */
  setWatch(symbols) {
    if (!this.pub) return;
    const limited = [...new Set(symbols)].slice(0, config.wsBookSymbols);
    const topics = new Set(limited.flatMap(s => [`orderbook.50.${s}`, `kline.15.${s}`]));
    const current = [...this.pub.topics].filter(t => t.startsWith('orderbook.') || t.startsWith('kline.'));
    this.pub.unsubscribe(current.filter(t => !topics.has(t)));
    this.pub.subscribe([...topics].filter(t => !this.pub.topics.has(t)));
  }

  healthy() { const s = this.pub?.sock; return !!(s && s.connected && s.lastMessageAt && Date.now() - s.lastMessageAt < config.wsStaleMs); }
  getTickerMap(maxAgeMs = 5000) { return this.healthy() ? this.pub.getTickerMap(maxAgeMs) : {}; }
  getBook(symbol) { return this.healthy() ? this.pub.getBook(symbol) : null; }
  getKline(symbol, interval) { return this.healthy() ? this.pub.getKline(symbol, interval) : null; }

  status() {
    return {
      exchange: config.exchange, enabled: this.enabled(), started: this.started, healthy: this.healthy(),
      restFallback: !this.healthy(), url: this.enabled() ? PUBLIC_URL : null,
      public: this.pub ? this.pub.status() : null,
      private: config.isLive ? (this.priv ? this.priv.status() : { connected: false, note: 'API keys missing' }) : { note: 'PAPER mode — private stream not used' },
    };
  }
}

module.exports = new LiveFeed();
module.exports.LiveFeed = LiveFeed;
