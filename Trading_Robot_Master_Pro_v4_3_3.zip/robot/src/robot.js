'use strict';

const config = require('./config');
const logger = require('./utils/logger');
const { discoverMarkets, getReferenceMarkets } = require('./market/universe');
const dataFeed = require('./market/dataFeed');
const { createDefaultRegistry } = require('./strategy/registry');
const { scoreSignal } = require('./scoring/engine');
const RiskEngine = require('./risk/engine');
const PaperEngine = require('./paper/engine');
const LiveExecution = require('./execution/live');
const ReconciliationEngine = require('./execution/reconciliation');
const Watchdog = require('./monitoring/watchdog');
const { defaultNotifier } = require('./notifications/index');
const journal = require('./journal/store');
const bybit = require('./exchanges');
const { eventBus } = require('./events/bus');
const liveFeed = require('./market/liveFeed');
const micro = require('./market/microstructure');

const MONITOR_INTERVAL_MS = parseInt(process.env.MONITOR_INTERVAL_SECONDS || '5', 10) * 1000;
const COMMAND_INTERVAL_MS = 1000;
const PERSISTED_EVENTS = [
  'position.opened', 'position.closed', 'position.trailing_updated',
  'emergency.triggered', 'risk.breach', 'scanner.error',
];

/**
 * GPS Trading Robot — Production Main Process
 *
 * Runs autonomously as a headless daemon.
 * PAPER mode by default. LIVE mode triple-gated and locked.
 */
class TradingRobot {
  constructor() {
    this.running = false;
    this.scanCount = 0;
    this.lastSignals = [];
    this.markets = [];

    this.strategyRegistry = createDefaultRegistry();
    this.riskEngine = new RiskEngine();
    this.paperEngine = new PaperEngine({}, this.riskEngine.cfg);
    this.strategyRegistry = this.paperEngine.registry; // one registry: toggles/status reflect what actually trades

    this.reconciliation = new ReconciliationEngine({ riskEngine: this.riskEngine });
    this.watchdog = new Watchdog({ riskEngine: this.riskEngine });
    this.liveExecution = new LiveExecution({
      riskEngine: this.riskEngine,
      reconciliationEngine: this.reconciliation,
    });
    this.notifier = defaultNotifier;

    // Concurrency
    this.concurrency = config.scanConcurrency || 8;

    // Timers
    this._scanTimer = null;
    this._monitorTimer = null;
    this._commandTimer = null;
    this._monitoring = false;
    this._startTime = null;
    this._tickerCache = { at: 0, map: {} };
    this._tickerStale = false;
    this.paused = false;            // true = no NEW entries (open positions still managed)
    this._eventListener = null;
    this._micro = new Map();      // symbol -> latest microstructure snapshot (for the dashboard)
    this._lastTick = {};
  }

  async start() {
    if (this.running) {
      logger.warn('Robot already running');
      return;
    }

    this._startTime = Date.now();
    this.running = true;

    logger.info('════════════════════════════════════════════════════');
    logger.info('  GPS TRADING ROBOT — PRODUCTION DAEMON STARTING   ');
    logger.info(`  OPERATIONAL MODE: ${config.mode}`);
    logger.info(`  LIVE TRADING ENABLED: ${config.liveEnabled ? 'YES' : 'NO (LOCKED)'}`);
    logger.info(`  SCAN CONCURRENCY: ${this.concurrency}`);
    logger.info(`  STRATEGIES: ${this.strategyRegistry.getEnabled().map(s => `${s.name} v${s.version}`).join(', ')}`);
    logger.info('════════════════════════════════════════════════════');

    logger.info(`  DATABASE: ${journal.getDbPath()}  (PID ${process.pid})`);
    logger.info(`  RISK/TRADE: ${(config.riskPerTrade * 100).toFixed(2)}% | MAX OPEN: ${config.maxOpenPositions} | TARGET OPEN: ${config.targetOpenPositions}+ | STRATEGY MODE: ${config.strategyMode}`);
    if (config.riskPerTrade < 0.015 || (config.maxOpenPositions > 0 && config.maxOpenPositions < 10)) {
      logger.warn('  ⚠ Your .env overrides the v4.2 defaults (risk < 1.5% or a MAX_OPEN_POSITIONS cap). Update .env from .env.example.');
    }

    // Re-attach open positions from the journal so SL/TP/trailing keep being managed after a restart
    this.paperEngine.restoreFromJournal();
    this._applyConfigOverrides(journal.getState('config_overrides') || {});
    for (const [id, on] of Object.entries(journal.getState('strategy_overrides') || {})) {
      try { this.strategyRegistry.setEnabled(id, !!on); } catch (_) { /* strategy removed */ }
    }
    if (journal.getState('emergency_stop') === true) {
      this._setEmergency(true, 'restored from previous session');
    }

    // Restore or initialize persistent state
    journal.setState('robot_running', true);
    journal.setState('robot_mode', config.mode);
    journal.setState('robot_start', this._startTime);

    // Initial Watchdog Health Check
    await this.watchdog.checkHealth();

    // Initial Market Discovery
    await this._refreshMarkets();

    // Live WebSocket feed (falls back to REST automatically); SL/TP then react to every ticker update
    dataFeed.attachLive(liveFeed);
    if (liveFeed.start(this.markets)) liveFeed.on('ticker', (t) => this._onLiveTicker(t));
    logger.info(`  DATA FEED: exchange=${config.exchange} | websocket=${liveFeed.enabled() ? 'ON (REST fallback armed)' : 'OFF (REST polling)'}`);

    // Schedule scan loop
    this._scheduleScan();

    // Fast loops: position monitor (SL/TP + heartbeat) and dashboard command queue
    this._attachEventPersistence();
    this._writeHeartbeat();
    this._monitorTimer = setInterval(() => this._monitorTick(), MONITOR_INTERVAL_MS);
    this._commandTimer = setInterval(() => this._commandTick(), COMMAND_INTERVAL_MS);

    // Process termination signals
    process.on('SIGINT',  () => this.stop('SIGINT'));
    process.on('SIGTERM', () => this.stop('SIGTERM'));
  }

  async stop(reason = 'MANUAL') {
    if (!this.running) return;
    this.running = false;

    if (this._scanTimer) clearTimeout(this._scanTimer);
    if (this._monitorTimer) clearInterval(this._monitorTimer);
    if (this._commandTimer) clearInterval(this._commandTimer);
    if (this._eventListener) eventBus.removeListener('*', this._eventListener);

    logger.info(`Robot stopping: ${reason}`);
    try { liveFeed.stop(); } catch (_) { /* ignore */ }
    journal.setState('robot_running', false);
    this._writeHeartbeat(false);

    await this.notifier.dispatch({
      type: 'INFO',
      severity: 'WARNING',
      title: 'ROBOT STOPPED',
      message: `Daemon stopped. Reason: ${reason}`,
    }).catch(() => {});
  }

  async emergencyStop(reason = 'Manual Trigger') {
    this.riskEngine.emergencyStop();
    journal.setState('emergency_stop', true);
    logger.risk(`⛔ EMERGENCY STOP ACTIVATED: ${reason}`);
    await this.notifier.notifyEmergencyStop(reason).catch(() => {});
  }

  _scheduleScan() {
    if (!this.running) return;
    const interval = config.scanIntervalSeconds * 1000;
    this._scanTimer = setTimeout(async () => {
      await this._runScan();
      this._scheduleScan();
    }, interval);
  }

  async _runScan() {
    if (!this.running) return;
    this.scanCount++;

    logger.scan(`Scan #${this.scanCount} starting — ${this.markets.length} markets (concurrency: ${this.concurrency})`);

    // Periodic tasks:
    // 1. Refresh market list every 15 scans
    if (this.scanCount % 15 === 0) {
      await this._refreshMarkets();
    }

    // 2. Run Watchdog Health Check every 5 scans
    if (this.scanCount % 5 === 0) {
      const health = await this.watchdog.checkHealth();
      if (health.status !== 'HEALTHY') {
        logger.warn(`Watchdog report: ${health.status} issues: ${health.issues.join(', ')}`);
      }
    }

    // 3. Run Reconciliation if in LIVE mode
    if (config.isLive) {
      // In a live system, query Bybit positions & reconcile with journal
      const localOpen = journal.getRecentSignals(20);
      await this.reconciliation.reconcile(localOpen, [], [], []);
    }

    const scanStart = Date.now();
    const analyses = [];
    let errors = 0;

    // Phase 1 — analyse every market with every active strategy (no trades yet). SL/TP is handled by the monitor loop / live ticker stream
    // (market.lastPrice here can be 15 scans old, so it must never be used to close trades)
    for (let i = 0; i < this.markets.length; i += this.concurrency) {
      if (!this.running) break;
      const batch = this.markets.slice(i, i + this.concurrency);
      await Promise.all(batch.map(async (market) => {
        try {
          const a = await this.paperEngine.analyzeMarket(market.symbol);
          if (a.error) errors++;
          analyses.push({ market, ...a });
        } catch (err) {
          errors++;
          logger.error(`Error scanning ${market.symbol}: ${err.message}`);
        }
      }));
    }

    // Phase 2 — rank the whole universe, then fill slots best-first
    const all = analyses.flatMap(a => a.signals);
    const bySymbolBest = new Map();
    for (const sig of all) {
      const cur = bySymbolBest.get(sig.symbol);
      if (!cur || (sig.score || 0) > (cur.score || 0)) bySymbolBest.set(sig.symbol, sig);
    }
    const qualified = all.filter(s => s.tier === 'QUALIFIED').sort((a, b) => b.score - a.score);
    const fills = all.filter(s => s.tier === 'FILL').sort((a, b) => b.score - a.score);

    const opened = [];
    let blocked = 0;
    if (!this.paused) {
      const queue = [...qualified];
      if (config.fillToTarget) queue.push(...fills);
      let budget = config.maxNewPerScan;
      for (const sig of queue) {
        if (budget <= 0 || !this.running) break;
        const openCount = this.paperEngine.openTrades.size;
        if (sig.tier === 'FILL' && openCount >= config.targetOpenPositions) continue; // fills only top up to target
        if (config.microChecks) {
          const eq = Math.max(0, this.paperEngine.balance);
          const dist = Math.abs(sig.entry - sig.stopLoss) || 1;
          const notional = (eq * this.paperEngine.riskEngine.cfg.riskPerTrade) / dist * sig.entry;
          const mi = await micro.evaluate(sig.symbol, sig.direction, notional).catch(() => null);
          if (mi) {
            this._micro.set(sig.symbol, this._slimMicro(mi, notional));
            if (!mi.ok) { sig.rejectionReason = `MICRO: ${mi.vetoes.join('; ')}`; blocked++; continue; }
          }
        }
        const r = this.paperEngine.openFromSignal(sig);
        if (r.action !== 'OPENED') {
          if (!['DUPLICATE_SIGNAL', 'ALREADY_IN_TRADE', 'SYMBOL_ALREADY_OPEN'].includes(r.reason)) { sig.rejectionReason = `RISK: ${r.reason}`; blocked++; }
          continue;
        }
        budget--;
        opened.push(r.signal);
        sig.openedTradeId = r.trade.id;
        this.paperEngine.flushOutbox();
        try {
          await this.notifier.notifySignal(r.signal, config.mode);
        } catch (err) { logger.warn(`Notify failed: ${err.message}`); }
      }
    }

    // Phase 3 — persist so the dashboard is never blank: best signal per market + every qualified/fill setup
    const scanTs = Date.now();
    const toSave = new Map();
    for (const sig of bySymbolBest.values()) toSave.set(`${sig.symbol}|${sig.strategyId}`, sig);
    for (const sig of [...qualified, ...fills]) toSave.set(`${sig.symbol}|${sig.strategyId}`, sig);
    for (const sig of toSave.values()) {
      try {
        journal.saveSignal({ ...sig, timestamp: scanTs, mode: config.mode, decision: sig.decision || 'NO_TRADE' });
      } catch (err) { logger.warn(`Signal save failed for ${sig.symbol}: ${err.message}`); }
    }
    if (this.scanCount % 10 === 0) { try { journal.pruneSignals(config.signalRetention); } catch (_) { /* ignore */ } }

    const slim = (s) => ({
      symbol: s.symbol, strategyName: s.strategyName, strategyId: s.strategyId, direction: s.direction,
      score: s.score, tier: s.tier, entry: s.entry, stopLoss: s.stopLoss, takeProfit: s.takeProfit,
      riskReward: s.riskReward, opened: !!s.openedTradeId,
    });
    journal.setState('last_scan_summary', {
      scanId: this.scanCount, ts: scanTs, durationMs: scanTs - scanStart,
      markets: this.markets.length, analyzed: analyses.length, errors,
      qualified: qualified.length, fill: fills.length, opened: opened.length, blocked,
      openPositions: this.paperEngine.openTrades.size, target: config.targetOpenPositions,
      strategyMode: config.strategyMode, strategies: this.strategyRegistry.getEnabled().length,
      top: [...qualified, ...fills].slice(0, 25).map(slim),
    });

    // Stream order books + klines for open positions and the best candidates; refresh their microstructure view
    const watch = [...new Set([...this.paperEngine.getOpenTrades().map(t => t.symbol), ...qualified.slice(0, 15).map(q => q.symbol)])];
    if (liveFeed.started) liveFeed.setWatch(watch);
    for (const t of this.paperEngine.getOpenTrades().slice(0, 40)) {
      const notional = (t.positionSize || 0) * (t.entry || 0);
      const mi = await micro.evaluate(t.symbol, t.direction, notional, { allowRest: false }).catch(() => null);
      if (mi) this._micro.set(t.symbol, this._slimMicro(mi, notional));
    }
    for (const q of qualified.slice(0, 12)) {
      if (this._micro.has(q.symbol) && Date.now() - this._micro.get(q.symbol).ts < 60000) continue;
      const mi = await micro.evaluate(q.symbol, q.direction, 100).catch(() => null);
      if (mi) this._micro.set(q.symbol, this._slimMicro(mi, 100));
    }
    journal.setState('micro', Object.fromEntries([...this._micro.entries()].slice(-80)));
    if (this._micro.size > 200) for (const k of [...this._micro.keys()].slice(0, 100)) this._micro.delete(k);

    this.lastSignals = opened;
    this._updateState();
    logger.scan(`Scan #${this.scanCount} done in ${((scanTs - scanStart) / 1000).toFixed(1)}s — qualified ${qualified.length}, fill ${fills.length}, opened ${opened.length}, open positions ${this.paperEngine.openTrades.size}/${config.targetOpenPositions}+`);
  }

  _slimMicro(mi, notional) {
    const b = mi.book, f = mi.funding, o = mi.oi;
    return { ts: mi.ts, direction: mi.direction, notional: +notional.toFixed(2), ok: mi.ok, vetoes: mi.vetoes,
      spreadBps: b ? +b.spreadBps.toFixed(2) : null, depthUsd: b ? Math.round(b.depthUsd) : null, slipBps: b ? +Math.min(b.slipBps, 999).toFixed(2) : null,
      imbalance: b ? +b.imbalance.toFixed(2) : null, fundingRate: f ? f.rate : null, fundingTrend: f ? f.trend : null, crowded: f ? f.crowded : null,
      oiDeltaPct: o ? +o.deltaPct.toFixed(2) : null, oiTrend: o ? o.trend : null };
  }

  // ── Dashboard sync: heartbeat, position monitor, commands, events ───────

  _writeHeartbeat(alive = true) {
    try {
      journal.setState('robot_heartbeat', {
        ts: Date.now(),
        alive,
        pid: process.pid,
        dbPath: journal.getDbPath(),
        mode: config.mode,
        paused: this.paused,
        openTrades: this.paperEngine.openTrades.size,
        pendingWrites: this.paperEngine.getPendingWrites(),
        tickersStale: this._tickerStale,
        scanCount: this.scanCount,
      });
      journal.setState('feed_status', { ts: Date.now(), ...liveFeed.status(), exchangeInfo: require('./exchanges').info(), strategyMode: config.strategyMode });
    } catch (err) {
      logger.warn(`Heartbeat write failed: ${err.message}`);
    }
  }

  /** WebSocket tick: evaluate SL/TP/trailing immediately for symbols we hold (throttled per symbol) */
  _onLiveTicker(t) {
    if (!this.running || !(t.lastPrice > 0) || !this.paperEngine.hasOpen(t.symbol)) return;
    const now = Date.now();
    if (now - (this._lastTick[t.symbol] || 0) < 300) return;
    this._lastTick[t.symbol] = now;
    try {
      const closed = this.paperEngine.updateTrades(t.symbol, t.lastPrice);
      for (const c of closed) this.notifier.notifyTradeClosed(c).catch(() => {});
    } catch (err) { logger.warn(`Live tick handling failed for ${t.symbol}: ${err.message}`); }
  }

  async _getTickerMap(maxAgeMs = 3000) {
    const liveMap = liveFeed.getTickerMap(30000);
    if (Object.keys(liveMap).length) { this._tickerStale = false; return liveMap; }
    const now = Date.now();
    if (now - this._tickerCache.at < maxAgeMs && Object.keys(this._tickerCache.map).length) {
      return this._tickerCache.map;
    }
    try {
      const list = await bybit.getTickers();
      const map = {};
      for (const t of list) {
        map[t.symbol] = {
          lastPrice: parseFloat(t.lastPrice || 0),
          markPrice: parseFloat(t.markPrice || t.lastPrice || 0),
        };
      }
      this._tickerCache = { at: now, map };
      this._tickerStale = false;
    } catch (err) {
      this._tickerStale = true;
      logger.warn(`Ticker fetch failed in monitor: ${err.message}`);
    }
    return this._tickerCache.map;
  }

  /**
   * Fast position monitor. Previously SL/TP were only checked when a symbol was reached inside a
   * full market scan, so exits could lag by a whole scan cycle (minutes).
   */
  async _monitorTick() {
    if (!this.running || this._monitoring) return;
    this._monitoring = true;
    try {
      const open = this.paperEngine.getOpenTrades();
      if (open.length) {
        const tickers = await this._getTickerMap();
        const symbols = [...new Set(open.map(t => t.symbol))];
        for (const sym of symbols) {
          const px = tickers[sym]?.lastPrice || tickers[sym]?.markPrice;
          if (!px) continue;
          const closed = this.paperEngine.updateTrades(sym, px);
          for (const t of closed) {
            await this.notifier.notifyTradeClosed(t).catch(() => {});
          }
        }
      }
      this.paperEngine.flushOutbox();
      this._reconcileEngineWithJournal();
    } catch (err) {
      logger.warn(`Monitor tick failed: ${err.message}`);
    } finally {
      this._monitoring = false;
      this._writeHeartbeat();
    }
  }

  /** Self-heal: any open trade in memory that is missing from the DB is re-saved */
  _reconcileEngineWithJournal() {
    const dbOpen = new Set(journal.getOpenPaperTrades().map(r => r.id));
    for (const t of this.paperEngine.getOpenTrades()) {
      if (!dbOpen.has(t.id)) {
        logger.warn(`Reconcile: open trade ${t.symbol} (${t.id}) missing from journal — re-saving`);
        this.paperEngine._persist(t);
      }
    }
  }

  _attachEventPersistence() {
    this._eventListener = (name, payload) => {
      if (!PERSISTED_EVENTS.includes(name)) return;
      try {
        const slim = { ...payload };
        if (slim.trade) {
          const t = slim.trade;
          slim.trade = {
            id: t.id, symbol: t.symbol, direction: t.direction, strategyName: t.strategyName,
            entry: t.entry, stopLoss: t.stopLoss, takeProfit: t.takeProfit,
            exitPrice: t.exitPrice, pnl: t.pnl, outcome: t.outcome, exitReason: t.exitReason,
            openTime: t.openTime, closeTime: t.closeTime,
          };
        }
        delete slim.signal;
        journal.appendEvent(name, slim);
        if (Math.random() < 0.02) journal.pruneEvents(2000);
      } catch (err) {
        logger.warn(`Event persistence failed (${name}): ${err.message}`);
      }
    };
    eventBus.on('*', this._eventListener);
  }

  _setEmergency(on, why = 'command') {
    if (on) {
      this.riskEngine.emergencyStop();
      this.paperEngine.riskEngine.emergencyStop();
      this.paused = true;
      journal.setState('emergency_stop', true);
    } else {
      this.riskEngine.resetKillSwitch();
      this.paperEngine.riskEngine.resetKillSwitch();
      this.paperEngine.riskEngine.enableTrading();
      journal.setState('emergency_stop', false);
    }
    logger.risk(`Emergency ${on ? 'ACTIVATED' : 'RESET'} (${why})`);
  }

  _applyConfigOverrides(o = {}) {
    const cfg = this.paperEngine.riskEngine.cfg;
    if (o.accountBalance > 0) {
      this.paperEngine.balance = o.accountBalance;
      this.paperEngine.startBalance = o.accountBalance;
      cfg.accountBalance = o.accountBalance;
    }
    if (o.riskPerTrade > 0 && o.riskPerTrade <= 0.5) cfg.riskPerTrade = o.riskPerTrade;
    if (o.maxOpenPositions >= 0 && o.maxOpenPositions <= 1000) cfg.maxOpenPositions = o.maxOpenPositions;
    if (o.maxDailyLoss >= 0 && o.maxDailyLoss <= 1) cfg.maxDailyLoss = o.maxDailyLoss;
    if (o.leverage >= 1 && o.leverage <= 100) cfg.leverage = o.leverage;
  }

  async _commandTick() {
    if (!this.running || this._commandBusy) return;
    this._commandBusy = true;
    try {
      journal.expireStaleCommands(60000);
      const pending = journal.claimPendingCommands(20);
      for (const cmd of pending) {
        try {
          const result = await this._executeCommand(cmd);
          journal.completeCommand(cmd.id, 'DONE', result);
        } catch (err) {
          logger.warn(`Command #${cmd.id} ${cmd.type} failed: ${err.message}`);
          journal.completeCommand(cmd.id, 'FAILED', { error: err.message });
        }
      }
      // Reflect the new state (paused / open count) on the dashboard immediately, not on the next 5s tick
      if (pending.length) this._writeHeartbeat();
    } catch (err) {
      logger.warn(`Command poller error: ${err.message}`);
    } finally {
      this._commandBusy = false;
    }
  }

  async _executeCommand(cmd) {
    const p = cmd.payload || {};
    switch (cmd.type) {
      case 'CLOSE_POSITION': {
        const id = p.id;
        if (!id) throw new Error('Position id required');
        let trade = this.paperEngine.getOpenTrades().find(t => t.id === id || t.symbol === id);
        if (!trade) {
          const live = journal.getOpenLiveTrades().find(t => t.id === id || t.symbol === id);
          if (live) throw new Error('Live positions must be closed on the exchange — dashboard close is paper-only');
          // Open in the journal but missing from memory (restart/desync) — re-attach it, then close normally
          const row = journal.getOpenPaperTrades().find(r => r.id === id || r.symbol === id);
          if (row) {
            trade = this.paperEngine.adoptOpenRow(row) || this.paperEngine.getOpenTrades().find(t => t.id === row.id);
            logger.warn(`Close: re-attached orphaned open position ${row.symbol} (${row.id}) from journal`);
          }
        }
        if (!trade) throw new Error(`Position ${id} is not open (it may already have been closed by SL/TP) — refresh the dashboard`);
        const tickers = await this._getTickerMap(1500);
        const px = tickers[trade.symbol]?.lastPrice || tickers[trade.symbol]?.markPrice;
        if (!(px > 0)) throw new Error(`No live market price for ${trade.symbol} — not closed`);
        const closed = this.paperEngine.closeTrade(trade.id, p.reason || 'MANUAL_DASHBOARD_CLOSE', px);
        await this.notifier.notifyTradeClosed(closed).catch(() => {});
        return { closed: { id: closed.id, symbol: closed.symbol, exitPrice: closed.exitPrice, pnl: closed.pnl, outcome: closed.outcome } };
      }
      case 'CLOSE_ALL': {
        const tickers = await this._getTickerMap(1500);
        const priceFor = (sym) => tickers[sym]?.lastPrice || tickers[sym]?.markPrice || null;
        const closed = this.paperEngine.closeAllTrades(p.reason || 'MANUAL_DASHBOARD_CLOSE_ALL', priceFor, { strict: true });
        for (const t of closed) await this.notifier.notifyTradeClosed(t).catch(() => {});
        return {
          count: closed.length,
          closed: closed.map(t => ({ id: t.id, symbol: t.symbol, exitPrice: t.exitPrice, pnl: t.pnl })),
          failed: closed.failed || [],
        };
      }
      case 'RESET_ACCOUNT': {
        const bal = parseFloat(p.balance);
        if (!(bal > 0)) throw new Error('A positive balance is required');
        const tickers = await this._getTickerMap(1500);
        const closed = this.paperEngine.resetAccount(bal, (sym) => tickers[sym]?.lastPrice || tickers[sym]?.markPrice || null);
        for (const t of closed) await this.notifier.notifyTradeClosed(t).catch(() => {});
        journal.setState('account_epoch', { ts: Date.now(), balance: bal });
        const ov = journal.getState('config_overrides') || {};
        ov.accountBalance = bal;
        journal.setState('config_overrides', ov);
        this._applyConfigOverrides(ov);
        this._updateState();
        this._writeHeartbeat();
        return { balance: bal, closed: closed.length };
      }
      case 'STRATEGY_TOGGLE': {
        this.strategyRegistry.setEnabled(p.id, !!p.enabled);
        const st = journal.getState('strategy_overrides') || {};
        st[p.id] = !!p.enabled;
        journal.setState('strategy_overrides', st);
        return { id: p.id, enabled: !!p.enabled };
      }
      case 'CONFIG_UPDATE':
        this._applyConfigOverrides(p);
        return { applied: true };
      case 'PAUSE':
        this.paused = true;
        return { paused: true };
      case 'RESUME':
        if (this.paperEngine.riskEngine.state.killSwitch) throw new Error('Emergency stop active — reset it first');
        this.paused = false;
        return { paused: false };
      case 'EMERGENCY_STOP':
        this._setEmergency(true, 'dashboard');
        return { emergency: true };
      case 'EMERGENCY_RESET':
        this._setEmergency(false, 'dashboard');
        return { emergency: false };
      default:
        throw new Error(`Unknown command type: ${cmd.type}`);
    }
  }

  async _refreshMarkets() {
    try {
      this.markets = await discoverMarkets(true);
      journal.setState('market_count', this.markets.length);
      if (liveFeed.started) liveFeed.setUniverse(this.markets);
      logger.info(`Markets refreshed: ${this.markets.length} eligible crypto markets`);
    } catch (err) {
      logger.error(`Market discovery failed: ${err.message}`);
    }
  }

  _updateState() {
    const perf = this.paperEngine.getPerformance();
    journal.setState('performance', perf);
    journal.setState('scan_count', this.scanCount);
    journal.setState('last_scan', Date.now());
  }

  getStatus() {
    const perf = this.paperEngine.getPerformance();
    const watchdogStatus = this.watchdog.getStatus();
    const reconStatus = this.reconciliation.getStatus();
    const opState = this.liveExecution.getOperationalState();

    return {
      running: this.running,
      mode: config.mode,
      operationalState: opState,
      scanCount: this.scanCount,
      marketCount: this.markets.length,
      uptime: this._startTime ? Math.floor((Date.now() - this._startTime) / 1000) : 0,
      strategies: this.strategyRegistry.status(),
      riskStatus: this.riskEngine.getStatus(),
      watchdog: watchdogStatus,
      reconciliation: reconStatus,
      performance: perf,
      lastSignals: this.lastSignals.slice(0, 10),
    };
  }
}

// ── Entry Point ────────────────────────────────────────────────────────────

if (require.main === module) {
  const robot = new TradingRobot();

  const args = process.argv.slice(2);
  const modeArg = args.find(a => a.startsWith('--mode='));
  if (modeArg) {
    const m = modeArg.split('=')[1].toUpperCase();
    process.env.TRADING_MODE = m;
  }

  robot.start().catch(err => {
    logger.error(`Robot startup failed: ${err.message}`);
    process.exit(1);
  });
}

module.exports = TradingRobot;
