'use strict';

/**
 * Real-Time System Recommendations Engine
 *
 * Lightweight advisory intelligence analyzing:
 * - Top performing strategies and regime fit
 * - Strongest asset classes and market quality
 * - Highest-ranked opportunities
 * - Portfolio concentration and correlation clusters
 * - Account risk utilization and circuit breaker proximity
 * - System and data health alerts
 *
 * NOTE: Recommendations are purely informational and NEVER override
 * the risk engine, live safety gates, or emergency controls.
 */

function generateRecommendations({
  openPositions = [],
  recentSignals = [],
  performance = {},
  config = {},
  systemHealth = {},
}) {
  const recommendations = [];

  const balance = config.accountBalance || 100;
  const maxPositions = config.maxOpenPositions || 5;
  const maxExposure = config.maxPortfolioExposure || 0.30;
  const riskPerTrade = config.riskPerTrade || 0.005;

  // 1. Account Risk & Position Capacity
  const openCount = openPositions.length;
  const riskUtilizationPct = Math.round((openCount / maxPositions) * 100);

  if (openCount >= maxPositions) {
    recommendations.push({
      id: 'rec_max_positions',
      type: 'RISK_WARNING',
      severity: 'WARNING',
      title: 'Position Capacity Limit Reached',
      message: `Account is at maximum capacity (${openCount}/${maxPositions} open positions). Further trade signals will be blocked until positions close.`,
      actionable: 'Monitor active positions or consider manual take-profit closes on winning trades.',
    });
  } else if (openCount === 0) {
    recommendations.push({
      id: 'rec_ready_to_deploy',
      type: 'PORTFOLIO_DIVERSIFICATION',
      severity: 'INFO',
      title: 'Full Capital Deployment Available',
      message: `Account holds $${balance.toFixed(2)} with zero open risk. Scanner is actively hunting A+ opportunities.`,
      actionable: 'Ensure persistent scanner is running.',
    });
  }

  // 2. Correlation & Concentration Risk
  const clusterCounts = {};
  for (const pos of openPositions) {
    const cluster = pos.cluster || 'UNKNOWN';
    clusterCounts[cluster] = (clusterCounts[cluster] || 0) + 1;
  }

  let correlationAlerts = 0;
  for (const [cluster, count] of Object.entries(clusterCounts)) {
    if (count >= 2 && cluster !== 'UNKNOWN') {
      correlationAlerts++;
      recommendations.push({
        id: `rec_cluster_${cluster}`,
        type: 'RISK_WARNING',
        severity: 'WARNING',
        title: `Correlated Cluster Concentration: ${cluster}`,
        message: `Multiple active positions (${count}) share the ${cluster} correlation cluster. Adverse sector movement may impact all concurrently.`,
        actionable: 'Avoid adding additional exposure in this sector.',
      });
    }
  }

  // 3. Best Current Opportunity
  const qualifiedSignals = (recentSignals || []).filter(s => s.qualified || s.decision === 'TRADE');
  let bestOpportunity = null;

  if (qualifiedSignals.length > 0) {
    // Pick highest rankScore or score
    qualifiedSignals.sort((a, b) => (b.rankScore || b.score || 0) - (a.rankScore || a.score || 0));
    bestOpportunity = qualifiedSignals[0];

    recommendations.push({
      id: 'rec_top_opportunity',
      type: 'OPPORTUNITY',
      severity: 'SUCCESS',
      title: `Top Opportunity: ${bestOpportunity.symbol} ${bestOpportunity.direction}`,
      message: `Ranked #${1} with score ${bestOpportunity.score}/100 and R:R ${bestOpportunity.riskReward}. Strategy: ${bestOpportunity.strategyName || bestOpportunity.strategyId}.`,
      actionable: 'Inspect trade levels on the Opportunity Board.',
    });
  } else {
    recommendations.push({
      id: 'rec_patience',
      type: 'OPPORTUNITY',
      severity: 'INFO',
      title: 'Capital Preservation Mode',
      message: 'No active setups currently satisfy the strict A+ quality filters and minimum R:R threshold.',
      actionable: 'Patience protects capital. Awaiting high-probability setups.',
    });
  }

  // 4. Asset Class Diversity Analysis
  const assetClassCounts = { CRYPTO: 0, FOREX: 0, METALS: 0, INDICES: 0, STOCKS: 0, COMMODITIES: 0 };
  for (const sig of recentSignals) {
    const ac = sig.assetClass || 'CRYPTO';
    if (assetClassCounts[ac] !== undefined) assetClassCounts[ac]++;
  }

  let topAssetClass = 'CRYPTO';
  let maxAcCount = 0;
  for (const [ac, count] of Object.entries(assetClassCounts)) {
    if (count > maxAcCount) {
      maxAcCount = count;
      topAssetClass = ac;
    }
  }

  // 5. Strategy Analysis
  const strategyCounts = {};
  for (const sig of recentSignals) {
    const strat = sig.strategyName || sig.strategyId || 'GPS';
    strategyCounts[strat] = (strategyCounts[strat] || 0) + 1;
  }
  let topStrategy = 'GPS v1';
  let maxStratCount = 0;
  for (const [strat, count] of Object.entries(strategyCounts)) {
    if (count > maxStratCount) {
      maxStratCount = count;
      topStrategy = strat;
    }
  }

  // 6. System Health Warning
  if (systemHealth.watchdog?.status === 'STALLED') {
    recommendations.push({
      id: 'rec_watchdog_stalled',
      type: 'SYSTEM_HEALTH',
      severity: 'CRITICAL',
      title: 'Scanner Stalled Alert',
      message: 'The scanner watchdog detected no scan activity within expected heartbeat interval.',
      actionable: 'Restart the scanner from the Command Center header.',
    });
  }

  return {
    timestamp: Date.now(),
    summary: `${recommendations.length} recommendations available`,
    recommendations,
    stats: {
      topStrategy,
      topAssetClass,
      bestOpportunity: bestOpportunity ? {
        symbol: bestOpportunity.symbol,
        direction: bestOpportunity.direction,
        score: bestOpportunity.score,
        riskReward: bestOpportunity.riskReward,
        strategy: bestOpportunity.strategyName || bestOpportunity.strategyId,
      } : null,
      riskUtilizationPct,
      correlationAlerts,
    },
  };
}

module.exports = { generateRecommendations };
