'use strict';

const logger = require('../utils/logger');
const journal = require('../journal/store');
const bybit = require('../exchanges');

/**
 * Robot Watchdog / Self-Monitoring Service
 * Monitors scanner activity, exchange API ping, database responsiveness,
 * and error thresholds to safeguard robot execution.
 */
class Watchdog {
  constructor(options = {}) {
    this.maxScanIntervalMs = options.maxScanIntervalMs || 15 * 60 * 1000; // 15 min alert threshold
    this.riskEngine = options.riskEngine || null;
    this.consecutiveApiFailures = 0;
    this.maxConsecutiveApiFailures = options.maxConsecutiveApiFailures || 5;
    this.lastCheck = null;
    this.healthStatus = 'HEALTHY';
    this.startTime = Date.now();
  }

  setRiskEngine(riskEngine) {
    this.riskEngine = riskEngine;
  }

  /**
   * Run full health check
   * @returns {Promise<object>} Health check results
   */
  async checkHealth() {
    const now = Date.now();
    const checks = {
      database: false,
      apiConnectivity: false,
      apiLatencyMs: null,
      scannerActive: false,
      lastScanAgeMs: null,
    };

    // 1. Database Check
    try {
      journal.setState('watchdog_heartbeat', now);
      const readBack = journal.getState('watchdog_heartbeat');
      checks.database = readBack === now;
    } catch (err) {
      checks.database = false;
      logger.error(`Watchdog: Database failure: ${err.message}`);
    }

    // 2. Exchange API Connectivity Check
    const apiStart = Date.now();
    try {
      // Bybit ticker fetch as lightweight ping
      const tickers = await bybit.getTickers('BTCUSDT');
      checks.apiLatencyMs = Date.now() - apiStart;
      checks.apiConnectivity = Array.isArray(tickers) && tickers.length > 0;
      this.consecutiveApiFailures = 0;
    } catch (err) {
      checks.apiConnectivity = false;
      this.consecutiveApiFailures++;
      logger.warn(`Watchdog: API ping failed (${this.consecutiveApiFailures}/${this.maxConsecutiveApiFailures}): ${err.message}`);
    }

    // 3. Scanner Health Check
    const lastScanTime = journal.getState('last_scan');
    if (lastScanTime) {
      const scanAge = now - lastScanTime;
      checks.lastScanAgeMs = scanAge;
      // Normal if recent scan occurred
      checks.scannerActive = scanAge <= this.maxScanIntervalMs;
    } else {
      // If robot just started, permit grace period
      checks.scannerActive = (now - this.startTime) <= this.maxScanIntervalMs;
    }

    // 4. Overall Health Classification
    let status = 'HEALTHY';
    const issues = [];

    if (!checks.database) {
      status = 'UNHEALTHY';
      issues.push('DATABASE_UNAVAILABLE');
    }

    if (!checks.apiConnectivity && this.consecutiveApiFailures >= this.maxConsecutiveApiFailures) {
      status = 'UNHEALTHY';
      issues.push('API_DISCONNECTED_EXCESSIVE');
    } else if (!checks.apiConnectivity) {
      status = 'DEGRADED';
      issues.push('API_PING_FAILED');
    }

    if (!checks.scannerActive) {
      if (status !== 'UNHEALTHY') status = 'DEGRADED';
      issues.push('SCANNER_STALLED');
    }

    this.healthStatus = status;
    this.lastCheck = now;

    const report = {
      status,
      timestamp: now,
      uptimeSeconds: Math.floor((now - this.startTime) / 1000),
      checks,
      issues,
    };

    journal.setState('watchdog_status', report);

    if (status === 'UNHEALTHY') {
      logger.error('Watchdog: System state UNHEALTHY!', issues);
      journal.logAlert('WATCHDOG_UNHEALTHY', JSON.stringify(issues), 'system', true);
    }

    return report;
  }

  getStatus() {
    return {
      status: this.healthStatus,
      lastCheck: this.lastCheck,
      uptimeSeconds: Math.floor((Date.now() - this.startTime) / 1000),
    };
  }
}

module.exports = Watchdog;
