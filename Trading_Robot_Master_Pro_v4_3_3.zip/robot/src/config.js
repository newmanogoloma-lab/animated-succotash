'use strict';

const fs = require('fs');
const path = require('path');

// Minimal zero-dependency .env loader
function loadEnv() {
  // Repo-root .env first (works from any start folder), then the current folder as fallback
  const repoEnv = path.resolve(__dirname, '..', '.env');
  const envPath = fs.existsSync(repoEnv) ? repoEnv : path.join(process.cwd(), '.env');
  if (fs.existsSync(envPath)) {
    const content = fs.readFileSync(envPath, 'utf8');
    content.split(/\r?\n/).forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        const key = trimmed.slice(0, eqIdx).trim();
        let val = trimmed.slice(eqIdx + 1).trim();
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.slice(1, -1);
        } else {
          val = val.replace(/\s+#.*$/, '').trim();   // strip inline comments: "MAX_OPEN_POSITIONS=0   # unlimited"
        }
        if (!process.env[key]) {
          process.env[key] = val;
        }
      }
    });
  }
}

loadEnv();

const config = {
  // Trading mode
  mode: (process.env.TRADING_MODE || 'PAPER').toUpperCase(),
  liveEnabled: process.env.LIVE_TRADING_ENABLED === 'true',

  // Bybit
  bybit: {
    apiKey: process.env.BYBIT_API_KEY || '',
    apiSecret: process.env.BYBIT_API_SECRET || '',
    testnet: process.env.BYBIT_TESTNET === 'true',
    baseUrl: process.env.BYBIT_TESTNET === 'true'
      ? 'https://api-testnet.bybit.com'
      : 'https://api.bybit.com',
  },

  // Market — CRYPTO ONLY (Bybit USDT perpetuals)
  scanIntervalSeconds: parseInt(process.env.SCAN_INTERVAL_SECONDS || '60', 10),
  scanConcurrency: Math.max(1, parseInt(process.env.SCAN_CONCURRENCY || '8', 10)),
  scanMaxMarkets: parseInt(process.env.SCAN_MAX_MARKETS || '0', 10), // 0 = unlimited
  minQuoteVolume: parseFloat(process.env.MIN_QUOTE_VOLUME || '1000000'),
  excludedSymbols: (process.env.EXCLUDED_SYMBOLS || 'BTCUSDT,ETHUSDT')
    .split(',').map(s => s.trim().toUpperCase()).filter(Boolean),

  // Alpha (must remain off)
  alphaEnabled: false,

  // Strategy defaults
  gpsStrategyName: process.env.GPS_STRATEGY_NAME || 'GPS',
  minScore: parseFloat(process.env.MIN_SCORE || '85'),
  minRR: parseFloat(process.env.MIN_RR || '2.0'),
  minVolumeMultiplier: parseFloat(process.env.MIN_VOLUME_MULTIPLIER || '1.2'),
  regimeFilterEnabled: process.env.REGIME_FILTER_ENABLED !== 'false', // default true

  // Risk engine — $100 small account default
  accountBalance: parseFloat(process.env.ACCOUNT_BALANCE || '100'),
  riskPerTrade: parseFloat(process.env.RISK_PER_TRADE || '0.015'), // 1.5% default (minimum per user spec; raise freely)
  maxDailyLoss: parseFloat(process.env.MAX_DAILY_LOSS || '0'),   // 0 = no daily-loss stop (paper: reset balance instead)
  // Manual-trading tickets: size is computed for YOUR real Bybit account, not the paper balance
  ticketBalance: parseFloat(process.env.TICKET_BALANCE || process.env.ACCOUNT_BALANCE || '100'),
  ticketRiskPct: parseFloat(process.env.TICKET_RISK_PCT || process.env.RISK_PER_TRADE || '0.015'),
  // Signal freshness (see src/signals/expiry.js)
  signalExpiry: {
    entryToleranceR: parseFloat(process.env.SIGNAL_ENTRY_TOLERANCE_R || '0.25'), // price ran this far (in R) past entry => expired
    adverseExpireR: parseFloat(process.env.SIGNAL_ADVERSE_EXPIRE_R || '0.6'),    // pulled back this far toward SL => expired
    maxAgeMin: parseFloat(process.env.SIGNAL_MAX_AGE_MIN || '240'),              // older than this => expired
  },
  telegramMinScore: parseFloat(process.env.TELEGRAM_MIN_SCORE || '90'),          // only signals above this score are sent
  defaultLeverage: parseInt(process.env.DEFAULT_LEVERAGE || '10', 10),
  maxOpenPositions: parseInt(process.env.MAX_OPEN_POSITIONS || '0', 10),   // 0 = unlimited
  targetOpenPositions: parseInt(process.env.TARGET_OPEN_POSITIONS || '10', 10), // robot tries to keep >= this many open
  // Exposure is measured as MARGIN (notional / leverage) by default. The old notional basis capped a $100
  // account at ~1 position when risking 1.5% per trade, making 10+ positions mathematically impossible.
  exposureBasis: (process.env.EXPOSURE_BASIS || 'margin').toLowerCase(),   // 'margin' | 'notional'
  maxPortfolioExposure: parseFloat(process.env.MAX_PORTFOLIO_EXPOSURE || '0'),   // 0 = unlimited
  maxCorrelatedExposure: parseFloat(process.env.MAX_CORRELATED_EXPOSURE || '0'),  // 0 = off
  maxConsecutiveLosses: parseInt(process.env.MAX_CONSECUTIVE_LOSSES || '0', 10), // 0 = off

  // Multi-strategy behaviour
  strategyMode: (process.env.STRATEGY_MODE || 'ALL').toUpperCase(),        // ALL = every enabled strategy runs on every market; ROUTED = regime router picks
  onePositionPerSymbol: process.env.ONE_POSITION_PER_SYMBOL !== 'false',    // best signal per symbol (avoids stacking 9 strategies on one coin)
  fillToTarget: process.env.FILL_TO_TARGET === 'true',                      // OFF: only setups >= MIN_SCORE (85) trade
  fillMinScore: parseFloat(process.env.FILL_MIN_SCORE || '75'),
  maxNewPerScan: parseInt(process.env.MAX_NEW_PER_SCAN || '10', 10),        // 0 = unlimited; staggers entries across scans
  sizeOnEquity: process.env.SIZE_ON_EQUITY !== 'false',                     // risk % is applied to CURRENT balance (compounds, shrinks after losses)
  enforceFreeMargin: process.env.ENFORCE_FREE_MARGIN === 'true',            // paper default OFF (any number of positions); always ON in LIVE
  liqSafety: parseFloat(process.env.LIQ_SAFETY || '0.8'),                   // SL must sit inside 80% of the distance to liquidation
  maintenanceMarginRate: parseFloat(process.env.MAINTENANCE_MARGIN_RATE || '0.005'),

  // Exchange + data feed
  exchange: (process.env.EXCHANGE || 'bybit').toLowerCase(),               // bybit | sim
  wsEnabled: process.env.WS_ENABLED !== 'false',
  wsStaleMs: parseInt(process.env.WS_STALE_MS || '30000', 10),
  wsBookSymbols: parseInt(process.env.WS_BOOK_SYMBOLS || '25', 10),        // order books streamed for open positions + top candidates
  microChecks: process.env.MICRO_CHECKS !== 'false',
  maxSpreadBps: parseFloat(process.env.MAX_SPREAD_BPS || '15'),
  maxSlipBps: parseFloat(process.env.MAX_SLIP_BPS || '30'),
  minDepthMultiple: parseFloat(process.env.MIN_DEPTH_MULTIPLE || '3'),    // book depth within 1% must be >= 3x the order notional
  fundingVeto: process.env.FUNDING_VETO === 'true',
  evidenceGating: process.env.EVIDENCE_GATING === 'true',                  // mute strategy x regime pairs with negative validated expectancy
  signalRetention: parseInt(process.env.SIGNAL_RETENTION || '6000', 10),

  // Trailing stop management
  trailingStop: {
    enabled: process.env.TRAILING_STOP_ENABLED !== 'false',
    activationRR: parseFloat(process.env.TRAILING_ACTIVATION_RR || '1.0'), // activate when trade reaches 1R
    distancePct: parseFloat(process.env.TRAILING_DISTANCE_PCT || '0.015'),  // 1.5% trailing distance
  },

  // Execution & Reconciliation
  reconciliationIntervalSeconds: parseInt(process.env.RECONCILIATION_INTERVAL_SECONDS || '300', 10),
  watchdogHeartbeatSeconds: parseInt(process.env.WATCHDOG_HEARTBEAT_SECONDS || '30', 10),
  dataQualityEnforce: process.env.DATA_QUALITY_ENFORCE !== 'false', // default true

  // Notifications (Telegram, Email, WhatsApp)
  notifications: {
    telegram: {
      enabled: process.env.TELEGRAM_ENABLED === 'true',
      botToken: process.env.TELEGRAM_BOT_TOKEN || '',
      chatId: process.env.TELEGRAM_CHAT_ID || '',
    },
    email: {
      enabled: process.env.EMAIL_ENABLED === 'true',
      webhookUrl: process.env.EMAIL_WEBHOOK_URL || '',
      recipient: process.env.EMAIL_RECIPIENT || '',
    },
    whatsapp: {
      enabled: process.env.WHATSAPP_ENABLED === 'true',
      webhookUrl: process.env.WHATSAPP_WEBHOOK_URL || '',
      phoneNumber: process.env.WHATSAPP_PHONE_NUMBER || '',
    },
  },
  telegram: {
    enabled: process.env.TELEGRAM_ENABLED === 'true',
    botToken: process.env.TELEGRAM_BOT_TOKEN || '',
    chatId: process.env.TELEGRAM_CHAT_ID || '',
  },

  // Dashboard
  dashboardPort: parseInt(process.env.DASHBOARD_PORT || process.env.PORT || '3000', 10),

  // Logging
  logLevel: (process.env.LOG_LEVEL || 'INFO').toUpperCase(),
};

// Validate live mode requirements
config.isLive = config.mode === 'LIVE' && config.liveEnabled;
config.isPaper = !config.isLive;

module.exports = config;
