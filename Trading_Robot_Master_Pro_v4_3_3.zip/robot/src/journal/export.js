'use strict';
const { buildXlsx } = require('./xlsx');

function regimeName(r) {
  if (!r) return '';
  if (typeof r === 'object') return r.regime || '';
  try { const p = JSON.parse(r); return p.regime || r; } catch (_) { return String(r); }
}

/** Normalise a DB trade row into one flat export row. */
function toRow(t) {
  const closed = t.close_time != null && t.outcome != null;
  const size = Number(t.position_size) || 0;
  const riskUsd = (Number(t.initial_risk) || Math.abs((t.entry || 0) - (t.stop_loss || 0))) * size;
  const pnl = closed ? Number(t.pnl) || 0 : null;
  const dir = (t.direction || '').toUpperCase();
  const rrPlanned = t.risk_reward || (riskUsd > 0 ? Math.abs((t.take_profit || 0) - (t.entry || 0)) * size / riskUsd : null);
  return {
    status: closed ? 'CLOSED' : 'OPEN',
    symbol: t.symbol,
    direction: dir,
    strategy: t.strategy_name || t.strategy_id || '',
    score: t.score ?? null,
    regime: regimeName(t.regime),
    cluster: t.cluster || '',
    entry: t.entry ?? null,
    stopLoss: t.initial_stop_loss ?? t.stop_loss ?? null,
    takeProfit: t.take_profit ?? null,
    exitPrice: closed ? t.exit_price ?? null : null,
    size,
    rrPlanned: rrPlanned ? Number(rrPlanned) : null,
    riskUsd: riskUsd || null,
    pnl,
    rResult: closed && riskUsd > 0 ? pnl / riskUsd : null,
    fee: t.fee ?? null,
    outcome: t.outcome || '',
    exitReason: t.exit_reason || '',
    openTime: t.open_time ?? null,
    closeTime: closed ? t.close_time : null,
    durationMin: closed && t.close_time && t.open_time ? (t.close_time - t.open_time) / 60000 : null,
    mode: t.mode || 'PAPER',
    id: t.id,
  };
}

function strategySummary(rows) {
  const by = new Map();
  for (const r of rows.filter(x => x.status === 'CLOSED')) {
    const k = r.strategy || 'Unknown';
    if (!by.has(k)) by.set(k, []);
    by.get(k).push(r);
  }
  const out = [];
  for (const [strategy, list] of by) out.push(summ(strategy, list));
  out.sort((a, b) => b.netR - a.netR);
  out.push(summ('ALL STRATEGIES', rows.filter(x => x.status === 'CLOSED')));
  return out;
}
function summ(strategy, list) {
  const n = list.length;
  const wins = list.filter(r => r.pnl > 0), losses = list.filter(r => r.pnl < 0);
  const gp = wins.reduce((a, r) => a + r.pnl, 0), gl = Math.abs(losses.reduce((a, r) => a + r.pnl, 0));
  const netR = list.reduce((a, r) => a + (r.rResult || 0), 0);
  return {
    strategy, trades: n, wins: wins.length, losses: losses.length,
    winRate: n ? wins.length / n * 100 : null,
    netPnl: list.reduce((a, r) => a + r.pnl, 0),
    netR, avgR: n ? netR / n : null,
    profitFactor: gl > 0 ? gp / gl : (gp > 0 ? null : null),
    best: n ? Math.max(...list.map(r => r.pnl)) : null,
    worst: n ? Math.min(...list.map(r => r.pnl)) : null,
  };
}

const TRADE_COLS = [
  { header: 'Symbol', key: 'symbol', width: 14 },
  { header: 'Status', key: 'status', width: 9 },
  { header: 'Dir', key: 'direction', width: 8 },
  { header: 'Strategy', key: 'strategy', width: 22 },
  { header: 'Score', key: 'score', width: 8, type: 'num' },
  { header: 'Entry', key: 'entry', width: 13, type: 'price' },
  { header: 'Stop Loss', key: 'stopLoss', width: 13, type: 'price' },
  { header: 'Take Profit', key: 'takeProfit', width: 13, type: 'price' },
  { header: 'Exit Price', key: 'exitPrice', width: 13, type: 'price' },
  { header: 'Size (coins)', key: 'size', width: 13, type: 'num' },
  { header: 'Planned R:R', key: 'rrPlanned', width: 11, type: 'num' },
  { header: 'Risk $', key: 'riskUsd', width: 10, type: 'usd' },
  { header: 'P&L $', key: 'pnl', width: 11, type: 'usd' },
  { header: 'Result (R)', key: 'rResult', width: 11, type: 'r' },
  { header: 'Outcome', key: 'outcome', width: 10 },
  { header: 'Exit Reason', key: 'exitReason', width: 16 },
  { header: 'Opened (UTC)', key: 'openTime', width: 17, type: 'date' },
  { header: 'Closed (UTC)', key: 'closeTime', width: 17, type: 'date' },
  { header: 'Held (min)', key: 'durationMin', width: 10, type: 'num' },
  { header: 'Regime', key: 'regime', width: 16 },
  { header: 'Cluster', key: 'cluster', width: 12 },
  { header: 'Fee $', key: 'fee', width: 9, type: 'num' },
  { header: 'Mode', key: 'mode', width: 8 },
  { header: 'Trade ID', key: 'id', width: 30 },
  // blank columns for the manual-trading log
  { header: 'I took it? (Y/N)', key: 'm1', width: 14 },
  { header: 'My entry', key: 'm2', width: 12 },
  { header: 'My exit', key: 'm3', width: 12 },
  { header: 'My result $', key: 'm4', width: 12 },
  { header: 'Notes', key: 'm5', width: 36 },
];
const SUM_COLS = [
  { header: 'Strategy', key: 'strategy', width: 26 },
  { header: 'Trades', key: 'trades', width: 9, type: 'num' },
  { header: 'Wins', key: 'wins', width: 8, type: 'num' },
  { header: 'Losses', key: 'losses', width: 8, type: 'num' },
  { header: 'Win %', key: 'winRate', width: 9, type: 'pct' },
  { header: 'Net P&L $', key: 'netPnl', width: 12, type: 'usd' },
  { header: 'Net R', key: 'netR', width: 10, type: 'r' },
  { header: 'Avg R / trade', key: 'avgR', width: 13, type: 'r' },
  { header: 'Profit factor', key: 'profitFactor', width: 12, type: 'num' },
  { header: 'Best $', key: 'best', width: 11, type: 'usd' },
  { header: 'Worst $', key: 'worst', width: 11, type: 'usd' },
];

/** @param {Array} dbTrades rows from paper_trades / live_trades */
function buildJournalXlsx(dbTrades) {
  const rows = dbTrades.map(toRow).sort((a, b) => (b.openTime || 0) - (a.openTime || 0));
  return buildXlsx([
    { name: 'Trades', columns: TRADE_COLS, rows, freezeCols: 1 },
    { name: 'Strategy Summary', columns: SUM_COLS, rows: strategySummary(rows) },
  ]);
}

module.exports = { buildJournalXlsx, toRow, strategySummary };
