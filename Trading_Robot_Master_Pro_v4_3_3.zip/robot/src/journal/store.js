'use strict';

const path = require('path');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');
const crypto = require('crypto');

// Ensure data dir exists
// Anchored to the repository (NOT process.cwd()) so the robot and the dashboard
// always resolve the SAME database file no matter which folder they were started from.
// Override with ROBOT_DATA_DIR if you really need a custom location.
const DATA_DIR = process.env.ROBOT_DATA_DIR
  ? path.resolve(process.env.ROBOT_DATA_DIR)
  : path.resolve(__dirname, '..', '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'robot.db');

let db;

function getDbPath() {
  return DB_PATH;
}

const REQUIRED_TABLES = [
  'strategies', 'signals', 'paper_trades', 'live_trades', 'backtest_runs', 'robot_state',
  'alerts', 'reconciliation_logs', 'scan_sessions', 'snapshots', 'trade_autopsies',
  'commands', 'events',
];
const SCHEMA_VERSION = 2;   // PRAGMA user_version; bump when initSchema/migrations change

function sleepMs(ms) {
  try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch (_) { /* best effort */ }
}
const isBusy = e => /locked|busy/i.test(String(e && e.message));
const isCorrupt = e => /malformed|not a database|corrupt/i.test(String(e && e.message));

function listTables(database) {
  return database.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r => r.name);
}

function missingTables(database) {
  const have = new Set(listTables(database));
  return REQUIRED_TABLES.filter(t => !have.has(t));
}

// Open + configure + create schema + verify. Only returns a connection that is FULLY usable;
// on any failure the connection is closed, so a half-initialised handle is never cached.
function openDatabase() {
  const conn = new DatabaseSync(DB_PATH);
  try {
    conn.exec('PRAGMA busy_timeout = 8000;');   // must come first: two processes opening a fresh DB at once raced on the WAL switch
    try {
      conn.exec('PRAGMA journal_mode = WAL;');
    } catch (e) {
      if (isBusy(e)) throw e;
      conn.exec('PRAGMA journal_mode = DELETE;');   // filesystems without WAL support (some network/overlay mounts)
    }
    conn.exec('PRAGMA foreign_keys = ON;');
    initSchema(conn);
    const missing = missingTables(conn);
    if (missing.length) throw new Error(`schema incomplete after init, missing: ${missing.join(', ')}`);
    conn.exec(`PRAGMA user_version = ${SCHEMA_VERSION};`);
    return conn;
  } catch (e) {
    try { conn.close(); } catch (_) { /* ignore */ }
    throw e;
  }
}

// A corrupt / non-SQLite file is MOVED aside (never deleted) and a fresh DB is created.
function quarantineDbFiles() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  for (const suffix of ['', '-wal', '-shm']) {
    const f = DB_PATH + suffix;
    if (fs.existsSync(f)) { try { fs.renameSync(f, `${DB_PATH}.corrupt-${stamp}${suffix}`); } catch (_) { /* ignore */ } }
  }
  return `${DB_PATH}.corrupt-${stamp}`;
}

function openWithRecovery() {
  let lastErr;
  for (let attempt = 1; attempt <= 12; attempt++) {
    try {
      return openDatabase();
    } catch (e) {
      lastErr = e;
      if (isBusy(e)) { sleepMs(150 * attempt); continue; }     // sibling process is initialising: wait + retry
      if (isCorrupt(e) && attempt <= 2) {
        const moved = quarantineDbFiles();
        console.error(`[DB] ${DB_PATH} is not a valid SQLite database (${e.message}). Moved to ${moved}; creating a fresh one.`);
        continue;
      }
      break;
    }
  }
  throw lastErr;
}

function getDb() {
  if (!db) db = openWithRecovery();   // assigned ONLY after a successful, verified init
  return db;
}

// Read-only health report used by `npm run db:check`
function checkDb() {
  const database = getDb();
  const tables = listTables(database);
  const rows = {};
  for (const t of REQUIRED_TABLES) {
    if (tables.includes(t)) rows[t] = database.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n;
  }
  const integrity = database.prepare('PRAGMA integrity_check').get();
  const journal = database.prepare('PRAGMA journal_mode').get();
  return {
    path: DB_PATH,
    sizeBytes: fs.existsSync(DB_PATH) ? fs.statSync(DB_PATH).size : 0,
    journalMode: Object.values(journal)[0],
    userVersion: Object.values(database.prepare('PRAGMA user_version').get())[0],
    integrity: Object.values(integrity)[0],
    missing: missingTables(database),
    rows,
  };
}

function initSchema(database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS strategies (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      version TEXT NOT NULL,
      enabled INTEGER DEFAULT 1,
      config TEXT,
      created_at INTEGER,
      updated_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS signals (
      id TEXT PRIMARY KEY,
      strategy_id TEXT,
      strategy_name TEXT,
      strategy_version TEXT,
      symbol TEXT,
      direction TEXT,
      score INTEGER,
      entry REAL,
      stop_loss REAL,
      take_profit REAL,
      risk_reward REAL,
      conditions TEXT,
      regime TEXT,
      cluster TEXT,
      qualified INTEGER,
      decision TEXT,
      rejection_reason TEXT,
      timestamp INTEGER,
      mode TEXT
    );

    CREATE TABLE IF NOT EXISTS paper_trades (
      id TEXT PRIMARY KEY,
      strategy_id TEXT,
      strategy_name TEXT,
      strategy_version TEXT,
      symbol TEXT,
      direction TEXT,
      entry REAL,
      stop_loss REAL,
      take_profit REAL,
      exit_price REAL,
      position_size REAL,
      pnl REAL,
      fee REAL,
      slippage REAL,
      outcome TEXT,
      exit_reason TEXT,
      score INTEGER,
      risk_reward REAL,
      regime TEXT,
      cluster TEXT,
      open_time INTEGER,
      close_time INTEGER,
      duration_ms INTEGER,
      mode TEXT DEFAULT 'PAPER'
    );

    CREATE TABLE IF NOT EXISTS live_trades (
      id TEXT PRIMARY KEY,
      order_id TEXT,
      strategy_id TEXT,
      strategy_name TEXT,
      strategy_version TEXT,
      symbol TEXT,
      direction TEXT,
      entry REAL,
      stop_loss REAL,
      take_profit REAL,
      exit_price REAL,
      position_size REAL,
      pnl REAL,
      fee REAL,
      slippage REAL,
      outcome TEXT,
      exit_reason TEXT,
      score INTEGER,
      risk_reward REAL,
      regime TEXT,
      cluster TEXT,
      open_time INTEGER,
      close_time INTEGER,
      mode TEXT DEFAULT 'LIVE'
    );

    CREATE TABLE IF NOT EXISTS backtest_runs (
      id TEXT PRIMARY KEY,
      strategy_id TEXT,
      strategy_version TEXT,
      symbol TEXT,
      period TEXT,
      config TEXT,
      result TEXT,
      created_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS robot_state (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT,
      message TEXT,
      channel TEXT,
      sent INTEGER DEFAULT 0,
      created_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS reconciliation_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      status TEXT,
      discrepancies TEXT,
      timestamp INTEGER
    );

    CREATE TABLE IF NOT EXISTS scan_sessions (
      id TEXT PRIMARY KEY,
      status TEXT NOT NULL,
      started_at INTEGER,
      updated_at INTEGER,
      current_asset_class TEXT,
      current_instrument TEXT,
      total_markets INTEGER DEFAULT 0,
      analyzed_count INTEGER DEFAULT 0,
      remaining_count INTEGER DEFAULT 0,
      qualified_count INTEGER DEFAULT 0,
      rejected_count INTEGER DEFAULT 0,
      error_count INTEGER DEFAULT 0,
      completed_symbols TEXT,
      failed_symbols TEXT,
      qualified_setups TEXT,
      config TEXT
    );

    CREATE TABLE IF NOT EXISTS snapshots (
      id TEXT PRIMARY KEY,
      timestamp INTEGER NOT NULL,
      account_state TEXT,
      positions TEXT,
      scanner_state TEXT,
      top_opportunities TEXT,
      risk_settings TEXT,
      summary TEXT
    );

    CREATE TABLE IF NOT EXISTS trade_autopsies (
      id TEXT PRIMARY KEY,
      trade_id TEXT UNIQUE NOT NULL,
      symbol TEXT NOT NULL,
      strategy_id TEXT,
      direction TEXT,
      regime TEXT,
      outcome TEXT,
      pnl REAL,
      r_multiple REAL,
      mfe REAL,
      mae REAL,
      mfe_r REAL,
      mae_r REAL,
      sl_tightness TEXT,
      tp_ambition TEXT,
      trailing_efficiency TEXT,
      lessons TEXT,
      created_at INTEGER NOT NULL
    );

    -- Cross-process command queue (dashboard -> robot)
    CREATE TABLE IF NOT EXISTS commands (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      payload TEXT,
      status TEXT DEFAULT 'PENDING',
      result TEXT,
      created_at INTEGER,
      processed_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_commands_status ON commands(status, id);

    -- Cross-process event stream (robot -> dashboard SSE)
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event TEXT NOT NULL,
      payload TEXT,
      created_at INTEGER
    );
  `);

  // Safe non-destructive column migrations
  const migrations = [
    'ALTER TABLE signals ADD COLUMN regime TEXT;',
    'ALTER TABLE signals ADD COLUMN cluster TEXT;',
    'ALTER TABLE signals ADD COLUMN asset_class TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN regime TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN cluster TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN asset_class TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN exit_reason TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN slippage REAL;',
    'ALTER TABLE paper_trades ADD COLUMN trailing_stop REAL;',
    'ALTER TABLE paper_trades ADD COLUMN trailing_active INTEGER;',
    'ALTER TABLE paper_trades ADD COLUMN initial_risk REAL;',
    'ALTER TABLE paper_trades ADD COLUMN initial_stop_loss REAL;',
    'ALTER TABLE live_trades ADD COLUMN asset_class TEXT;',
    'ALTER TABLE live_trades ADD COLUMN trailing_stop REAL;',
  ];

  for (const m of migrations) {
    try {
      database.exec(m);
    } catch (_) {
      // Column already exists
    }
  }
}

// ── Strategy ──────────────────────────────────────────────────────────────

function saveStrategy(strategy) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO strategies (id, name, version, enabled, config, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    strategy.id,
    strategy.name,
    strategy.version,
    strategy.enabled ? 1 : 0,
    JSON.stringify(strategy.cfg || {}),
    Date.now()
  );
}

function getStrategies() {
  const stmt = getDb().prepare('SELECT * FROM strategies');
  return stmt.all();
}

// ── Signal ────────────────────────────────────────────────────────────────

function saveSignal(signal) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR IGNORE INTO signals
    (id, strategy_id, strategy_name, strategy_version, symbol, direction, score,
     entry, stop_loss, take_profit, risk_reward, conditions, regime, cluster, qualified, decision, rejection_reason, timestamp, mode)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `);
  stmt.run(
    crypto.randomUUID(),
    signal.strategyId, signal.strategyName, signal.strategyVersion,
    signal.symbol, signal.direction, signal.score,
    signal.entry, signal.stopLoss, signal.takeProfit, signal.riskReward,
    JSON.stringify(signal.conditions || {}),
    typeof signal.regime === 'object' ? JSON.stringify(signal.regime) : (signal.regime || null),
    signal.cluster || null,
    signal.qualified ? 1 : 0,
    signal.decision || null, signal.rejectionReason || null,
    signal.timestamp || Date.now(),
    signal.mode || 'PAPER'
  );
}

function getRecentSignals(limit = 50) {
  const stmt = getDb().prepare('SELECT * FROM signals ORDER BY timestamp DESC LIMIT ?');
  return stmt.all(limit);
}

/**
 * Signals from the most recent scan (the robot stamps every row of a scan with one timestamp; 3s tolerance), qualified first then by score.
 * The old "last N rows by time" query returned an arbitrary slice of one scan, so the scanner page looked empty/random.
 */
function getLatestScanSignals(limit = 300) {
  return getDb().prepare(`
    SELECT * FROM signals
    WHERE timestamp >= (SELECT COALESCE(MAX(timestamp),0) FROM signals) - 3000
    ORDER BY (decision IN ('TRADE','FILL')) DESC, qualified DESC, score DESC LIMIT ?`).all(limit);
}

/** Keep the signals table bounded (a 260-market scan every minute grows quickly) */
function pruneSignals(keep = 6000) {
  getDb().prepare('DELETE FROM signals WHERE id IN (SELECT id FROM signals ORDER BY timestamp DESC LIMIT -1 OFFSET ?)').run(keep);
}

// ── Paper Trades ──────────────────────────────────────────────────────────

function savePaperTrade(trade) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO paper_trades
    (id, strategy_id, strategy_name, strategy_version, symbol, direction, entry, stop_loss,
     take_profit, exit_price, position_size, pnl, fee, slippage, outcome, exit_reason, score, risk_reward,
     regime, cluster, open_time, close_time, duration_ms, mode,
     trailing_stop, trailing_active, initial_risk, initial_stop_loss)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `);
  stmt.run(
    trade.id || crypto.randomUUID(),
    trade.strategyId, trade.strategyName, trade.strategyVersion,
    trade.symbol, trade.direction, trade.entry, trade.stopLoss,
    trade.takeProfit, trade.exitPrice || null,
    trade.positionSize, trade.pnl ?? null, trade.fee || null, trade.slippage || null,
    trade.outcome || null, trade.exitReason || null, trade.score, trade.riskReward,
    typeof trade.regime === 'object' ? JSON.stringify(trade.regime) : (trade.regime || null),
    trade.cluster || null,
    trade.openTime, trade.closeTime || null, trade.durationMs || null,
    'PAPER',
    trade.trailingStopPrice ?? null,
    trade.trailingActive ? 1 : 0,
    trade.initialRisk ?? null,
    trade.initialStopLoss ?? null
  );
}

function getPaperTrades(limit = 100) {
  const stmt = getDb().prepare('SELECT * FROM paper_trades ORDER BY open_time DESC LIMIT ?');
  return stmt.all(limit);
}

// ── Live Trades ───────────────────────────────────────────────────────────

function saveLiveTrade(trade) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO live_trades
    (id, order_id, strategy_id, strategy_name, strategy_version, symbol, direction, entry, stop_loss,
     take_profit, exit_price, position_size, pnl, fee, slippage, outcome, exit_reason, score, risk_reward,
     regime, cluster, open_time, close_time, mode)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `);
  stmt.run(
    trade.id || crypto.randomUUID(),
    trade.orderId || null,
    trade.strategyId, trade.strategyName, trade.strategyVersion,
    trade.symbol, trade.direction, trade.entry, trade.stopLoss,
    trade.takeProfit, trade.exitPrice || null,
    trade.positionSize, trade.pnl || null, trade.fee || null, trade.slippage || null,
    trade.outcome || null, trade.exitReason || null, trade.score, trade.riskReward,
    typeof trade.regime === 'object' ? JSON.stringify(trade.regime) : (trade.regime || null),
    trade.cluster || null,
    trade.openTime, trade.closeTime || null,
    'LIVE'
  );
}

function getLiveTrades(limit = 100) {
  const stmt = getDb().prepare('SELECT * FROM live_trades ORDER BY open_time DESC LIMIT ?');
  return stmt.all(limit);
}

function getOpenPaperTrades() {
  const stmt = getDb().prepare('SELECT * FROM paper_trades WHERE close_time IS NULL AND outcome IS NULL ORDER BY open_time DESC');
  return stmt.all();
}

function getClosedPaperTrades(limit = 500) {
  const stmt = getDb().prepare('SELECT * FROM paper_trades WHERE close_time IS NOT NULL AND outcome IS NOT NULL ORDER BY close_time DESC LIMIT ?');
  return stmt.all(limit);
}

function getOpenLiveTrades() {
  const stmt = getDb().prepare('SELECT * FROM live_trades WHERE close_time IS NULL AND outcome IS NULL ORDER BY open_time DESC');
  return stmt.all();
}

function getClosedLiveTrades(limit = 500) {
  const stmt = getDb().prepare('SELECT * FROM live_trades WHERE close_time IS NOT NULL AND outcome IS NOT NULL ORDER BY close_time DESC LIMIT ?');
  return stmt.all(limit);
}

function getAllTrades(limit = 500) {
  const paper = getPaperTrades(limit);
  const live = getLiveTrades(limit);
  const all = [...paper, ...live];
  all.sort((a, b) => (b.open_time || 0) - (a.open_time || 0));
  return all.slice(0, limit);
}

// ── Backtest ──────────────────────────────────────────────────────────────

function saveBacktestRun(run) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT INTO backtest_runs (id, strategy_id, strategy_version, symbol, period, config, result, created_at)
    VALUES (?,?,?,?,?,?,?,?)
  `);
  stmt.run(
    crypto.randomUUID(),
    run.strategyId || 'gps_v1', run.strategyVersion || '1.0.0',
    run.symbol, run.period,
    JSON.stringify(run.config || {}),
    JSON.stringify(run.result || {}),
    Date.now()
  );
}

function getBacktestRuns(limit = 20) {
  const stmt = getDb().prepare('SELECT * FROM backtest_runs ORDER BY created_at DESC LIMIT ?');
  return stmt.all(limit);
}

// ── Robot State ───────────────────────────────────────────────────────────

function setState(key, value) {
  const stmt = getDb().prepare(`
    INSERT OR REPLACE INTO robot_state (key, value, updated_at) VALUES (?, ?, ?)
  `);
  stmt.run(key, JSON.stringify(value), Date.now());
}

function getState(key) {
  const stmt = getDb().prepare('SELECT value FROM robot_state WHERE key = ?');
  const row = stmt.get(key);
  return row ? JSON.parse(row.value) : null;
}

// ── Alerts & Reconciliation ───────────────────────────────────────────────

function logAlert(type, message, channel = 'system', sent = false) {
  const stmt = getDb().prepare(`
    INSERT INTO alerts (type, message, channel, sent, created_at) VALUES (?,?,?,?,?)
  `);
  stmt.run(type, message, channel, sent ? 1 : 0, Date.now());
}

function getRecentAlerts(limit = 50) {
  const stmt = getDb().prepare('SELECT * FROM alerts ORDER BY created_at DESC LIMIT ?');
  return stmt.all(limit);
}

function saveReconciliationLog(log) {
  const stmt = getDb().prepare(`
    INSERT INTO reconciliation_logs (status, discrepancies, timestamp) VALUES (?,?,?)
  `);
  stmt.run(log.status, JSON.stringify(log.discrepancies || []), log.timestamp || Date.now());
}

function getReconciliationLogs(limit = 20) {
  const stmt = getDb().prepare('SELECT * FROM reconciliation_logs ORDER BY timestamp DESC LIMIT ?');
  return stmt.all(limit);
}

// ── Persistent Scan Sessions ──────────────────────────────────────────────

function saveScanSession(session) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO scan_sessions
    (id, status, started_at, updated_at, current_asset_class, current_instrument,
     total_markets, analyzed_count, remaining_count, qualified_count, rejected_count, error_count,
     completed_symbols, failed_symbols, qualified_setups, config)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    session.id || session.sessionId || crypto.randomUUID(),
    session.status || 'IDLE',
    session.startedAt || Date.now(),
    Date.now(),
    session.currentAssetClass || 'ALL',
    session.currentInstrument || null,
    session.totalMarkets || 0,
    session.analyzedCount || 0,
    session.remainingCount || 0,
    session.qualifiedCount || 0,
    session.rejectedCount || 0,
    session.errorCount || 0,
    JSON.stringify(session.completedSymbols || []),
    JSON.stringify(session.failedSymbols || []),
    JSON.stringify(session.qualifiedSetups || []),
    JSON.stringify(session.config || {})
  );
}

function getLatestScanSession() {
  const stmt = getDb().prepare('SELECT * FROM scan_sessions ORDER BY updated_at DESC LIMIT 1');
  const row = stmt.get();
  if (!row) return null;
  return {
    id: row.id,
    status: row.status,
    startedAt: row.started_at,
    updatedAt: row.updated_at,
    currentAssetClass: row.current_asset_class,
    currentInstrument: row.current_instrument,
    totalMarkets: row.total_markets,
    analyzedCount: row.analyzed_count,
    remainingCount: row.remaining_count,
    qualifiedCount: row.qualified_count,
    rejectedCount: row.rejected_count,
    errorCount: row.error_count,
    completedSymbols: JSON.parse(row.completed_symbols || '[]'),
    failedSymbols: JSON.parse(row.failed_symbols || '[]'),
    qualifiedSetups: JSON.parse(row.qualified_setups || '[]'),
    config: JSON.parse(row.config || '{}'),
  };
}

function getScanSession(id) {
  const stmt = getDb().prepare('SELECT * FROM scan_sessions WHERE id = ?');
  const row = stmt.get(id);
  if (!row) return null;
  return {
    id: row.id,
    status: row.status,
    startedAt: row.started_at,
    updatedAt: row.updated_at,
    currentAssetClass: row.current_asset_class,
    currentInstrument: row.current_instrument,
    totalMarkets: row.total_markets,
    analyzedCount: row.analyzed_count,
    remainingCount: row.remaining_count,
    qualifiedCount: row.qualified_count,
    rejectedCount: row.rejected_count,
    errorCount: row.error_count,
    completedSymbols: JSON.parse(row.completed_symbols || '[]'),
    failedSymbols: JSON.parse(row.failed_symbols || '[]'),
    qualifiedSetups: JSON.parse(row.qualified_setups || '[]'),
    config: JSON.parse(row.config || '{}'),
  };
}

// ── Snapshots ─────────────────────────────────────────────────────────────

function saveSnapshot(snapshot) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO snapshots
    (id, timestamp, account_state, positions, scanner_state, top_opportunities, risk_settings, summary)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    snapshot.id || crypto.randomUUID(),
    snapshot.timestamp || Date.now(),
    JSON.stringify(snapshot.accountState || {}),
    JSON.stringify(snapshot.positions || []),
    JSON.stringify(snapshot.scannerState || {}),
    JSON.stringify(snapshot.topOpportunities || []),
    JSON.stringify(snapshot.riskSettings || {}),
    snapshot.summary || ''
  );
}

function getSnapshots(limit = 20) {
  const stmt = getDb().prepare('SELECT * FROM snapshots ORDER BY timestamp DESC LIMIT ?');
  const rows = stmt.all(limit);
  return rows.map(r => ({
    id: r.id,
    timestamp: r.timestamp,
    accountState: JSON.parse(r.account_state || '{}'),
    positions: JSON.parse(r.positions || '[]'),
    scannerState: JSON.parse(r.scanner_state || '{}'),
    topOpportunities: JSON.parse(r.top_opportunities || '[]'),
    riskSettings: JSON.parse(r.risk_settings || '{}'),
    summary: r.summary,
  }));
}

function getSnapshot(id) {
  const stmt = getDb().prepare('SELECT * FROM snapshots WHERE id = ?');
  const r = stmt.get(id);
  if (!r) return null;
  return {
    id: r.id,
    timestamp: r.timestamp,
    accountState: JSON.parse(r.account_state || '{}'),
    positions: JSON.parse(r.positions || '[]'),
    scannerState: JSON.parse(r.scanner_state || '{}'),
    topOpportunities: JSON.parse(r.top_opportunities || '[]'),
    riskSettings: JSON.parse(r.risk_settings || '{}'),
    summary: r.summary,
  };
}

// ── Trade Autopsies ────────────────────────────────────────────────────────

function saveAutopsy(autopsy) {
  const database = getDb();
  const id = autopsy.id || crypto.randomUUID();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO trade_autopsies (
      id, trade_id, symbol, strategy_id, direction, regime, outcome,
      pnl, r_multiple, mfe, mae, mfe_r, mae_r,
      sl_tightness, tp_ambition, trailing_efficiency, lessons, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run(
    id,
    autopsy.tradeId,
    autopsy.symbol,
    autopsy.strategyId || null,
    autopsy.direction || null,
    autopsy.regime || null,
    autopsy.outcome || null,
    autopsy.pnl || 0,
    autopsy.rMultiple || 0,
    autopsy.mfe || 0,
    autopsy.mae || 0,
    autopsy.mfeR || 0,
    autopsy.maeR || 0,
    autopsy.slTightness || 'OPTIMAL',
    autopsy.tpAmbition || 'REALISTIC',
    autopsy.trailingEfficiency || 'NEUTRAL',
    JSON.stringify(autopsy.lessons || []),
    autopsy.createdAt || Date.now()
  );

  return id;
}

function getAutopsies(limit = 50) {
  const stmt = getDb().prepare('SELECT * FROM trade_autopsies ORDER BY created_at DESC LIMIT ?');
  const rows = stmt.all(limit);
  return rows.map(r => ({
    id: r.id,
    tradeId: r.trade_id,
    symbol: r.symbol,
    strategyId: r.strategy_id,
    direction: r.direction,
    regime: r.regime,
    outcome: r.outcome,
    pnl: r.pnl,
    rMultiple: r.r_multiple,
    mfe: r.mfe,
    mae: r.mae,
    mfeR: r.mfe_r,
    maeR: r.mae_r,
    slTightness: r.sl_tightness,
    tpAmbition: r.tp_ambition,
    trailingEfficiency: r.trailing_efficiency,
    lessons: JSON.parse(r.lessons || '[]'),
    createdAt: r.created_at,
  }));
}

function getAutopsyByTradeId(tradeId) {
  const stmt = getDb().prepare('SELECT * FROM trade_autopsies WHERE trade_id = ?');
  const r = stmt.get(tradeId);
  if (!r) return null;
  return {
    id: r.id,
    tradeId: r.trade_id,
    symbol: r.symbol,
    strategyId: r.strategy_id,
    direction: r.direction,
    regime: r.regime,
    outcome: r.outcome,
    pnl: r.pnl,
    rMultiple: r.r_multiple,
    mfe: r.mfe,
    mae: r.mae,
    mfeR: r.mfe_r,
    maeR: r.mae_r,
    slTightness: r.sl_tightness,
    tpAmbition: r.tp_ambition,
    trailingEfficiency: r.trailing_efficiency,
    lessons: JSON.parse(r.lessons || '[]'),
    createdAt: r.created_at,
  };
}


// ── Symbol-scoped trades (chart) ──────────────────────────────────────────

function getTradesBySymbol(symbol, limit = 30) {
  const database = getDb();
  const paper = database.prepare('SELECT * FROM paper_trades WHERE symbol = ? ORDER BY open_time DESC LIMIT ?').all(symbol, limit);
  const live = database.prepare('SELECT * FROM live_trades WHERE symbol = ? ORDER BY open_time DESC LIMIT ?').all(symbol, limit);
  return [...paper, ...live].sort((a, b) => (b.open_time || 0) - (a.open_time || 0)).slice(0, limit);
}

// ── Command queue (dashboard -> robot) ────────────────────────────────────

function enqueueCommand(type, payload = {}) {
  const info = getDb().prepare(
    'INSERT INTO commands (type, payload, status, created_at) VALUES (?, ?, ?, ?)'
  ).run(type, JSON.stringify(payload || {}), 'PENDING', Date.now());
  return Number(info.lastInsertRowid);
}

function claimPendingCommands(limit = 20) {
  const database = getDb();
  const rows = database.prepare(
    "SELECT * FROM commands WHERE status = 'PENDING' ORDER BY id ASC LIMIT ?"
  ).all(limit);
  const mark = database.prepare("UPDATE commands SET status = 'PROCESSING' WHERE id = ? AND status = 'PENDING'");
  const claimed = [];
  for (const r of rows) {
    const res = mark.run(r.id);
    if (res.changes > 0) {
      claimed.push({ ...r, payload: r.payload ? JSON.parse(r.payload) : {} });
    }
  }
  return claimed;
}

function completeCommand(id, status, result = {}) {
  getDb().prepare(
    'UPDATE commands SET status = ?, result = ?, processed_at = ? WHERE id = ?'
  ).run(status, JSON.stringify(result ?? {}), Date.now(), id);
}

function getCommand(id) {
  const r = getDb().prepare('SELECT * FROM commands WHERE id = ?').get(id);
  if (!r) return null;
  return {
    ...r,
    payload: r.payload ? JSON.parse(r.payload) : {},
    result: r.result ? JSON.parse(r.result) : null,
  };
}

/** Commands stuck in PROCESSING (robot crashed mid-command) are failed so UI never hangs */
function expireStaleCommands(maxAgeMs = 60000) {
  const cutoff = Date.now() - maxAgeMs;
  getDb().prepare(
    "UPDATE commands SET status = 'FAILED', result = ?, processed_at = ? WHERE status IN ('PENDING','PROCESSING') AND created_at < ?"
  ).run(JSON.stringify({ error: 'Command expired before the robot processed it' }), Date.now(), cutoff);
}

// ── Event stream (robot -> dashboard) ─────────────────────────────────────

function appendEvent(event, payload = {}) {
  const info = getDb().prepare(
    'INSERT INTO events (event, payload, created_at) VALUES (?, ?, ?)'
  ).run(event, JSON.stringify(payload || {}), Date.now());
  return Number(info.lastInsertRowid);
}

function _eventRow(r) {
  let payload = {};
  try { payload = r.payload ? JSON.parse(r.payload) : {}; } catch (_) { /* ignore */ }
  return { id: r.id, event: r.event, timestamp: r.created_at, payload };
}

function getEventsSince(lastId = 0, limit = 100) {
  return getDb().prepare('SELECT * FROM events WHERE id > ? ORDER BY id ASC LIMIT ?').all(lastId, limit).map(_eventRow);
}

function getRecentEventsDb(limit = 50, filterEvent = null) {
  const rows = filterEvent
    ? getDb().prepare('SELECT * FROM events WHERE event = ? ORDER BY id DESC LIMIT ?').all(filterEvent, limit)
    : getDb().prepare('SELECT * FROM events ORDER BY id DESC LIMIT ?').all(limit);
  return rows.map(_eventRow);
}

function getLatestEventId() {
  const r = getDb().prepare('SELECT MAX(id) AS m FROM events').get();
  return r && r.m ? Number(r.m) : 0;
}

function pruneEvents(keep = 2000) {
  getDb().prepare('DELETE FROM events WHERE id <= (SELECT COALESCE(MAX(id),0) - ? FROM events)').run(keep);
  getDb().prepare("DELETE FROM commands WHERE status IN ('DONE','FAILED') AND id <= (SELECT COALESCE(MAX(id),0) - ? FROM commands)").run(500);
}

module.exports = {
  getDb,
  checkDb,
  REQUIRED_TABLES,
  getDbPath,
  getTradesBySymbol,
  enqueueCommand,
  claimPendingCommands,
  completeCommand,
  getCommand,
  expireStaleCommands,
  appendEvent,
  getEventsSince,
  getRecentEventsDb,
  getLatestEventId,
  pruneEvents,
  saveStrategy,
  getStrategies,
  saveSignal,
  getRecentSignals,
  getLatestScanSignals,
  pruneSignals,
  savePaperTrade,
  getPaperTrades,
  getOpenPaperTrades,
  getClosedPaperTrades,
  saveLiveTrade,
  getLiveTrades,
  getOpenLiveTrades,
  getClosedLiveTrades,
  getAllTrades,
  saveBacktestRun,
  getBacktestRuns,
  setState,
  getState,
  logAlert,
  getRecentAlerts,
  saveReconciliationLog,
  getReconciliationLogs,
  saveScanSession,
  getLatestScanSession,
  getScanSession,
  saveSnapshot,
  getSnapshots,
  getSnapshot,
  saveAutopsy,
  getAutopsies,
  getAutopsyByTradeId,
};
