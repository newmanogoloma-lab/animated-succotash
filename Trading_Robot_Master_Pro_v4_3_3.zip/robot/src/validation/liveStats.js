'use strict';
const { stats, groupBy } = require('./metrics');

/** Live paper-trade statistics per strategy and per strategy x regime, from closed journal rows */
function computeLiveStats(rows) {
  const trades = [];
  for (const r of rows) {
    const risk = (r.initial_risk || 0) * (r.position_size || 0);
    if (!(risk > 0) || r.pnl === null || r.pnl === undefined) continue;
    let regime = 'UNKNOWN';
    try { regime = r.regime ? (JSON.parse(r.regime).regime || r.regime) : 'UNKNOWN'; } catch (_) { regime = r.regime || 'UNKNOWN'; }
    trades.push({ strategyId: r.strategy_id, strategyName: r.strategy_name, regime, netR: r.pnl / risk, pnl: r.pnl, exitTime: r.close_time });
  }
  const byStrategy = [...groupBy(trades, t => t.strategyId)].map(([id, ts]) => ({ id, name: ts[0].strategyName, ...stats(ts), netPnl: +ts.reduce((s, t) => s + t.pnl, 0).toFixed(2) }))
    .sort((a, b) => b.expectancyR - a.expectancyR);
  const byStrategyRegime = [...groupBy(trades, t => `${t.strategyId}|${t.regime}`)].map(([k, ts]) => { const [strategyId, regime] = k.split('|'); return { strategyId, regime, ...stats(ts) }; });
  return { overall: stats(trades), byStrategy, byStrategyRegime };
}
module.exports = { computeLiveStats };
