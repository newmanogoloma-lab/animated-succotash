'use strict';

/** Shared statistics for validation reports and live strategy stats. Trades carry netR (profit in units of initial risk). */

function rngFrom(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const r2 = (x, d = 2) => (Number.isFinite(x) ? parseFloat(x.toFixed(d)) : null);

function stats(trades) {
  const n = trades.length;
  if (!n) return { trades: 0, winRate: 0, expectancyR: 0, profitFactor: 0, avgWinR: 0, avgLossR: 0, netR: 0, maxDrawdownR: 0, sharpe: 0, sample: 'NONE' };
  const sorted = [...trades].sort((a, b) => (a.exitTime || 0) - (b.exitTime || 0));
  const rs = sorted.map(t => t.netR);
  const wins = rs.filter(x => x > 0), losses = rs.filter(x => x <= 0);
  const gp = wins.reduce((s, x) => s + x, 0), gl = Math.abs(losses.reduce((s, x) => s + x, 0));
  const mean = rs.reduce((s, x) => s + x, 0) / n;
  const sd = Math.sqrt(rs.reduce((s, x) => s + (x - mean) ** 2, 0) / Math.max(1, n - 1));
  let eq = 0, peak = 0, dd = 0;
  for (const x of rs) { eq += x; peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); }
  return {
    trades: n, winRate: r2(wins.length / n * 100, 1), expectancyR: r2(mean, 3),
    profitFactor: gl ? r2(gp / gl, 2) : (gp > 0 ? 99 : 0),
    avgWinR: r2(wins.length ? gp / wins.length : 0, 2), avgLossR: r2(losses.length ? -gl / losses.length : 0, 2),
    netR: r2(eq, 2), maxDrawdownR: r2(dd, 2), sharpe: r2(sd ? mean / sd * Math.sqrt(n) : 0, 2),
    sample: n >= 100 ? 'ROBUST' : n >= 30 ? 'MODERATE' : 'SMALL',
  };
}

function groupBy(trades, keyFn) {
  const m = new Map();
  for (const t of trades) { const k = keyFn(t); if (!m.has(k)) m.set(k, []); m.get(k).push(t); }
  return m;
}

/** Bootstrap Monte Carlo over the trade list. riskPct = fraction of equity risked per trade (compounding). */
function monteCarlo(netRs, { sims = 1000, riskPct = 0.015, horizon = null, seed = 7, points = 40 } = {}) {
  if (netRs.length < 5) return null;
  const rng = rngFrom(seed), H = horizon || netRs.length;
  const finals = [], dds = [], paths = [];
  const step = Math.max(1, Math.floor(H / points));
  for (let s = 0; s < sims; s++) {
    let eq = 1, peak = 1, dd = 0; const path = [];
    for (let i = 0; i < H; i++) {
      eq *= Math.max(0, 1 + netRs[Math.floor(rng() * netRs.length)] * riskPct);
      peak = Math.max(peak, eq); dd = Math.max(dd, (peak - eq) / peak);
      if (i % step === 0 || i === H - 1) path.push(eq);
    }
    finals.push(eq); dds.push(dd); paths.push(path);
  }
  const pct = (arr, p) => { const a = [...arr].sort((x, y) => x - y); return a[Math.min(a.length - 1, Math.floor(p * a.length))]; };
  const len = paths[0].length;
  const band = (p) => Array.from({ length: len }, (_, i) => r2(pct(paths.map(x => x[i]), p), 3));
  return {
    sims, horizonTrades: H, riskPct,
    finalEquity: { p5: r2(pct(finals, 0.05), 3), p50: r2(pct(finals, 0.5), 3), p95: r2(pct(finals, 0.95), 3) },
    maxDrawdown: { p50: r2(pct(dds, 0.5) * 100, 1), p95: r2(pct(dds, 0.95) * 100, 1) },
    probProfit: r2(finals.filter(x => x > 1).length / sims * 100, 1),
    probDrawdown50: r2(dds.filter(x => x >= 0.5).length / sims * 100, 1),
    probRuin90: r2(finals.filter(x => x <= 0.1).length / sims * 100, 1),
    fan: { p5: band(0.05), p50: band(0.5), p95: band(0.95) },
  };
}

module.exports = { stats, groupBy, monteCarlo, rngFrom, r2 };
