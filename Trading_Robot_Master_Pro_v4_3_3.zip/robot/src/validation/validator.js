'use strict';

/**
 * Strategy validator — replays EVERY registered strategy over multi-symbol 15m history with realistic costs.
 *  • no look-ahead: a decision at 15m close t only sees candles that closed <= t (1h / 4h aggregated from the 15m series)
 *  • entry at the NEXT candle open + slippage; stop checked before target inside a candle (conservative); trailing stop as live
 *  • costs: taker fees both sides, slippage both sides, funding while held
 *  • every candidate signal (score >= candidateScore) is simulated once, so the minScore sweep shows what each filter level costs/earns
 * Outputs expectancy (R), profit factor, win rate, max drawdown, trade count per strategy / regime / symbol,
 * walk-forward consistency, a regime-selection out-of-sample test and Monte-Carlo equity distributions.
 */
const config = require('../config');
const { createDefaultRegistry } = require('../strategy/registry');
const { detectRegime } = require('../market/regime');
const { stats, groupBy, monteCarlo, r2 } = require('./metrics');

const MIN15 = 15 * 60000;
const FEE = 0.00055, SLIP = 0.0005, FUNDING_8H = 0.0001;

function aggregate(c15, minutes) {
  const ms = minutes * 60000, out = [];
  let cur = null;
  for (const c of c15) {
    const b = Math.floor(c.time / ms) * ms;
    if (!cur || cur.time !== b) { if (cur) out.push(cur); cur = { time: b, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume, turnover: c.turnover || 0 }; }
    else { cur.high = Math.max(cur.high, c.high); cur.low = Math.min(cur.low, c.low); cur.close = c.close; cur.volume += c.volume; cur.turnover += c.turnover || 0; }
  }
  if (cur) out.push(cur);
  return out;
}

function simulate(sig, c15, start, { trailing = true, maxHoldBars = 96 * 7 } = {}) {
  const dir = sig.direction === 'LONG' ? 1 : -1;
  const open = c15[start].open;
  const entry = open * (1 + dir * SLIP);
  let sl = sig.stopLoss; const tp = sig.takeProfit;
  const risk = (entry - sl) * dir;
  if (!(risk > 0) || !((tp - entry) * dir > 0)) return null;     // gapped through the stop/target before entry
  const initRisk = risk, actRR = config.trailingStop?.activationRR || 1, dist = config.trailingStop?.distancePct || 0.015;
  let exit = null, reason = 'TIMEOUT', j = start;
  let trailPx = null;
  for (; j < Math.min(c15.length, start + maxHoldBars); j++) {
    const c = c15[j];
    if (dir === 1 ? c.low <= sl : c.high >= sl) { exit = sl * (1 - dir * SLIP); reason = trailPx && sl === trailPx ? 'TRAIL' : 'SL'; break; }
    if (dir === 1 ? c.high >= tp : c.low <= tp) { exit = tp * (1 - dir * SLIP); reason = 'TP'; break; }
    if (trailing && (c.high - entry) * (dir === 1 ? 1 : 0) + (entry - c.low) * (dir === -1 ? 1 : 0) >= initRisk * actRR) {
      const prop = dir === 1 ? c.high * (1 - dist) : c.low * (1 + dist);
      if (trailPx === null || (dir === 1 ? prop > trailPx : prop < trailPx)) trailPx = prop;
      if (dir === 1 ? trailPx > sl : trailPx < sl) sl = trailPx;
    }
  }
  if (exit === null) { j = Math.min(j, c15.length - 1); exit = c15[j].close * (1 - dir * SLIP); }
  const size = 1 / initRisk;                                       // 1R == 1 unit of account risk
  const gross = (exit - entry) * dir * size;
  const fees = (entry + exit) * size * FEE;
  const funding = entry * size * FUNDING_8H * (((j - start + 1) * 0.25) / 8);
  return { netR: gross - fees - funding, grossR: gross, bars: j - start + 1, exitIdx: j, exitReason: reason };
}

function runSymbol(symbol, c15, registry, opts) {
  const c1h = aggregate(c15, 60), c4h = aggregate(c15, 240);
  const warm = Math.max(900, opts.warmup || 900);
  const out = []; const busy = {};
  let p1 = 0, p4 = 0;
  for (let i = warm; i < c15.length - 2; i += opts.step) {
    const t = c15[i].time + MIN15;
    while (p1 < c1h.length && c1h[p1].time + 3600000 <= t) p1++;
    while (p4 < c4h.length && c4h[p4].time + 14400000 <= t) p4++;
    const data = { symbol, candles15M: c15.slice(i - 199, i + 1), candles1H: c1h.slice(Math.max(0, p1 - 200), p1), candles4H: c4h.slice(Math.max(0, p4 - 200), p4),
      meta: { symbol, fundingRate: 0.0001, openInterest: null } };
    let regime = null;
    for (const strat of registry.getEnabled()) {
      if (busy[strat.id] > i) continue;
      let sig; try { sig = strat.evaluate(data); } catch (_) { continue; }
      if (!sig || !sig.direction || sig.criticalFail || !(sig.entry > 0 && sig.stopLoss > 0 && sig.takeProfit > 0)) continue;
      if ((sig.score || 0) < opts.candidateScore || (sig.riskReward || 0) < config.minRR) continue;
      if (!regime) { try { regime = detectRegime(data.candles4H, data.candles1H, data.candles15M).regime || 'UNKNOWN'; } catch (_) { regime = 'UNKNOWN'; } }
      const r = simulate(sig, c15, i + 1, opts);
      if (!r) continue;
      busy[strat.id] = r.exitIdx + 1;
      out.push({ symbol, strategyId: strat.id, strategyName: strat.name, regime, score: sig.score, direction: sig.direction,
        entryTime: c15[i + 1].time, exitTime: c15[r.exitIdx].time, netR: r.netR, grossR: r.grossR, bars: r.bars, exitReason: r.exitReason });
    }
  }
  return out;
}

function analyse(allTrades, opts) {
  const minScore = opts.minScore ?? config.minScore;
  const headline = allTrades.filter(t => t.score >= minScore);
  const days = opts.spanDays || 1;
  const strategies = [...groupBy(headline, t => t.strategyId)].map(([id, ts]) => ({ id, name: ts[0].strategyName, ...stats(ts), perDay: r2(ts.length / days, 3) }))
    .sort((a, b) => b.expectancyR - a.expectancyR);
  const byStrategyRegime = [...groupBy(headline, t => `${t.strategyId}|${t.regime}`)].map(([k, ts]) => {
    const [strategyId, regime] = k.split('|'); return { strategyId, regime, ...stats(ts) };
  });
  const bySymbol = [...groupBy(headline, t => t.symbol)].map(([symbol, ts]) => ({ symbol, ...stats(ts) })).sort((a, b) => b.netR - a.netR);
  const scoreSweep = [60, 65, 70, 75, 80, 85, 90].map(th => { const ts = allTrades.filter(t => t.score >= th); return { minScore: th, ...stats(ts), perDay: r2(ts.length / days, 3) }; });

  // Walk-forward: equal time windows; each strategy must be positive out-of-time, not just overall
  const t0 = Math.min(...headline.map(t => t.exitTime)), t1 = Math.max(...headline.map(t => t.exitTime));
  const K = opts.windows || 4, span = (t1 - t0) / K || 1;
  const win = (t) => Math.min(K - 1, Math.floor((t.exitTime - t0) / span));
  const windows = Array.from({ length: K }, (_, k) => ({ window: k + 1, from: t0 + k * span, to: t0 + (k + 1) * span, ...stats(headline.filter(t => win(t) === k)) }));
  const consistency = strategies.map(s => {
    const per = Array.from({ length: K }, (_, k) => stats(headline.filter(t => t.strategyId === s.id && win(t) === k)));
    return { id: s.id, name: s.name, positiveWindows: per.filter(p => p.trades >= 3 && p.expectancyR > 0).length, activeWindows: per.filter(p => p.trades >= 3).length, perWindowExpectancyR: per.map(p => p.trades ? p.expectancyR : null) };
  });

  // Does regime-aware selection help OUT OF SAMPLE? choose strategy×regime pairs positive on earlier windows, test on the next
  const minN = opts.selectionMinTrades || 8;
  let sel = [], base = [];
  for (let k = 1; k < K; k++) {
    const train = headline.filter(t => win(t) < k), test = headline.filter(t => win(t) === k);
    const good = new Set([...groupBy(train, t => `${t.strategyId}|${t.regime}`)].filter(([, ts]) => ts.length >= minN && stats(ts).expectancyR > 0).map(([key]) => key));
    base = base.concat(test); sel = sel.concat(test.filter(t => good.has(`${t.strategyId}|${t.regime}`)));
  }
  const selectionTest = { rule: `pairs with >=${minN} trades and positive expectancy in earlier windows`, unfiltered: stats(base), selected: stats(sel),
    verdict: !base.length ? 'NO DATA' : (sel.length >= 20 && stats(sel).expectancyR > stats(base).expectancyR ? 'SELECTION HELPS (out-of-sample)' : sel.length < 20 ? 'INCONCLUSIVE (too few selected trades)' : 'NO EVIDENCE THAT SELECTION HELPS') };

  const mc = monteCarlo(headline.map(t => t.netR), { sims: opts.sims || 1000, riskPct: opts.riskPct || config.riskPerTrade, horizon: Math.min(250, Math.max(20, headline.length)) });
  const warnings = [];
  if (headline.length < 30) warnings.push(`Only ${headline.length} trades at score >= ${minScore} — statistically weak. Use more symbols/years or read the score sweep.`);
  for (const s of strategies) if (s.trades < 30) warnings.push(`${s.name}: ${s.trades} trades (SMALL sample) — do not trust its expectancy.`);
  if (!strategies.length) warnings.push('No strategy produced a qualifying trade; see scoreSweep to judge whether minScore is too strict.');
  return { minScore, headline: stats(headline), tradesTotalCandidates: allTrades.length, strategies, byStrategyRegime, bySymbol, scoreSweep, walkForward: { windows, consistency }, selectionTest, monteCarlo: mc, warnings };
}

async function validate({ exchange, symbols, years = 1, step = 4, windows = 4, sims = 1000, minScore = config.minScore, candidateScore = 60, onProgress = () => {}, loadCandles }) {
  const registry = createDefaultRegistry();
  const all = []; let first = Infinity, last = 0, used = [];
  for (let i = 0; i < symbols.length; i++) {
    const sym = symbols[i];
    onProgress({ stage: 'load', symbol: sym, i, n: symbols.length });
    const c15 = loadCandles ? await loadCandles(sym, years) : await exchange.getKlineHistory(sym, '15', Math.round(years * 35040));
    if (!c15 || c15.length < 1500) { onProgress({ stage: 'skip', symbol: sym, reason: 'insufficient history' }); continue; }
    onProgress({ stage: 'replay', symbol: sym, i, n: symbols.length, candles: c15.length });
    const trades = runSymbol(sym, c15, registry, { step, candidateScore, trailing: true });
    first = Math.min(first, c15[0].time); last = Math.max(last, c15[c15.length - 1].time); used.push(sym);
    all.push(...trades);
  }
  const spanDays = Math.max(1, (last - first) / 86400000);
  const result = analyse(all, { minScore, windows, sims, spanDays });
  return { generatedAt: Date.now(), exchange: exchange?.name || 'custom', symbols: used, years, spanDays: r2(spanDays, 0), step,
    costs: { feePerSide: FEE, slippagePerSide: SLIP, funding8h: FUNDING_8H, trailing: true }, riskPerTrade: config.riskPerTrade, ...result };
}

module.exports = { validate, analyse, aggregate, simulate, runSymbol };
