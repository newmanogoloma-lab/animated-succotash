'use strict';

/** Evidence gate: mutes strategy x regime pairs whose VALIDATED expectancy is negative (needs >= minTrades). Off unless EVIDENCE_GATING=true. */
const fs = require('fs');
const path = require('path');

const DIR = path.join(process.env.ROBOT_DATA_DIR || path.resolve(__dirname, '..', '..', 'data'), 'validation');
let cache = { at: 0, report: null };

function latestPath() { return path.join(DIR, 'latest.json'); }
function load() {
  if (Date.now() - cache.at < 60000) return cache.report;
  let report = null;
  try { report = JSON.parse(fs.readFileSync(latestPath(), 'utf8')); } catch (_) { /* none yet */ }
  cache = { at: Date.now(), report };
  return report;
}
function allowed(strategyId, regime, minTrades = 30) {
  const r = load();
  if (!r || !r.byStrategyRegime) return true;
  const row = r.byStrategyRegime.find(x => x.strategyId === strategyId && x.regime === regime);
  if (!row || row.trades < minTrades) return true;          // no evidence either way -> allowed
  return row.expectancyR > 0;
}
function reset() { cache = { at: 0, report: null }; }

module.exports = { load, allowed, reset, DIR, latestPath };
