'use strict';

const logger = require('../utils/logger');
const journal = require('../journal/store');

/**
 * Exchange ↔ Database Reconciliation Engine
 * Compares local position/order records in SQLite against actual exchange state.
 * If discrepancies are found, triggers RECONCILIATION_FAILURE to freeze new trading.
 */
class ReconciliationEngine {
  constructor(options = {}) {
    this.riskEngine = options.riskEngine || null;
    this.notificationService = options.notificationService || null;
    this.lastReconciliation = null;
    this.status = 'HEALTHY'; // HEALTHY | RECONCILIATION_FAILURE | PENDING
    this.lastDiscrepancies = [];
  }

  setRiskEngine(riskEngine) {
    this.riskEngine = riskEngine;
  }

  setNotificationService(notificationService) {
    this.notificationService = notificationService;
  }

  /**
   * Reconcile local state against exchange state
   *
   * @param {Array} localPositions - Array of local position objects { symbol, positionSize, entry, side }
   * @param {Array} exchangePositions - Array of exchange position objects { symbol, size, avgPrice, side }
   * @param {Array} localOrders - Array of active local orders
   * @param {Array} exchangeOrders - Array of active exchange orders
   * @returns {object} Reconciliation result
   */
  async reconcile(localPositions = [], exchangePositions = [], localOrders = [], exchangeOrders = []) {
    const discrepancies = [];
    const timestamp = Date.now();

    // 1. Reconcile Positions
    const localPosMap = new Map();
    for (const p of localPositions) {
      if (p.positionSize && Math.abs(p.positionSize) > 0) {
        localPosMap.set(p.symbol, p);
      }
    }

    const exPosMap = new Map();
    for (const p of exchangePositions) {
      const sz = parseFloat(p.size || p.positionSize || 0);
      if (Math.abs(sz) > 0) {
        exPosMap.set(p.symbol, { ...p, size: sz });
      }
    }

    // Check for untracked positions on exchange
    for (const [symbol, exPos] of exPosMap) {
      const locPos = localPosMap.get(symbol);
      if (!locPos) {
        discrepancies.push({
          type: 'UNTRACKED_EXCHANGE_POSITION',
          symbol,
          exchangeSize: exPos.size,
          localSize: 0,
          severity: 'CRITICAL',
        });
      } else {
        const sizeDiff = Math.abs(exPos.size - locPos.positionSize);
        // Tolerate minor rounding below 0.0001
        if (sizeDiff > 0.0001) {
          discrepancies.push({
            type: 'POSITION_SIZE_MISMATCH',
            symbol,
            exchangeSize: exPos.size,
            localSize: locPos.positionSize,
            diff: sizeDiff,
            severity: 'CRITICAL',
          });
        }
      }
    }

    // Check for missing positions on exchange (local thinks open, exchange has none)
    for (const [symbol, locPos] of localPosMap) {
      if (!exPosMap.has(symbol)) {
        discrepancies.push({
          type: 'MISSING_EXCHANGE_POSITION',
          symbol,
          localSize: locPos.positionSize,
          exchangeSize: 0,
          severity: 'CRITICAL',
        });
      }
    }

    // 2. Reconcile Orders
    const localOrdMap = new Map((localOrders || []).map(o => [o.orderId || o.id, o]));
    const exOrdMap = new Map((exchangeOrders || []).map(o => [o.orderId || o.id, o]));

    for (const [id, exOrd] of exOrdMap) {
      if (!localOrdMap.has(id)) {
        discrepancies.push({
          type: 'UNTRACKED_EXCHANGE_ORDER',
          orderId: id,
          symbol: exOrd.symbol,
          severity: 'WARNING',
        });
      }
    }

    for (const [id, locOrd] of localOrdMap) {
      if (!exOrdMap.has(id)) {
        discrepancies.push({
          type: 'GHOST_LOCAL_ORDER',
          orderId: id,
          symbol: locOrd.symbol,
          severity: 'WARNING',
        });
      }
    }

    // 3. Process Result
    this.lastReconciliation = timestamp;
    this.lastDiscrepancies = discrepancies;

    const criticalIssues = discrepancies.filter(d => d.severity === 'CRITICAL');

    if (criticalIssues.length > 0) {
      this.status = 'RECONCILIATION_FAILURE';
      logger.error(`RECONCILIATION_FAILURE: ${criticalIssues.length} critical discrepancies detected!`, criticalIssues);

      // Freeze new trades immediately
      if (this.riskEngine && typeof this.riskEngine.emergencyStop === 'function') {
        this.riskEngine.emergencyStop();
      }

      // Persist state & log alert
      journal.setState('reconciliation_status', {
        status: 'RECONCILIATION_FAILURE',
        timestamp,
        discrepancies,
      });

      journal.logAlert('RECONCILIATION_FAILURE', JSON.stringify(criticalIssues), 'system', true);

      return {
        healthy: false,
        status: 'RECONCILIATION_FAILURE',
        timestamp,
        discrepancies,
      };
    }

    this.status = 'HEALTHY';
    journal.setState('reconciliation_status', {
      status: 'HEALTHY',
      timestamp,
      discrepancyCount: discrepancies.length,
    });

    return {
      healthy: true,
      status: 'HEALTHY',
      timestamp,
      discrepancies,
    };
  }

  getStatus() {
    return {
      status: this.status,
      lastReconciliation: this.lastReconciliation,
      discrepancies: this.lastDiscrepancies,
    };
  }
}

module.exports = ReconciliationEngine;
