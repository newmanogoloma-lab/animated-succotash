'use strict';
/**
 * Bybit instrument rules (tick size, qty step, min qty/notional) + manual-trade "ticket" builder.
 * A ticket is the signal re-expressed in values Bybit will accept as typed:
 *   entry  -> nearest tick
 *   SL     -> rounded AWAY from entry (never understates risk)
 *   TP     -> rounded TOWARD entry (more likely to fill)
 *   qty    -> floored to qtyStep (never exceeds your risk), checked against min qty / min notional
 * Ticket size is computed for YOUR account (TICKET_BALANCE x TICKET_RISK_PCT), not the paper balance.
 */
const config = require('../config');
const logger = require('../utils/logger');

const TTL_MS = 6 * 3600 * 1000;
let cache = { at: 0, map: new Map(), ok: false };
let inflight = null;

function decimals(step) {
  const s = String(step);
  if (s.includes('e-')) return parseInt(s.split('e-')[1], 10);
  const i = s.indexOf('.');
  return i < 0 ? 0 : s.length - i - 1;
}
const fix = (v, step) => Number(Number(v).toFixed(decimals(step)));
const roundTo = (v, step) => fix(Math.round(v / step + 1e-9) * step, step);
const floorTo = (v, step) => fix(Math.floor(v / step + 1e-9) * step, step);
const ceilTo = (v, step) => fix(Math.ceil(v / step - 1e-9) * step, step);

function parseInstrument(i) {
  return {
    symbol: i.symbol,
    tickSize: parseFloat(i.priceFilter?.tickSize) || 0,
    qtyStep: parseFloat(i.lotSizeFilter?.qtyStep) || 0,
    minQty: parseFloat(i.lotSizeFilter?.minOrderQty) || 0,
    maxQty: parseFloat(i.lotSizeFilter?.maxOrderQty) || Infinity,
    minNotional: parseFloat(i.lotSizeFilter?.minNotionalValue) || 5,
    maxLeverage: parseFloat(i.leverageFilter?.maxLeverage) || null,
  };
}

async function refresh(force = false) {
  if (!force && cache.ok && Date.now() - cache.at < TTL_MS) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const exchange = require('./index');
      const list = await exchange.getInstruments();
      const map = new Map();
      for (const i of list) map.set(i.symbol, parseInstrument(i));
      if (map.size) cache = { at: Date.now(), map, ok: true };
      logger.info(`Instrument rules loaded: ${map.size} symbols`);
    } catch (err) {
      logger.warn(`Instrument rules fetch failed: ${err.message}`);
      cache.at = Date.now() - TTL_MS + 60000; // retry in ~1 min, keep stale map
    } finally { inflight = null; }
    return cache;
  })();
  return inflight;
}

function getRules(symbol) { return cache.map.get(symbol) || null; }

/**
 * @param {{symbol,direction,entry,stopLoss,takeProfit}} sig
 * @param {object} [opt] {balance, riskPct, leverage, rules}
 */
function buildTicket(sig, opt = {}) {
  const rules = opt.rules || getRules(sig.symbol);
  const balance = opt.balance ?? config.ticketBalance ?? config.accountBalance;
  const riskPct = opt.riskPct ?? config.ticketRiskPct ?? config.riskPerTrade;
  const leverage = opt.leverage ?? config.defaultLeverage;
  const long = String(sig.direction).toUpperCase() === 'LONG';
  const notes = [];
  let entry = sig.entry, sl = sig.stopLoss, tp = sig.takeProfit;

  if (rules && rules.tickSize) {
    entry = roundTo(sig.entry, rules.tickSize);
    sl = long ? floorTo(sig.stopLoss, rules.tickSize) : ceilTo(sig.stopLoss, rules.tickSize);
    tp = long ? floorTo(sig.takeProfit, rules.tickSize) : ceilTo(sig.takeProfit, rules.tickSize);
  } else notes.push('Bybit rules not loaded - values are unrounded');

  const riskPerUnit = Math.abs(entry - sl);
  const wantedRiskUsd = balance * riskPct;
  let qty = riskPerUnit > 0 ? wantedRiskUsd / riskPerUnit : 0;
  let belowMin = false;
  if (rules && rules.qtyStep) {
    qty = floorTo(qty, rules.qtyStep);
    if (qty > rules.maxQty) { qty = rules.maxQty; notes.push('Capped at max order qty'); }
    if (qty < rules.minQty) { belowMin = true; notes.push(`Below Bybit min qty (${rules.minQty}) at your risk %`); }
  }
  const notional = qty * entry;
  if (rules && !belowMin && notional < rules.minNotional) { belowMin = true; notes.push(`Below Bybit min order value ($${rules.minNotional})`); }
  const margin = notional / leverage;
  if (margin > balance) notes.push(`Needs $${margin.toFixed(2)} margin at ${leverage}x - more than your balance`);
  if (rules?.maxLeverage && leverage > rules.maxLeverage) notes.push(`Max leverage on Bybit is ${rules.maxLeverage}x`);

  const riskUsd = qty * riskPerUnit;
  const rewardUsd = qty * Math.abs(tp - entry);
  return {
    symbol: sig.symbol, direction: String(sig.direction).toUpperCase(),
    entry, stopLoss: sl, takeProfit: tp, qty,
    notional: Number(notional.toFixed(2)), margin: Number(margin.toFixed(2)), leverage,
    riskUsd: Number(riskUsd.toFixed(2)), rewardUsd: Number(rewardUsd.toFixed(2)),
    rr: riskUsd > 0 ? Number((rewardUsd / riskUsd).toFixed(2)) : null,
    tickSize: rules?.tickSize ?? null, qtyStep: rules?.qtyStep ?? null,
    belowMin, rulesLoaded: !!rules, notes,
    basis: { balance, riskPct },
  };
}

module.exports = { refresh, getRules, buildTicket, parseInstrument, _roundTo: roundTo, _floorTo: floorTo, _ceilTo: ceilTo };
