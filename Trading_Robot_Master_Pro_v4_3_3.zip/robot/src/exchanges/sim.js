'use strict';

/**
 * Simulated exchange — deterministic synthetic Bybit-shaped market (regime-switching random walks).
 * Purpose: offline development, Codespaces demos, CI and repeatable validation runs. NOT real prices.
 * EXCHANGE=sim  (SIM_SEED, SIM_SYMBOLS control it)
 */
const STEP = 15 * 60000;
const EPOCH = Date.UTC(2025, 0, 1);
const SEED = parseInt(process.env.SIM_SEED || '42', 10);
const NAMES = ['BTC','ETH','SOL','XRP','DOGE','ADA','AVAX','LINK','DOT','LTC','NEAR','APT','ARB','OP','SUI','INJ','TIA','SEI','WLD','FET',
  'RENDER','AAVE','UNI','ATOM','FIL','ETC','BCH','TRX','PEPE','BONK'];
const COUNT = Math.max(3, Math.min(NAMES.length, parseInt(process.env.SIM_SYMBOLS || '30', 10)));
const SYMBOLS = NAMES.slice(0, COUNT).map(n => `${n}USDT`);

function hash(str) { let h = 2166136261; for (const c of str) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
function rngFrom(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

class Series {
  constructor(symbol) {
    this.symbol = symbol;
    this.rng = rngFrom(hash(symbol) ^ SEED);
    this.gauss = () => { let u = 0, v = 0; while (!u) u = this.rng(); while (!v) v = this.rng(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
    const mag = Math.pow(10, -1 + this.rng() * 5);        // 0.1 .. 10,000
    this.anchor = mag; this.price = mag;
    this.turnoverTarget = Math.pow(10, 6.7 + this.rng() * 1.8);   // ~5M .. 300M USDT / day
    this.o = []; this.h = []; this.l = []; this.c = []; this.v = [];
    this.regimeLeft = 0; this.drift = 0; this.vol = 0.003; this.mean = false;
  }
  _newRegime() {
    const pick = this.rng();
    this.regimeLeft = 80 + Math.floor(this.rng() * 500);
    if (pick < 0.28) { this.drift = 0.0006; this.vol = 0.0035; this.mean = false; }
    else if (pick < 0.56) { this.drift = -0.0006; this.vol = 0.0035; this.mean = false; }
    else if (pick < 0.86) { this.drift = 0; this.vol = 0.0022; this.mean = true; this.anchor = this.price; }
    else { this.drift = 0; this.vol = 0.009; this.mean = false; }
  }
  extend(n) {
    while (this.c.length < n) {
      if (this.regimeLeft-- <= 0) this._newRegime();
      const open = this.price;
      const pull = this.mean ? -0.04 * Math.log(open / this.anchor) : 0;
      const ret = this.drift + pull + this.vol * this.gauss();
      const close = open * Math.exp(ret);
      const wick = this.vol * 0.5;
      const high = Math.max(open, close) * (1 + Math.abs(this.gauss()) * wick);
      const low = Math.min(open, close) * (1 - Math.abs(this.gauss()) * wick);
      const surge = 1 + (Math.abs(ret) / this.vol) * 0.6;
      const vol = (this.turnoverTarget / 96 / open) * surge * (0.7 + this.rng() * 0.6);
      this.o.push(open); this.h.push(high); this.l.push(low); this.c.push(close); this.v.push(vol);
      this.price = close;
    }
  }
}

const store = new Map();
function series(sym) { if (!store.has(sym)) store.set(sym, new Series(sym)); return store.get(sym); }
function idxAt(ms) { return Math.max(0, Math.floor((ms - EPOCH) / STEP)); }
function minutes(interval) { return interval === 'D' ? 1440 : parseInt(interval, 10) || 15; }
const fmt = (x) => String(Number(x.toPrecision(8)));

function candles(symbol, interval, limit, endMs = Date.now()) {
  const s = series(symbol); const g = Math.max(1, minutes(interval) / 15);
  const endIdx = idxAt(endMs); s.extend(endIdx + 1);
  const lastBucket = Math.floor(endIdx / g);
  const out = [];
  for (let b = Math.max(0, lastBucket - limit + 1); b <= lastBucket; b++) {
    const a = b * g, z = Math.min(a + g - 1, endIdx);
    let hi = -Infinity, lo = Infinity, vol = 0, turn = 0;
    for (let i = a; i <= z; i++) { hi = Math.max(hi, s.h[i]); lo = Math.min(lo, s.l[i]); vol += s.v[i]; turn += s.v[i] * s.c[i]; }
    out.push({ time: EPOCH + a * STEP, open: s.o[a], high: hi, low: lo, close: s.c[z], volume: vol, turnover: turn });
  }
  return out;
}

async function getInstruments() {
  return SYMBOLS.map(symbol => ({
    symbol, baseCoin: symbol.replace('USDT', ''), quoteCoin: 'USDT', contractType: 'LinearPerpetual', status: 'Trading',
    lotSizeFilter: { minOrderQty: '0.001', maxOrderQty: '1000000', qtyStep: '0.001' }, priceFilter: { tickSize: '0.0001' },
    leverageFilter: { maxLeverage: '25' }, priceScale: '4',
  }));
}

function tickerFor(symbol) {
  const s = series(symbol); const idx = idxAt(Date.now()); s.extend(idx + 1);
  const last = s.c[idx]; const prev = s.c[Math.max(0, idx - 96)];
  let turn = 0; for (let i = Math.max(0, idx - 95); i <= idx; i++) turn += s.v[i] * s.c[i];
  const half = last * 0.00008;
  return { symbol, lastPrice: fmt(last), markPrice: fmt(last), indexPrice: fmt(last), bid1Price: fmt(last - half), ask1Price: fmt(last + half),
    turnover24h: String(Math.round(turn)), volume24h: String(Math.round(turn / last)), price24hPcnt: String((last / prev - 1).toFixed(4)),
    fundingRate: fmt(fundingAt(symbol, Date.now())), openInterestValue: String(Math.round(turn * 0.6)) };
}
async function getTickers(symbol) { return (symbol ? [symbol] : SYMBOLS).map(tickerFor); }
async function getKlines(symbol, interval, limit = 200, start, end) { return candles(symbol, interval, Math.min(limit, 1000), end || Date.now()); }
async function getKlineHistory(symbol, interval, maxCandles = 1000) { return candles(symbol, interval, maxCandles, Date.now()); }

function fundingAt(symbol, ms) {
  const h = hash(symbol) % 1000 / 1000, slot = Math.floor(ms / (8 * 3600000));
  return 0.0001 + 0.00045 * Math.sin(slot / 7 + h * 6.28) + 0.00008 * Math.sin(slot * 1.7 + h * 11);
}
async function getFundingRate(symbol) { const t = Math.floor(Date.now() / (8 * 3600000)) * 8 * 3600000; return { symbol, fundingRate: fundingAt(symbol, Date.now()), fundingTime: t }; }
async function getFundingHistory(symbol, limit = 8) {
  const base = Math.floor(Date.now() / (8 * 3600000)) * 8 * 3600000;
  return Array.from({ length: limit }, (_, i) => ({ symbol, fundingRate: String(fundingAt(symbol, base - i * 8 * 3600000)), fundingRateTimestamp: String(base - i * 8 * 3600000) }));
}
function oiAt(symbol, ms) {
  const t = tickerFor(symbol); const base = Number(t.openInterestValue) / Number(t.lastPrice);
  return base * (1 + 0.08 * Math.sin(ms / 3600000 / 5 + (hash(symbol) % 100)));
}
async function getOpenInterest(symbol) { return { symbol, openInterest: oiAt(symbol, Date.now()), time: Date.now() }; }
async function getOpenInterestHistory(symbol, intervalTime = '1h', limit = 6) {
  const base = Math.floor(Date.now() / 3600000) * 3600000;
  return Array.from({ length: limit }, (_, i) => ({ openInterest: String(oiAt(symbol, base - i * 3600000)), timestamp: String(base - i * 3600000) }));
}
async function getOrderBook(symbol, limit = 50) {
  const t = tickerFor(symbol); const mid = Number(t.lastPrice); const turn = Number(t.turnover24h);
  const rng = rngFrom(hash(symbol) ^ Math.floor(Date.now() / 5000));
  const levelUsd = Math.max(500, turn / 96 / 40);
  const bids = [], asks = [];
  for (let i = 0; i < limit; i++) {
    const off = 0.00008 + i * 0.00025;
    bids.push([fmt(mid * (1 - off)), fmt(levelUsd * (0.5 + rng()) / mid)]);
    asks.push([fmt(mid * (1 + off)), fmt(levelUsd * (0.5 + rng()) / mid)]);
  }
  return { symbol, ts: Date.now(), bids, asks };
}

module.exports = { SYMBOLS, getInstruments, getTickers, getKlines, getKlineHistory, getFundingRate, getFundingHistory,
  getOpenInterest, getOpenInterestHistory, getOrderBook };
