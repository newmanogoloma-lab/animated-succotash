'use strict';

/**
 * Self-healing socket wrapper: exponential back-off reconnect with jitter, app-level heartbeat,
 * stale-connection watchdog (no data for staleMs => drop and reconnect) and status counters.
 */
const { EventEmitter } = require('events');
const MiniWebSocket = require('./miniws');

class ManagedSocket extends EventEmitter {
  constructor({ url, name = 'ws', pingMs = 20000, staleMs = 30000, pingMsg = () => JSON.stringify({ op: 'ping' }), Impl = MiniWebSocket, headers = {}, minBackoffMs = 1000, maxBackoffMs = 30000 }) {
    super();
    Object.assign(this, { url, name, pingMs, staleMs, pingMsg, Impl, headers, minBackoffMs, maxBackoffMs });
    this.connected = false; this.attempts = 0; this.reconnects = 0; this.messages = 0;
    this.lastMessageAt = 0; this.lastPingAt = 0; this.lastError = null; this.connectedAt = 0;
    this._stopped = true;
  }

  start() {
    if (!this._stopped) return;
    this._stopped = false;
    this._open();
    this._tick = setInterval(() => this._watch(), 5000);
    if (this._tick.unref) this._tick.unref();
  }

  stop() {
    this._stopped = true;
    clearInterval(this._tick); clearTimeout(this._retry);
    if (this.ws) { try { this.ws.close(); } catch (_) { /* ignore */ } }
    this.connected = false;
  }

  _open() {
    let ws;
    try { ws = new this.Impl(this.url, { headers: this.headers }); } catch (e) { this.lastError = e.message; return this._schedule(); }
    this.ws = ws;
    ws.on('open', () => {
      this.connected = true; this.attempts = 0; this.connectedAt = this.lastMessageAt = Date.now();
      this.emit('open');
    });
    ws.on('message', (m) => { this.messages++; this.lastMessageAt = Date.now(); this.emit('message', typeof m === 'string' ? m : m.toString('utf8')); });
    ws.on('error', (e) => { this.lastError = e.message; });
    ws.on('close', () => {
      const was = this.connected;
      this.connected = false;
      if (ws !== this.ws) return;
      if (was) this.emit('close');
      if (!this._stopped) this._schedule();
    });
  }

  _schedule() {
    clearTimeout(this._retry);
    const delay = Math.min(this.maxBackoffMs, this.minBackoffMs * 2 ** Math.min(this.attempts++, 10)) * (0.8 + Math.random() * 0.4);
    this._retry = setTimeout(() => { if (!this._stopped) { this.reconnects++; this._open(); } }, delay);
    if (this._retry.unref) this._retry.unref();
  }

  _watch() {
    if (this._stopped || !this.connected) return;
    const now = Date.now();
    if (now - this.lastMessageAt > this.staleMs) {
      this.lastError = `stale: no data for ${Math.round((now - this.lastMessageAt) / 1000)}s`;
      try { this.ws.terminate(); } catch (_) { /* ignore */ }
      return;
    }
    if (now - this.lastPingAt >= this.pingMs) { this.lastPingAt = now; this.send(this.pingMsg(), true); }
  }

  send(msg, raw = false) { return this.connected && this.ws.send(raw ? msg : JSON.stringify(msg)); }

  status() {
    return { connected: this.connected, reconnects: this.reconnects, messages: this.messages,
      lastMessageAgeMs: this.lastMessageAt ? Date.now() - this.lastMessageAt : null, lastError: this.lastError,
      uptimeMs: this.connected ? Date.now() - this.connectedAt : 0 };
  }
}

module.exports = ManagedSocket;
