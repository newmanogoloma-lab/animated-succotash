'use strict';

/**
 * Bybit V5 WebSocket streams.
 *  - BybitPublicStream: tickers (price/funding/OI, snapshot+delta merge), kline, orderbook (snapshot+delta)
 *  - BybitPrivateStream: HMAC-authenticated order / position / execution / wallet updates (LIVE mode only)
 * Both reconnect, re-subscribe, heartbeat and expose status(). REST remains the fallback (see liveFeed).
 */
const crypto = require('crypto');
const { EventEmitter } = require('events');
const ManagedSocket = require('./managed');

const BATCH = 10; // args per subscribe request (Bybit spot limit; harmless for linear)

class BybitPublicStream extends EventEmitter {
  constructor({ url, Impl, staleMs = 30000 }) {
    super();
    this.sock = new ManagedSocket({ url, name: 'bybit-public', Impl, staleMs });
    this.topics = new Set();
    this.tickers = new Map(); this.books = new Map(); this.klines = new Map();
    this.latencyMs = null; this._rate = [];
    this.sock.on('open', () => { this._sendSub('subscribe', [...this.topics]); this.emit('open'); });
    this.sock.on('close', () => this.emit('close'));
    this.sock.on('message', (m) => this._onMessage(m));
  }

  start() { this.sock.start(); }
  stop() { this.sock.stop(); }

  subscribe(topics) { const add = topics.filter(t => !this.topics.has(t)); add.forEach(t => this.topics.add(t)); if (add.length) this._sendSub('subscribe', add); }
  unsubscribe(topics) {
    const rm = topics.filter(t => this.topics.has(t)); rm.forEach(t => this.topics.delete(t));
    if (rm.length) this._sendSub('unsubscribe', rm);
    for (const t of rm) {
      const [kind, ...rest] = t.split('.'); const sym = rest[rest.length - 1];
      if (kind === 'orderbook') this.books.delete(sym);
      if (kind === 'tickers') this.tickers.delete(sym);
      if (kind === 'kline') this.klines.delete(`${sym}|${rest[0]}`);
    }
  }
  _sendSub(op, args) { for (let i = 0; i < args.length; i += BATCH) this.sock.send({ op, args: args.slice(i, i + BATCH) }); }

  _onMessage(str) {
    let m; try { m = JSON.parse(str); } catch (_) { return; }
    if (m.op === 'pong' || m.ret_msg === 'pong') return;
    if (!m.topic) return;
    const now = Date.now();
    if (m.ts) { const lat = Math.max(0, now - m.ts); this.latencyMs = this.latencyMs == null ? lat : this.latencyMs * 0.9 + lat * 0.1; }
    this._rate.push(now); if (this._rate.length > 2000) this._rate.splice(0, this._rate.length - 2000);
    const [kind, ...rest] = m.topic.split('.');
    if (kind === 'tickers') this._ticker(m);
    else if (kind === 'kline') this._kline(m, rest[0], rest[1]);
    else if (kind === 'orderbook') this._book(m);
  }

  _ticker(m) {
    const d = m.data || {}; const sym = d.symbol || m.topic.split('.')[1];
    const cur = m.type === 'snapshot' || !this.tickers.has(sym) ? {} : this.tickers.get(sym);
    for (const [k, v] of Object.entries(d)) if (v !== undefined && v !== '') cur[k] = v;
    cur.symbol = sym; cur.ts = Date.now(); cur.serverTs = m.ts;
    this.tickers.set(sym, cur);
    const lastPrice = parseFloat(cur.lastPrice), markPrice = parseFloat(cur.markPrice || cur.lastPrice);
    if (lastPrice > 0) this.emit('ticker', { symbol: sym, lastPrice, markPrice, fundingRate: parseFloat(cur.fundingRate), ts: cur.ts });
  }

  _kline(m, interval, symbol) {
    for (const k of m.data || []) {
      const c = { time: Number(k.start), open: +k.open, high: +k.high, low: +k.low, close: +k.close, volume: +k.volume, turnover: +k.turnover, confirm: !!k.confirm };
      this.klines.set(`${symbol}|${interval}`, c);
      this.emit('kline', { symbol, interval, candle: c });
    }
  }

  _book(m) {
    const d = m.data || {}; const sym = d.s || m.topic.split('.')[2];
    let b = this.books.get(sym);
    if (m.type === 'snapshot' || !b) b = { bids: new Map(), asks: new Map(), ts: 0 };
    const apply = (map, levels) => { for (const [p, s] of levels || []) { if (+s === 0) map.delete(p); else map.set(p, s); } };
    apply(b.bids, d.b); apply(b.asks, d.a);
    b.ts = Date.now(); b.u = d.u;
    this.books.set(sym, b);
  }

  getTicker(symbol, maxAgeMs = 5000) { const t = this.tickers.get(symbol); return t && Date.now() - t.ts <= maxAgeMs ? t : null; }
  getTickerMap(maxAgeMs = 5000) {
    const out = {}; const now = Date.now();
    for (const [s, t] of this.tickers) if (now - t.ts <= maxAgeMs) out[s] = { lastPrice: parseFloat(t.lastPrice) || 0, markPrice: parseFloat(t.markPrice || t.lastPrice) || 0, fundingRate: parseFloat(t.fundingRate), ts: t.ts };
    return out;
  }
  getBook(symbol, maxAgeMs = 10000) {
    const b = this.books.get(symbol);
    if (!b || Date.now() - b.ts > maxAgeMs) return null;
    const top = (map, dir) => [...map.entries()].sort((x, y) => dir * (parseFloat(x[0]) - parseFloat(y[0]))).slice(0, 50);
    return { bids: top(b.bids, -1), asks: top(b.asks, 1), ts: b.ts };
  }
  getKline(symbol, interval) { return this.klines.get(`${symbol}|${interval}`) || null; }

  status() {
    const now = Date.now(); const recent = this._rate.filter(t => now - t < 10000).length;
    return { ...this.sock.status(), topics: this.topics.size, tickers: this.tickers.size, books: this.books.size, klines: this.klines.size,
      msgPerSec: +(recent / 10).toFixed(1), latencyMs: this.latencyMs == null ? null : Math.round(this.latencyMs) };
  }
}

class BybitPrivateStream extends EventEmitter {
  constructor({ url, apiKey, apiSecret, Impl, staleMs = 60000 }) {
    super();
    Object.assign(this, { apiKey, apiSecret });
    this.authed = false; this.lastEvent = null;
    this.sock = new ManagedSocket({ url, name: 'bybit-private', Impl, staleMs });
    this.sock.on('open', () => this._auth());
    this.sock.on('close', () => { this.authed = false; });
    this.sock.on('message', (m) => this._onMessage(m));
  }
  start() { this.sock.start(); }
  stop() { this.sock.stop(); }
  _auth() {
    const expires = Date.now() + 10000;
    const sig = crypto.createHmac('sha256', this.apiSecret).update(`GET/realtime${expires}`).digest('hex');
    this.sock.send({ op: 'auth', args: [this.apiKey, expires, sig] });
  }
  _onMessage(str) {
    let m; try { m = JSON.parse(str); } catch (_) { return; }
    if (m.op === 'auth') {
      this.authed = !!m.success;
      if (this.authed) this.sock.send({ op: 'subscribe', args: ['order', 'position', 'execution', 'wallet'] });
      else this.sock.lastError = `auth failed: ${m.ret_msg || 'unknown'}`;
      return;
    }
    if (m.topic) { this.lastEvent = { topic: m.topic, ts: Date.now() }; this.emit(m.topic.split('.')[0], m.data || []); }
  }
  status() { return { ...this.sock.status(), authed: this.authed, lastEvent: this.lastEvent }; }
}

module.exports = { BybitPublicStream, BybitPrivateStream };
