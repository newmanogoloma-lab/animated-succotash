'use strict';

/**
 * Minimal RFC 6455 WebSocket client using only Node core (net/tls/crypto) — no npm packages, works on Node >= 20
 * (Codespaces default), unlike the global WebSocket which needs Node 22. Supports text/binary frames, fragmentation,
 * ping/pong, close, masked client frames. Events: 'open', 'message'(string|Buffer), 'pong', 'close', 'error'.
 */
const net = require('net');
const tls = require('tls');
const crypto = require('crypto');
const { EventEmitter } = require('events');
const { URL } = require('url');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_PAYLOAD = 16 * 1024 * 1024;

class MiniWebSocket extends EventEmitter {
  constructor(url, opts = {}) {
    super();
    this.url = new URL(url);
    this.opts = opts;
    this.readyState = 0; // 0 connecting, 1 open, 2 closing, 3 closed
    this._buf = Buffer.alloc(0);
    this._upgraded = false;
    this._frag = [];
    this._fragOp = 0;
    this._connect();
  }

  _connect() {
    const u = this.url, secure = u.protocol === 'wss:';
    const port = Number(u.port) || (secure ? 443 : 80);
    const sock = secure ? tls.connect({ host: u.hostname, port, servername: u.hostname }) : net.connect({ host: u.hostname, port });
    this.sock = sock;
    sock.setNoDelay(true);
    this._key = crypto.randomBytes(16).toString('base64');
    this._connTimer = setTimeout(() => this._fail(new Error('WebSocket connect timeout')), this.opts.connectTimeoutMs || 10000);
    sock.once(secure ? 'secureConnect' : 'connect', () => {
      const headers = [
        `GET ${u.pathname}${u.search} HTTP/1.1`, `Host: ${u.host}`, 'Upgrade: websocket', 'Connection: Upgrade',
        `Sec-WebSocket-Key: ${this._key}`, 'Sec-WebSocket-Version: 13',
        ...Object.entries(this.opts.headers || {}).map(([k, v]) => `${k}: ${v}`), '', '',
      ];
      sock.write(headers.join('\r\n'));
    });
    sock.on('data', (d) => { try { this._onData(d); } catch (e) { this._fail(e); } });
    sock.on('error', (e) => this._fail(e));
    sock.on('close', () => this._closed());
  }

  _onData(d) {
    if (!this._upgraded) {
      this._buf = Buffer.concat([this._buf, d]);
      const end = this._buf.indexOf('\r\n\r\n');
      if (end < 0) return;
      const head = this._buf.slice(0, end).toString('utf8');
      const rest = this._buf.slice(end + 4);
      this._buf = Buffer.alloc(0);
      const accept = crypto.createHash('sha1').update(this._key + GUID).digest('base64');
      if (!/^HTTP\/1\.1 101/i.test(head) || !head.toLowerCase().includes(`sec-websocket-accept: ${accept.toLowerCase()}`)) {
        return this._fail(new Error(`WebSocket handshake failed: ${head.split('\r\n')[0]}`));
      }
      clearTimeout(this._connTimer);
      this._upgraded = true;
      this.readyState = 1;
      this.emit('open');
      if (rest.length) this._frames(rest);
      return;
    }
    this._frames(d);
  }

  _frames(d) {
    this._buf = Buffer.concat([this._buf, d]);
    for (;;) {
      const b = this._buf;
      if (b.length < 2) return;
      const fin = !!(b[0] & 0x80), op = b[0] & 0x0f, masked = !!(b[1] & 0x80);
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > MAX_PAYLOAD) throw new Error('WebSocket frame too large');
      const maskLen = masked ? 4 : 0;
      if (b.length < off + maskLen + len) return;
      let payload = b.slice(off + maskLen, off + maskLen + len);
      if (masked) { const m = b.slice(off, off + 4); payload = Buffer.from(payload); for (let i = 0; i < payload.length; i++) payload[i] ^= m[i & 3]; }
      this._buf = b.slice(off + maskLen + len);

      if (op === 0x8) { this._send(0x8, payload.slice(0, 2)); this.readyState = 2; this.sock.end(); }
      else if (op === 0x9) this._send(0xA, payload);
      else if (op === 0xA) this.emit('pong', payload);
      else if (op === 0x0 || op === 0x1 || op === 0x2) {
        if (op !== 0) { this._fragOp = op; this._frag = [payload]; } else this._frag.push(payload);
        if (fin) {
          const msg = Buffer.concat(this._frag);
          this._frag = [];
          this.emit('message', this._fragOp === 1 ? msg.toString('utf8') : msg);
        }
      }
    }
  }

  _send(op, payload) {
    if (!this.sock || this.sock.destroyed || !this._upgraded) return false;
    const n = payload.length;
    const head = n < 126 ? Buffer.from([0x80 | op, 0x80 | n])
      : n < 65536 ? Buffer.from([0x80 | op, 0x80 | 126, n >> 8, n & 255])
        : (() => { const h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 0x80 | 127; h.writeBigUInt64BE(BigInt(n), 2); return h; })();
    const mask = crypto.randomBytes(4);
    const body = Buffer.from(payload);
    for (let i = 0; i < body.length; i++) body[i] ^= mask[i & 3];
    this.sock.write(Buffer.concat([head, mask, body]));
    return true;
  }

  send(data) { return this.readyState === 1 && this._send(typeof data === 'string' ? 0x1 : 0x2, typeof data === 'string' ? Buffer.from(data) : data); }
  ping(data = Buffer.alloc(0)) { return this.readyState === 1 && this._send(0x9, data); }
  close() { if (this.readyState === 1) { this.readyState = 2; this._send(0x8, Buffer.alloc(0)); setTimeout(() => this.terminate(), 1000).unref(); } else this.terminate(); }
  terminate() { if (this.sock) this.sock.destroy(); this._closed(); }

  _fail(err) {
    if (this.listenerCount('error')) this.emit('error', err);
    this.terminate();
  }
  _closed() {
    if (this.readyState === 3 && this._done) return;
    this._done = true;
    clearTimeout(this._connTimer);
    const was = this.readyState;
    this.readyState = 3;
    if (was !== 3) this.emit('close');
  }
}

module.exports = MiniWebSocket;
