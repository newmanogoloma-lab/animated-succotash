'use strict';

/**
 * Exchange facade. Everything in the app talks to this object; EXCHANGE=bybit|sim picks the adapter.
 * Adapter contract (see base.js): getInstruments, getTickers, getKlines, getKlineHistory, getFundingRate,
 * getOpenInterest + depth/funding/OI-history helpers (getOrderBook, getFundingHistory, getOpenInterestHistory).
 * Methods are looked up on every call, so tests can still stub individual functions on the adapter module.
 */
const config = require('../config');

const ADAPTERS = {
  bybit: { id: 'bybit', label: 'Bybit V5 linear USDT perpetuals', kind: 'live', load: () => require('./bybit'), ws: true },
  sim:   { id: 'sim',   label: 'Simulated exchange (deterministic, offline)', kind: 'simulated', load: () => require('./sim'), ws: false },
};

const OPTIONAL = {
  getOrderBook: async () => null,
  getFundingHistory: async () => [],
  getOpenInterestHistory: async () => [],
};

let override = null;
function active() {
  if (override) return override;
  const a = ADAPTERS[config.exchange] || ADAPTERS.bybit;
  return a.load();
}

const facade = new Proxy({}, {
  get(_t, key) {
    if (key === 'then' || typeof key === 'symbol') return undefined;
    if (key === 'name') return (ADAPTERS[config.exchange] || ADAPTERS.bybit).id;
    if (key === '_use') return (mod) => { override = mod; };
    if (key === 'info') return () => ({ active: (ADAPTERS[config.exchange] || ADAPTERS.bybit).id,
      adapters: Object.values(ADAPTERS).map(a => ({ id: a.id, label: a.label, kind: a.kind, websocket: a.ws })) });
    return (...args) => {
      const mod = active();
      const fn = mod[key] || OPTIONAL[key];
      if (!fn) throw new Error(`Exchange '${config.exchange}' does not implement ${String(key)}`);
      return fn.apply(mod, args);
    };
  },
});

module.exports = facade;
