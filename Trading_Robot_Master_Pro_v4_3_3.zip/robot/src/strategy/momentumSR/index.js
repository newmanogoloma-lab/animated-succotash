'use strict';

const indicators = require('../../indicators');
const { detectRegime } = require('../../market/regime');

const PASS = 'PASS';
const FAIL = 'FAIL';
const NA   = 'NOT_AVAILABLE';

const DEFAULT_CONFIG = {
  lookback: 20,
  minScore: 80,
  minRR: 2.0,
  weights: {
    regimeAlignment: 20,
    srRetest: 30,
    momentumConfirmation: 30,
    volumeSupport: 20,
  },
};

/**
 * Momentum & Support/Resistance Strategy (momentum_sr_v1)
 * Trades key horizontal S/R flips and retests with directional momentum follow-through.
 */
class MomentumSRStrategy {
  constructor(options = {}) {
    this.id = 'momentum_sr_v1';
    this.name = options.name || 'Momentum & S/R';
    this.version = '1.0.0';
    this.enabled = options.enabled !== undefined ? options.enabled : true;
    this.cfg = { ...DEFAULT_CONFIG, ...options };
  }

  evaluate(marketData) {
    const { symbol, candles4H = [], candles1H = [], candles15M = [] } = marketData;

    if (!this.enabled) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'STRATEGY_DISABLED',
        timestamp: Date.now(),
      };
    }

    const regime = detectRegime(candles4H, candles1H, candles15M);
    const conditions = {};
    const details = {};

    // 1. Regime alignment (STRONG_TREND, WEAK_TREND, or BREAKOUT)
    const isTrendingOrBreak = ['STRONG_TREND', 'WEAK_TREND', 'BREAKOUT', 'TRENDING_UP', 'TRENDING_DOWN'].includes(regime.canonicalRegime || regime.regime);
    conditions.regimeAlignment = isTrendingOrBreak ? PASS : FAIL;
    details.regime = regime.summary;

    if (candles1H.length < 30) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'INSUFFICIENT_1H_CANDLES',
        regime,
        timestamp: Date.now(),
      };
    }

    const lastIdx = candles1H.length - 1;
    const last1H = candles1H[lastIdx];
    const prev1H = candles1H[lastIdx - 1];

    // Find key swing highs and lows in the last 25 bars
    const window = candles1H.slice(-25, -2);
    const swingHigh = Math.max(...window.map(c => c.high));
    const swingLow = Math.min(...window.map(c => c.low));

    let direction = null;
    let srRetest = false;

    // Resistance flipped to support (BULLISH RETEST)
    if (prev1H.low <= swingHigh * 1.003 && last1H.close > swingHigh) {
      direction = 'LONG';
      srRetest = true;
    }
    // Support flipped to resistance (BEARISH RETEST)
    else if (prev1H.high >= swingLow * 0.997 && last1H.close < swingLow) {
      direction = 'SHORT';
      srRetest = true;
    }

    conditions.srRetest = srRetest ? PASS : FAIL;
    details.srLevels = `SwingHigh: ${swingHigh.toFixed(4)}, SwingLow: ${swingLow.toFixed(4)}`;

    // 2. Momentum confirmation (EMA 9 > EMA 21 or RSI alignment)
    const closes = candles1H.map(c => c.close);
    const ema9 = indicators.ema(closes, 9);
    const ema21 = indicators.ema(closes, 21);
    const rsiVals = indicators.rsi(candles1H, 14);

    const lastEma9 = ema9[lastIdx];
    const lastEma21 = ema21[lastIdx];
    const lastRsi = rsiVals[lastIdx];

    let momentumOk = false;
    if (direction === 'LONG' && lastEma9 > lastEma21 && lastRsi > 50) momentumOk = true;
    if (direction === 'SHORT' && lastEma9 < lastEma21 && lastRsi < 50) momentumOk = true;

    conditions.momentumConfirmation = momentumOk ? PASS : FAIL;

    // 3. Volume support
    const volMA = indicators.volumeMA(candles1H, 20);
    const lastVolMA = volMA[lastIdx];
    const volOk = !isNaN(lastVolMA) && last1H.volume >= lastVolMA * 0.9;
    conditions.volumeSupport = volOk ? PASS : FAIL;

    // Calculate score
    let totalWeight = 0;
    let earnedWeight = 0;
    for (const [key, res] of Object.entries(conditions)) {
      const w = this.cfg.weights[key] || 0;
      if (res === NA) continue;
      totalWeight += w;
      if (res === PASS) earnedWeight += w;
    }
    const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 0;

    // Levels
    const entry = last1H.close;
    let stopLoss, takeProfit;
    const atrVals = indicators.atr(candles1H, 14);
    const atrNow = atrVals[lastIdx] || (entry * 0.015);

    if (direction === 'LONG') {
      stopLoss = swingHigh - atrNow * 1.0;
      const risk = entry - stopLoss;
      takeProfit = entry + risk * this.cfg.minRR;
    } else if (direction === 'SHORT') {
      stopLoss = swingLow + atrNow * 1.0;
      const risk = stopLoss - entry;
      takeProfit = entry - risk * this.cfg.minRR;
    } else {
      stopLoss = entry;
      takeProfit = entry;
    }

    const riskDist = Math.abs(entry - stopLoss);
    const rewardDist = Math.abs(takeProfit - entry);
    const riskReward = riskDist > 0 ? parseFloat((rewardDist / riskDist).toFixed(2)) : 0;

    const criticalFail = !srRetest ? 'NO_SR_RETEST' : (direction === null ? 'NO_DIRECTION' : null);
    const qualified = !criticalFail && score >= this.cfg.minScore && riskReward >= this.cfg.minRR;

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      symbol,
      direction,
      score,
      qualified,
      criticalFail,
      regime,
      entry: parseFloat(entry.toFixed(6)),
      stopLoss: parseFloat(stopLoss.toFixed(6)),
      takeProfit: parseFloat(takeProfit.toFixed(6)),
      riskReward,
      conditions,
      details,
      timestamp: Date.now(),
      configuration: this.cfg,
    };
  }
}

module.exports = MomentumSRStrategy;
