'use strict';

const indicators = require('../../indicators');
const { detectRegime } = require('../../market/regime');

const PASS = 'PASS';
const FAIL = 'FAIL';
const NA   = 'NOT_AVAILABLE';

const DEFAULT_CONFIG = {
  orbBars: 4, // First 4 15M bars (1 hour range)
  minScore: 80,
  minRR: 2.0,
  weights: {
    regimeAlignment: 20,
    rangeBreakout: 35,
    volumeExpansion: 25,
    expansionFollowThrough: 20,
  },
};

/**
 * Opening Range Breakout Strategy (orb_v1)
 * Captures directional expansions outside defined multi-bar session opening ranges.
 */
class OpeningRangeBreakoutStrategy {
  constructor(options = {}) {
    this.id = 'orb_v1';
    this.name = options.name || 'Opening Range Breakout';
    this.version = '1.0.0';
    this.enabled = options.enabled !== undefined ? options.enabled : true;
    this.cfg = { ...DEFAULT_CONFIG, ...options };
  }

  evaluate(marketData) {
    const { symbol, candles4H = [], candles1H = [], candles15M = [] } = marketData;

    if (!this.enabled) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'STRATEGY_DISABLED',
        timestamp: Date.now(),
      };
    }

    const regime = detectRegime(candles4H, candles1H, candles15M);
    const conditions = {};
    const details = {};

    // 1. Regime alignment (BREAKOUT, STRONG_TREND, or COMPRESSION)
    const isSuitableRegime = ['BREAKOUT', 'STRONG_TREND', 'COMPRESSION', 'HIGH_VOLATILITY'].includes(regime.canonicalRegime || regime.regime);
    conditions.regimeAlignment = isSuitableRegime ? PASS : FAIL;
    details.regime = regime.summary;

    const candles = candles15M.length >= 20 ? candles15M : candles1H;
    if (candles.length < 15) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'INSUFFICIENT_CANDLES',
        regime,
        timestamp: Date.now(),
      };
    }

    const orbBars = this.cfg.orbBars;
    const orbCandles = candles.slice(-orbBars - 4, -1);
    const lastBar = candles[candles.length - 1];

    const orbHigh = Math.max(...orbCandles.map(c => c.high));
    const orbLow = Math.min(...orbCandles.map(c => c.low));

    let direction = null;
    let rangeBreak = false;

    if (lastBar.close > orbHigh) {
      direction = 'LONG';
      rangeBreak = true;
    } else if (lastBar.close < orbLow) {
      direction = 'SHORT';
      rangeBreak = true;
    }

    conditions.rangeBreakout = rangeBreak ? PASS : FAIL;
    details.orbRange = `High: ${orbHigh.toFixed(4)}, Low: ${orbLow.toFixed(4)}, Close: ${lastBar.close.toFixed(4)}`;

    // 2. Volume expansion
    const volMA = indicators.volumeMA(candles, 20);
    const lastVolMA = volMA[volMA.length - 1];
    const volExpansion = !isNaN(lastVolMA) && lastBar.volume >= lastVolMA * 1.2;
    conditions.volumeExpansion = volExpansion ? PASS : FAIL;

    // 3. Expansion follow through (strong close)
    const barRange = lastBar.high - lastBar.low;
    const strongClose = barRange > 0
      ? (direction === 'LONG' ? (lastBar.close - lastBar.low) / barRange >= 0.65 : (lastBar.high - lastBar.close) / barRange >= 0.65)
      : false;
    conditions.expansionFollowThrough = strongClose ? PASS : FAIL;

    // Calculate score
    let totalWeight = 0;
    let earnedWeight = 0;
    for (const [key, res] of Object.entries(conditions)) {
      const w = this.cfg.weights[key] || 0;
      if (res === NA) continue;
      totalWeight += w;
      if (res === PASS) earnedWeight += w;
    }
    const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 0;

    // Levels
    const entry = lastBar.close;
    let stopLoss, takeProfit;
    const atrVals = indicators.atr(candles, 14);
    const atrNow = atrVals[atrVals.length - 1] || (entry * 0.012);

    if (direction === 'LONG') {
      stopLoss = Math.min(lastBar.low, orbHigh - atrNow * 0.5);
      const risk = entry - stopLoss;
      takeProfit = entry + risk * this.cfg.minRR;
    } else if (direction === 'SHORT') {
      stopLoss = Math.max(lastBar.high, orbLow + atrNow * 0.5);
      const risk = stopLoss - entry;
      takeProfit = entry - risk * this.cfg.minRR;
    } else {
      stopLoss = entry;
      takeProfit = entry;
    }

    const riskDist = Math.abs(entry - stopLoss);
    const rewardDist = Math.abs(takeProfit - entry);
    const riskReward = riskDist > 0 ? parseFloat((rewardDist / riskDist).toFixed(2)) : 0;

    const criticalFail = !rangeBreak ? 'NO_ORB_BREAK' : (direction === null ? 'NO_DIRECTION' : null);
    const qualified = !criticalFail && score >= this.cfg.minScore && riskReward >= this.cfg.minRR;

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      symbol,
      direction,
      score,
      qualified,
      criticalFail,
      regime,
      entry: parseFloat(entry.toFixed(6)),
      stopLoss: parseFloat(stopLoss.toFixed(6)),
      takeProfit: parseFloat(takeProfit.toFixed(6)),
      riskReward,
      conditions,
      details,
      timestamp: Date.now(),
      configuration: this.cfg,
    };
  }
}

module.exports = OpeningRangeBreakoutStrategy;
