'use strict';

const indicators = require('../../indicators');
const { detectRegime } = require('../../market/regime');

const PASS = 'PASS';
const FAIL = 'FAIL';
const NA   = 'NOT_AVAILABLE';

const DEFAULT_CONFIG = {
  emaFast: 20,
  emaSlow: 50,
  minScore: 80,
  minRR: 2.0,
  weights: {
    htfTrendAlignment: 25,
    pullbackDepth: 25,
    reversalConfirmation: 20,
    momentumReset: 15,
    volumeAbsorption: 15,
  },
};

class PullbackStrategy {
  constructor(options = {}) {
    this.id = 'pullback_v1';
    this.name = options.name || 'Trend Pullback Continuation';
    this.version = '1.0.0';
    this.enabled = options.enabled !== undefined ? options.enabled : true;
    this.cfg = { ...DEFAULT_CONFIG, ...options };
  }

  evaluate(marketData) {
    const { symbol, candles4H = [], candles1H = [], candles15M = [], meta = {} } = marketData;

    if (!this.enabled) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'STRATEGY_DISABLED',
        timestamp: Date.now(),
      };
    }

    const regime = detectRegime(candles4H, candles1H, candles15M);
    const conditions = {};
    const details = {};

    const refCandles = (candles1H && candles1H.length >= 50) ? candles1H : candles4H;
    if (!refCandles || refCandles.length < 50) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'INSUFFICIENT_CANDLES',
        regime,
        timestamp: Date.now(),
      };
    }

    // 1. Higher Timeframe Trend Alignment
    const closes = refCandles.map(c => c.close);
    const ema20 = indicators.ema(closes, this.cfg.emaFast);
    const ema50 = indicators.ema(closes, this.cfg.emaSlow);
    const lastClose = closes[closes.length - 1];
    const lastEma20 = ema20[ema20.length - 1];
    const lastEma50 = ema50[ema50.length - 1];

    let direction = null;
    let trendAligned = false;

    if (lastEma20 > lastEma50) {
      direction = 'LONG';
      trendAligned = true;
    } else if (lastEma20 < lastEma50) {
      direction = 'SHORT';
      trendAligned = true;
    }
    conditions.htfTrendAlignment = trendAligned ? PASS : FAIL;
    details.trend = `EMA20: ${lastEma20?.toFixed(4)}, EMA50: ${lastEma50?.toFixed(4)}`;

    // 2. Pullback Depth (Price retracing to EMA 20 zone without breaking EMA 50)
    const atrVals = indicators.atr(refCandles, 14);
    const atrNow = atrVals[atrVals.length - 1] || (lastClose * 0.01);
    const lastCandle = refCandles[refCandles.length - 1];

    let goodDepth = false;
    if (direction === 'LONG') {
      // Pulled back near EMA20 (within 1 ATR) and staying above EMA50
      const touchedZone = lastCandle.low <= (lastEma20 + atrNow * 0.5) && lastCandle.close >= (lastEma50 - atrNow * 0.2);
      goodDepth = touchedZone;
    } else if (direction === 'SHORT') {
      // Pulled back near EMA20 (within 1 ATR) and staying below EMA50
      const touchedZone = lastCandle.high >= (lastEma20 - atrNow * 0.5) && lastCandle.close <= (lastEma50 + atrNow * 0.2);
      goodDepth = touchedZone;
    }
    conditions.pullbackDepth = goodDepth ? PASS : FAIL;

    // 3. Reversal Confirmation (Trigger bar on 15M or 1H closing in trend direction)
    let reversalOk = false;
    const triggerCandles = (candles15M && candles15M.length >= 3) ? candles15M : refCandles;
    const lastTrigger = triggerCandles[triggerCandles.length - 1];
    if (direction === 'LONG') {
      reversalOk = lastTrigger.close > lastTrigger.open;
    } else if (direction === 'SHORT') {
      reversalOk = lastTrigger.close < lastTrigger.open;
    }
    conditions.reversalConfirmation = reversalOk ? PASS : FAIL;

    // 4. Momentum Reset (RSI cooled off from extremes)
    const rsiVals = indicators.rsi(refCandles, 14);
    const lastRsi = rsiVals[rsiVals.length - 1];
    let rsiReset = false;
    if (direction === 'LONG' && lastRsi >= 40 && lastRsi <= 65) rsiReset = true;
    if (direction === 'SHORT' && lastRsi <= 60 && lastRsi >= 35) rsiReset = true;
    conditions.momentumReset = isNaN(lastRsi) ? NA : (rsiReset ? PASS : FAIL);

    // 5. Volume Absorption (Volume on pullback lower than trend volume)
    const volMA = indicators.volumeMA(refCandles, 20);
    const lastVolMA = volMA[volMA.length - 1];
    const volOk = !isNaN(lastVolMA) && lastVolMA > 0 && lastCandle.volume <= lastVolMA * 1.5;
    conditions.volumeAbsorption = volOk ? PASS : FAIL;

    // Score
    let totalWeight = 0;
    let earnedWeight = 0;
    for (const [key, res] of Object.entries(conditions)) {
      const w = this.cfg.weights[key] || 0;
      if (res === NA) continue;
      totalWeight += w;
      if (res === PASS) earnedWeight += w;
    }
    const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 0;

    // Trade Levels
    const entry = lastClose;
    let stopLoss, takeProfit;
    if (direction === 'LONG') {
      const recentLow = Math.min(...refCandles.slice(-10).map(c => c.low));
      stopLoss = Math.min(recentLow, lastEma50 - atrNow * 0.5);
      const risk = entry - stopLoss;
      takeProfit = entry + risk * this.cfg.minRR;
    } else if (direction === 'SHORT') {
      const recentHigh = Math.max(...refCandles.slice(-10).map(c => c.high));
      stopLoss = Math.max(recentHigh, lastEma50 + atrNow * 0.5);
      const risk = stopLoss - entry;
      takeProfit = entry - risk * this.cfg.minRR;
    } else {
      stopLoss = entry;
      takeProfit = entry;
    }

    const riskDist = Math.abs(entry - stopLoss);
    const rewardDist = Math.abs(takeProfit - entry);
    const riskReward = riskDist > 0 ? parseFloat((rewardDist / riskDist).toFixed(2)) : 0;

    const criticalFail = !trendAligned ? 'NO_TREND' : (direction === null ? 'NO_DIRECTION' : null);
    const qualified = !criticalFail && score >= this.cfg.minScore && riskReward >= this.cfg.minRR;

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      symbol,
      direction,
      score,
      qualified,
      criticalFail,
      regime,
      entry: parseFloat(entry.toFixed(6)),
      stopLoss: parseFloat(stopLoss.toFixed(6)),
      takeProfit: parseFloat(takeProfit.toFixed(6)),
      riskReward,
      conditions,
      details,
      timestamp: Date.now(),
      configuration: this.cfg,
    };
  }
}

module.exports = PullbackStrategy;
