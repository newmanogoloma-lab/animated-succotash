'use strict';

const indicators = require('../../indicators');
const config = require('../../config');
const { validateMarketData } = require('../../market/dataQuality');
const { detectRegime } = require('../../market/regime');

const PASS = 'PASS';
const FAIL = 'FAIL';
const NA   = 'NOT_AVAILABLE';

/** Safely get last value from array */
function last(arr, offset = 0) {
  if (!arr || arr.length === 0) return NaN;
  const v = arr[arr.length - 1 - offset];
  return v ?? NaN;
}

function lastCandle(candles, offset = 0) {
  if (!candles || candles.length === 0) return null;
  return candles[candles.length - 1 - offset] || null;
}

/**
 * GPS Strategy — Multi-timeframe setup evaluation
 *
 * 4H = TREND
 * 1H = STRUCTURE
 * 15M = TRIGGER
 *
 * Each condition returns PASS | FAIL | NOT_AVAILABLE
 */
class GPSStrategy {
  constructor(strategyConfig = {}) {
    this.id = 'gps_v1';
    this.name = strategyConfig.name || config.gpsStrategyName || 'GPS';
    this.version = '1.0.0';
    this.enabled = strategyConfig.enabled !== false;

    // Configuration with defaults
    this.cfg = {
      minScore:          strategyConfig.minScore          ?? config.minScore,
      minRR:             strategyConfig.minRR             ?? config.minRR,
      minVolumeMultiplier: strategyConfig.minVolumeMultiplier ?? config.minVolumeMultiplier,

      // Condition weights (must sum to 100)
      weights: strategyConfig.weights ?? {
        trend4H:   20,
        sweep:     10,
        reclaim:   10,
        structure1H: 15,
        trigger15M: 15,
        rsi:       10,
        alligator:  8,
        volume:     7,
        funding:    3,
        openInterest: 2,
      },

      // Condition toggles
      conditions: strategyConfig.conditions ?? {
        trend4H:    true,
        sweep:      true,
        reclaim:    true,
        structure1H: true,
        trigger15M:  true,
        rsi:         true,
        alligator:   true,
        volume:      true,
        funding:     true,
        openInterest: true,
      },

      // Indicator parameters
      rsiPeriod:    strategyConfig.rsiPeriod    ?? 14,
      rsiOverbought: strategyConfig.rsiOverbought ?? 70,
      rsiOversold:   strategyConfig.rsiOversold  ?? 30,
      atrPeriod:    strategyConfig.atrPeriod    ?? 14,
      volMAPeriod:  strategyConfig.volMAPeriod  ?? 20,
      swingLookback: strategyConfig.swingLookback ?? 5,
    };
  }

  /** Update name without changing ID or corrupting history */
  rename(newName) {
    this.name = newName;
  }

  /**
   * Main evaluation function
   * @param {object} data — { candles4H, candles1H, candles15M, meta }
   * @returns {object} — full signal object
   */
  evaluate(data) {
    const { candles4H = [], candles1H = [], candles15M = [], meta = {} } = data;
    const { symbol } = meta;

    // ── DATA QUALITY FIREWALL ──────────────────────────────────────────
    if (config.dataQualityEnforce) {
      const dq = validateMarketData({ symbol, candles4H, candles1H, candles15M });
      if (!dq.valid) {
        return {
          strategyId:      this.id,
          strategyName:    this.name,
          strategyVersion: this.version,
          symbol,
          direction: null,
          score: 0,
          qualified: false,
          criticalFail: dq.reason,
          regime: null,
          entry: null,
          stopLoss: null,
          takeProfit: null,
          riskReward: 0,
          conditions: {},
          details: { dataQuality: dq.reason },
          timestamp: Date.now(),
          configuration: this.getConfigSnapshot(),
        };
      }
    }

    // ── MARKET REGIME DETECTION ────────────────────────────────────────
    const regime = detectRegime(candles4H, candles1H);

    const conditions = {};
    const details = {};

    // ── 4H TREND ──────────────────────────────────────────────────────────
    const trend4H = this._eval4HTrend(candles4H, conditions, details);

    // ── LIQUIDITY SWEEP ───────────────────────────────────────────────────
    this._evalSweep(candles4H, candles1H, trend4H, conditions, details);

    // ── RECLAIM ───────────────────────────────────────────────────────────
    this._evalReclaim(candles4H, candles1H, trend4H, conditions, details);

    // ── 1H STRUCTURE ──────────────────────────────────────────────────────
    this._eval1HStructure(candles1H, trend4H, conditions, details);

    // ── 15M TRIGGER ───────────────────────────────────────────────────────
    this._eval15MTrigger(candles15M, trend4H, conditions, details);

    // ── RSI ───────────────────────────────────────────────────────────────
    this._evalRSI(candles15M, candles1H, trend4H, conditions, details);

    // ── ALLIGATOR ─────────────────────────────────────────────────────────
    this._evalAlligator(candles1H, trend4H, conditions, details);

    // ── VOLUME ────────────────────────────────────────────────────────────
    this._evalVolume(candles15M, conditions, details);

    // ── FUNDING ───────────────────────────────────────────────────────────
    this._evalFunding(meta, trend4H, conditions, details);

    // ── OPEN INTEREST ─────────────────────────────────────────────────────
    this._evalOI(meta, conditions, details);

    // ── SCORE ─────────────────────────────────────────────────────────────
    const score = this._calcScore(conditions);
    const direction = trend4H === 'BULLISH' ? 'LONG' : trend4H === 'BEARISH' ? 'SHORT' : null;

    // ── ENTRY / SL / TP ───────────────────────────────────────────────────
    const levels = this._calcLevels(candles15M, candles1H, candles4H, direction, meta);

    // ── CRITICAL OVERRIDES ────────────────────────────────────────────────
    const criticalFail = this._checkCritical(conditions, details);

    const qualified = !criticalFail && score >= this.cfg.minScore && direction !== null
      && levels.riskReward >= this.cfg.minRR;

    return {
      strategyId:      this.id,
      strategyName:    this.name,
      strategyVersion: this.version,
      symbol,
      direction,
      score,
      qualified,
      criticalFail,
      regime,
      entry:      levels.entry,
      stopLoss:   levels.stopLoss,
      takeProfit: levels.takeProfit,
      riskReward: levels.riskReward,
      conditions,
      details,
      timestamp:  Date.now(),
      configuration: this.getConfigSnapshot(),
    };
  }

  // ── PRIVATE EVALUATION METHODS ──────────────────────────────────────────

  _eval4HTrend(candles4H, conditions, details) {
    if (!this.cfg.conditions.trend4H) { conditions.trend4H = NA; return null; }
    if (candles4H.length < 30) { conditions.trend4H = NA; details.trend4H = 'Insufficient 4H candles'; return null; }

    const trend = indicators.detectTrend(candles4H, this.cfg.swingLookback);
    details.trend4H = trend;

    if (trend === 'BULLISH' || trend === 'BEARISH') {
      conditions.trend4H = PASS;
    } else if (trend === 'INSUFFICIENT') {
      conditions.trend4H = NA;
    } else {
      conditions.trend4H = FAIL;
    }
    return trend;
  }

  _evalSweep(candles4H, candles1H, trend, conditions, details) {
    if (!this.cfg.conditions.sweep) { conditions.sweep = NA; return; }
    const candles = candles1H.length >= 50 ? candles1H : candles4H;
    if (candles.length < 20) { conditions.sweep = NA; details.sweep = 'Insufficient candles'; return; }

    const sweep = indicators.detectLiquiditySweep(candles, this.cfg.swingLookback, 10);
    details.sweep = sweep;

    if (!sweep.swept) { conditions.sweep = FAIL; return; }

    // Sweep direction must align with trend
    if (trend === 'BULLISH' && sweep.direction === 'LOW') conditions.sweep = PASS;
    else if (trend === 'BEARISH' && sweep.direction === 'HIGH') conditions.sweep = PASS;
    else conditions.sweep = FAIL;
  }

  _evalReclaim(candles4H, candles1H, trend, conditions, details) {
    if (!this.cfg.conditions.reclaim) { conditions.reclaim = NA; return; }
    // Reclaim = price has returned above/below swept level
    // We use the sweep result — if swept + reclaimed, this is PASS
    const sweep = details.sweep;
    if (!sweep || !sweep.swept) { conditions.reclaim = FAIL; return; }
    conditions.reclaim = sweep.reclaimed ? PASS : FAIL;
    details.reclaim = sweep.reclaimed ? `Reclaimed ${sweep.level?.toFixed(4)}` : 'No reclaim';
  }

  _eval1HStructure(candles1H, trend, conditions, details) {
    if (!this.cfg.conditions.structure1H) { conditions.structure1H = NA; return; }
    if (candles1H.length < 30) { conditions.structure1H = NA; details.structure1H = 'Insufficient 1H candles'; return; }

    const structure1H = indicators.detectTrend(candles1H, this.cfg.swingLookback);
    details.structure1H = structure1H;

    // 1H structure must align with 4H trend
    if (trend === 'BULLISH' && structure1H === 'BULLISH') conditions.structure1H = PASS;
    else if (trend === 'BEARISH' && structure1H === 'BEARISH') conditions.structure1H = PASS;
    else if (structure1H === 'INSUFFICIENT') conditions.structure1H = NA;
    else conditions.structure1H = FAIL;
  }

  _eval15MTrigger(candles15M, trend, conditions, details) {
    if (!this.cfg.conditions.trigger15M) { conditions.trigger15M = NA; return; }
    if (candles15M.length < 10) { conditions.trigger15M = NA; details.trigger15M = 'Insufficient 15M candles'; return; }

    const c = lastCandle(candles15M);
    const prev = lastCandle(candles15M, 1);
    if (!c || !prev) { conditions.trigger15M = NA; return; }

    // Bullish trigger: last candle close > open (bullish bar) above prior close
    // Bearish trigger: last candle close < open (bearish bar) below prior close
    const bullTrigger = c.close > c.open && c.close > prev.close;
    const bearTrigger = c.close < c.open && c.close < prev.close;

    details.trigger15M = {
      lastClose: c.close,
      lastOpen: c.open,
      bullTrigger,
      bearTrigger,
    };

    if (trend === 'BULLISH' && bullTrigger) conditions.trigger15M = PASS;
    else if (trend === 'BEARISH' && bearTrigger) conditions.trigger15M = PASS;
    else conditions.trigger15M = FAIL;
  }

  _evalRSI(candles15M, candles1H, trend, conditions, details) {
    if (!this.cfg.conditions.rsi) { conditions.rsi = NA; return; }
    const candles = candles15M.length >= 20 ? candles15M : candles1H;
    if (candles.length < this.cfg.rsiPeriod + 5) { conditions.rsi = NA; details.rsi = 'Insufficient data'; return; }

    const rsiValues = indicators.rsi(candles, this.cfg.rsiPeriod);
    const rsiNow = last(rsiValues);
    details.rsi = isNaN(rsiNow) ? null : parseFloat(rsiNow.toFixed(2));

    if (isNaN(rsiNow)) { conditions.rsi = NA; return; }

    // For LONG: RSI should not be overbought (< 70), ideally coming from oversold
    // For SHORT: RSI should not be oversold (> 30), ideally coming from overbought
    if (trend === 'BULLISH') {
      conditions.rsi = rsiNow < this.cfg.rsiOverbought ? PASS : FAIL;
    } else if (trend === 'BEARISH') {
      conditions.rsi = rsiNow > this.cfg.rsiOversold ? PASS : FAIL;
    } else {
      conditions.rsi = NA;
    }
  }

  _evalAlligator(candles1H, trend, conditions, details) {
    if (!this.cfg.conditions.alligator) { conditions.alligator = NA; return; }
    if (candles1H.length < 30) { conditions.alligator = NA; details.alligator = 'Insufficient 1H candles'; return; }

    const { jaw, teeth, lips } = indicators.alligator(candles1H);
    const j = last(jaw);
    const t = last(teeth);
    const l = last(lips);
    const price = lastCandle(candles1H)?.close;

    details.alligator = { jaw: j?.toFixed(4), teeth: t?.toFixed(4), lips: l?.toFixed(4) };

    if (isNaN(j) || isNaN(t) || isNaN(l)) { conditions.alligator = NA; return; }

    // Bullish alignment: lips > teeth > jaw, price above all
    // Bearish alignment: lips < teeth < jaw, price below all
    if (trend === 'BULLISH') {
      conditions.alligator = (l > t && t > j && price > l) ? PASS : FAIL;
    } else if (trend === 'BEARISH') {
      conditions.alligator = (l < t && t < j && price < l) ? PASS : FAIL;
    } else {
      conditions.alligator = NA;
    }
  }

  _evalVolume(candles15M, conditions, details) {
    if (!this.cfg.conditions.volume) { conditions.volume = NA; return; }
    if (candles15M.length < this.cfg.volMAPeriod + 2) { conditions.volume = NA; details.volume = 'Insufficient 15M candles'; return; }

    const ratios = indicators.volumeRatio(candles15M, this.cfg.volMAPeriod);
    const ratio = last(ratios);
    details.volume = isNaN(ratio) ? null : parseFloat(ratio.toFixed(2));

    if (isNaN(ratio)) { conditions.volume = NA; return; }
    conditions.volume = ratio >= this.cfg.minVolumeMultiplier ? PASS : FAIL;
  }

  _evalFunding(meta, trend, conditions, details) {
    if (!this.cfg.conditions.funding) { conditions.funding = NA; return; }
    if (meta.fundingRate === null || meta.fundingRate === undefined) { conditions.funding = NA; return; }

    const fr = meta.fundingRate;
    details.funding = fr;

    // For LONG: prefer negative or low funding (market not overcrowded long)
    // For SHORT: prefer positive funding (market overcrowded long = contrarian short)
    if (trend === 'BULLISH') {
      conditions.funding = fr <= 0.001 ? PASS : FAIL;
    } else if (trend === 'BEARISH') {
      conditions.funding = fr >= -0.001 ? PASS : FAIL;
    } else {
      conditions.funding = NA;
    }
  }

  _evalOI(meta, conditions, details) {
    if (!this.cfg.conditions.openInterest) { conditions.openInterest = NA; return; }
    if (meta.openInterest === null || meta.openInterest === undefined) { conditions.openInterest = NA; return; }

    // OI available — presence alone is scored as informational PASS
    // More sophisticated OI change analysis can be added later
    details.openInterest = meta.openInterest;
    conditions.openInterest = PASS;
  }

  _calcScore(conditions) {
    const { weights, conditions: toggles } = this.cfg;
    let totalWeight = 0;
    let earnedWeight = 0;

    for (const [key, result] of Object.entries(conditions)) {
      if (!toggles[key]) continue; // condition disabled
      const w = weights[key] || 0;
      if (result === NA) continue; // skip unavailable — don't penalize
      totalWeight += w;
      if (result === PASS) earnedWeight += w;
    }

    if (totalWeight === 0) return 0;
    return Math.round((earnedWeight / totalWeight) * 100);
  }

  _checkCritical(conditions, details) {
    // 4H trend must PASS — no trend = no trade regardless of score
    if (conditions.trend4H === FAIL) return '4H trend FAIL';
    if (conditions.trend4H === NA && details.trend4H !== 'Insufficient 4H candles') return '4H trend NOT_AVAILABLE';
    return null;
  }

  _calcLevels(candles15M, candles1H, candles4H, direction, meta) {
    if (!direction) return { entry: null, stopLoss: null, takeProfit: null, riskReward: 0 };

    const refCandles = candles15M.length >= 20 ? candles15M : candles1H;
    const c = lastCandle(refCandles);
    if (!c) return { entry: null, stopLoss: null, takeProfit: null, riskReward: 0 };

    const atrValues = indicators.atr(refCandles, this.cfg.atrPeriod);
    const atrNow = last(atrValues);
    const atrMultiplier = isNaN(atrNow) ? 0 : atrNow;

    // Entry at current close
    const entry = c.close;
    let stopLoss, takeProfit;

    if (direction === 'LONG') {
      // SL = recent swing low or ATR-based
      const recentLow = Math.min(...refCandles.slice(-10).map(x => x.low));
      stopLoss = Math.min(recentLow, entry - atrMultiplier * 1.5);
      const risk = entry - stopLoss;
      takeProfit = entry + risk * this.cfg.minRR;
    } else {
      // SL = recent swing high or ATR-based
      const recentHigh = Math.max(...refCandles.slice(-10).map(x => x.high));
      stopLoss = Math.max(recentHigh, entry + atrMultiplier * 1.5);
      const risk = stopLoss - entry;
      takeProfit = entry - risk * this.cfg.minRR;
    }

    const risk = Math.abs(entry - stopLoss);
    const reward = Math.abs(takeProfit - entry);
    const riskReward = risk > 0 ? parseFloat((reward / risk).toFixed(2)) : 0;

    return {
      entry: parseFloat(entry.toFixed(6)),
      stopLoss: parseFloat(stopLoss.toFixed(6)),
      takeProfit: parseFloat(takeProfit.toFixed(6)),
      riskReward,
    };
  }

  /** Return config snapshot for versioning */
  getConfigSnapshot() {
    return JSON.parse(JSON.stringify(this.cfg));
  }
}

module.exports = GPSStrategy;
