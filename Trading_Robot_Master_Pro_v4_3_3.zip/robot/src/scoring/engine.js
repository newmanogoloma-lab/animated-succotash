'use strict';

const config = require('../config');
const logger = require('../utils/logger');

const GRADES = {
  A_PLUS:     { min: 90, label: 'A+ SETUP' },
  QUALIFIED:  { min: 85, label: 'QUALIFIED' },
  DEVELOPING: { min: 75, label: 'DEVELOPING' },
  WATCHLIST:  { min: 65, label: 'WATCHLIST' },
  INVALID:    { min: 0,  label: 'INVALID' },
};

/**
 * Score a signal and decide: TRADE or NO_TRADE
 * The score is setup quality, not win probability.
 */
function scoreSignal(signal, overrides = {}) {
  const minScore = overrides.minScore ?? config.minScore;
  const minRR    = overrides.minRR    ?? config.minRR;

  const grade = getGrade(signal.score);
  const result = {
    ...signal,
    grade: grade.label,
    decision: null,
    rejectionReason: null,
  };

  // Critical fail overrides score
  if (signal.criticalFail) {
    result.decision = 'NO_TRADE';
    result.rejectionReason = `Critical: ${signal.criticalFail}`;
    logger.noTrade(`${signal.symbol} [${signal.strategyId}] — ${result.rejectionReason}`);
    return result;
  }

  // No direction
  if (!signal.direction) {
    result.decision = 'NO_TRADE';
    result.rejectionReason = 'No directional bias';
    return result;
  }

  // Score threshold
  if (signal.score < minScore) {
    result.decision = 'NO_TRADE';
    result.rejectionReason = `Score ${signal.score} < minimum ${minScore}`;
    logger.noTrade(`${signal.symbol} [${signal.strategyId}] — ${result.rejectionReason}`);
    return result;
  }

  // R:R threshold
  if (signal.riskReward < minRR) {
    result.decision = 'NO_TRADE';
    result.rejectionReason = `R:R ${signal.riskReward} < minimum ${minRR}`;
    logger.noTrade(`${signal.symbol} [${signal.strategyId}] — ${result.rejectionReason}`);
    return result;
  }

  // No valid levels
  if (!signal.entry || !signal.stopLoss || !signal.takeProfit) {
    result.decision = 'NO_TRADE';
    result.rejectionReason = 'Invalid entry/SL/TP levels';
    return result;
  }

  result.decision = 'TRADE';
  logger.signal(`${signal.symbol} [${signal.strategyId}] QUALIFIED — Score: ${signal.score} | R:R: ${signal.riskReward} | ${signal.direction}`);
  return result;
}

function getGrade(score) {
  if (score >= GRADES.A_PLUS.min)     return GRADES.A_PLUS;
  if (score >= GRADES.QUALIFIED.min)  return GRADES.QUALIFIED;
  if (score >= GRADES.DEVELOPING.min) return GRADES.DEVELOPING;
  if (score >= GRADES.WATCHLIST.min)  return GRADES.WATCHLIST;
  return GRADES.INVALID;
}

/** Format a rejected signal for display */
function formatRejection(signal) {
  const lines = [
    `NO TRADE`,
    ``,
    `${signal.symbol}`,
    `Score: ${signal.score}/100`,
    `Grade: ${signal.grade}`,
    ``,
    `Rejected:`,
    signal.rejectionReason || 'Unknown reason',
  ];

  if (signal.conditions) {
    const failed = Object.entries(signal.conditions)
      .filter(([, v]) => v === 'FAIL')
      .map(([k]) => `  ${k} = FAIL`);
    if (failed.length) lines.push(...failed);
  }
  return lines.join('\n');
}

module.exports = { scoreSignal, getGrade, formatRejection, GRADES };
